# Cloudflare deployment setup

## What this folder currently supports

Cloudflare Pages Functions are included for:
- `POST /api/account/signup`
- `POST /api/account/login`
- `GET /api/account/me`
- `POST /api/account/logout`

The public website files are in `public/`. The Functions are in the project-root `functions/` directory. The D1 schema is in `cloudflare/migrations/0001_gblox_accounts.sql`. `wrangler.toml` publishes `./public` and declares the D1 binding `DB`.

Other GBLOX APIs (profiles, communities, catalog, moderation, Gobux purchases/history, messaging, games, admin tools, etc.) are still Hatchable-format source in `legacy-hatchable/api/`. They are **not** operational on Cloudflare yet. Existing Hatchable account and Gobux data has not been imported. Keep the old project/database intact.

## Important: folder upload vs Functions deployment

A dashboard drag-and-drop/static folder upload does not reliably deploy a Pages `functions/` directory. Deploy this project with Wrangler from the project root, or use a Git-connected Pages project that includes both `functions/` and `public/`. Merely uploading the `public/` folder will still leave `/api/account/signup` without a POST handler (HTTP 405).

## Deploy with Wrangler

1. Create a D1 database:
   ```sh
   npx wrangler d1 create gblox-db
   ```
2. Copy the `database_id` printed by Wrangler into `wrangler.toml`, replacing `REPLACE_WITH_YOUR_D1_DATABASE_ID`.
3. From this folder (the directory containing `wrangler.toml` and `functions/`), apply the schema:
   ```sh
   npx wrangler d1 migrations apply gblox-db --remote
   ```
4. Deploy the Pages project and its Functions:
   ```sh
   npx wrangler pages deploy ./public --project-name gblox
   ```
5. In Cloudflare Pages → your project → Settings → Functions → D1 database bindings, confirm the production binding name is exactly `DB` and points to `gblox-db` if your deployment workflow does not apply the binding from Wrangler config.

If your Pages project has a different name, replace `gblox` in the deploy command with the exact project name.

## Smoke test

After deployment, open `/api/account/me` in a browser. Without a session it should return JSON with `signedIn: false`. Then create a test account on `/signup.html`. A successful signup should return HTTP 200, set secure session cookies, and `/api/account/me` should return `signedIn: true`. Use a unique test username and a password not used anywhere else.

If signup returns 503, the D1 binding/schema is missing. If it returns 404/405, the Functions were not included in the deployment or the route is not being served by Pages Functions.
