# GBLOX v712 — Cloudflare Pages project folder

This folder preserves the v712 public website assets and the original Hatchable source under `legacy-hatchable/`. It adds Cloudflare Pages Functions for signup, login, current-session lookup, and logout, plus the initial D1 account schema.

**This is not a complete migration of all GBLOX backend features.** Other legacy APIs remain under `legacy-hatchable/api/` as source/reference and are not deployed as Cloudflare Functions.

Start with `CLOUDFLARE-SETUP.md`. Do not delete the original Hatchable project/database or assume old accounts and balances have been imported.
