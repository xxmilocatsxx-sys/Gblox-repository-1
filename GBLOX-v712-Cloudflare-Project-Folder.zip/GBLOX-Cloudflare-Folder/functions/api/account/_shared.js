const enc = new TextEncoder();
export function json(data, status = 200, headers = {}) { const out = new Headers({ 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); for (const [key, value] of Object.entries(headers)) { if (key.toLowerCase() === 'set-cookie' && Array.isArray(value)) { for (const cookie of value) out.append('set-cookie', cookie); } else out.set(key, String(value)); } return new Response(JSON.stringify(data), { status, headers: out }); }
export const b64url = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
export const b64std = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes)));
export async function digest(text) { return crypto.subtle.digest('SHA-256', enc.encode(text)); }
export async function tokenHash(token) { return b64url(await digest(token)); }
export async function legacyTokenHash(token) { return b64std(await digest(token)); }
export function makeToken() { const bytes = new Uint8Array(32); crypto.getRandomValues(bytes); return b64url(bytes); }
export function cookie(name, value, maxAge) { return `${name}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax`; }
export function clearCookie(name) { return `${name}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`; }
export function getCookie(request, name) {
  const raw = request.headers.get('cookie') || '';
  for (const part of raw.split(';')) { const i = part.indexOf('='); if (i >= 0 && part.slice(0, i).trim() === name) { const value = part.slice(i + 1).trim(); try { return decodeURIComponent(value); } catch { return value; } } }
  return null;
}
export async function readJson(request) { try { return await request.json(); } catch { return null; } }
export async function passwordHash(password, saltBytes) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: saltBytes, iterations: 120000, hash: 'SHA-256' }, key, 256);
  return b64url(bits);
}
export function decodeB64url(value) { const s = value.replace(/-/g, '+').replace(/_/g, '/'); const padded = s + '='.repeat((4 - s.length % 4) % 4); const raw = atob(padded); return Uint8Array.from(raw, c => c.charCodeAt(0)); }
export function usernameProblem(username) {
  if (!/^[A-Za-z0-9_]{3,24}$/.test(username)) return 'Username must be 3–24 characters using letters, numbers, or underscores.';
  if ((username.match(/_/g) || []).length > 1) return 'Normal player usernames can contain at most one underscore.';
  const reserved = new Set(['admin','administrator','moderator','mod','owner','support','system','staff','roblox','gblocks','official','help','security','developer','dev']);
  if (reserved.has(username.toLowerCase())) return 'That username is reserved.';
  const lower = username.toLowerCase();
  const blocked = ['nigger','n1gger','pussy','pu2sy','dick','d1ck','bitch','b1tch','suckmydick','suckmyd1ck','porn','p0rn','horny','fuckpussy'];
  if (blocked.some(word => lower.includes(word))) return 'That username is not allowed.';
  return null;
}
export async function clientIpHash(request) {
  const ip = request.headers.get('cf-connecting-ip') || '';
  if (!ip) return null;
  return b64url(await digest(`gblox-signup:${ip}`));
}
