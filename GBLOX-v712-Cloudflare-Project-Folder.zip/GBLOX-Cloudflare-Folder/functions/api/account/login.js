import { json, readJson, passwordHash, decodeB64url, makeToken, tokenHash, legacyTokenHash, cookie } from './_shared.js';
export async function onRequestPost({ request, env }) {
  if (!env.DB) return json({ error: 'GBLOX database is not connected yet. Create the D1 database and bind it as DB.' }, 503);
  const body = await readJson(request);
  const username = String(body?.username || '').trim();
  const password = String(body?.password || '');
  if (!username || !password) return json({ error: 'Enter your username and password.' }, 400);
  const row = await env.DB.prepare('SELECT p.user_id,p.username,p.display_name,p.banned,p.terminated,p.temp_ban_until,p.ban_note,p.role,p.is_bot,p.deactivated_at,p.recovery_deadline,c.password_salt,c.password_hash FROM profiles p JOIN account_credentials c ON c.user_id=p.user_id WHERE p.username=? COLLATE NOCASE LIMIT 1').bind(username).first();
  if (!row) return json({ error: 'Incorrect username or password.' }, 401);
  const actual = await passwordHash(password, decodeB64url(row.password_salt));
  if (actual !== row.password_hash) return json({ error: 'Incorrect username or password.' }, 401);
  if (row.deactivated_at) return json({ error: 'This account is deactivated. You can reactivate it at any time.', deactivated: true, reactivation_required: true, username: row.username, recovery_deadline: row.recovery_deadline, redirect: '/account-deactivated.html' }, 403);
  if (row.terminated) return json({ error: 'This account has been terminated.', moderated: true, moderation_status: 'terminated', redirect: '/moderation.html' }, 403);
  const raw = makeToken();
  await env.DB.batch([
    env.DB.prepare(`INSERT INTO account_sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime('now','+30 days'))`).bind(await tokenHash(raw), row.user_id),
    env.DB.prepare(`INSERT OR IGNORE INTO gblocks_sessions(token_hash,user_id,expires_at) SELECT ?,user_id,datetime('now','+30 days') FROM gblocks_players WHERE user_id=?`).bind(await legacyTokenHash(raw), row.user_id),
    env.DB.prepare('INSERT INTO login_history(user_id) VALUES(?)').bind(row.user_id),
    env.DB.prepare("UPDATE profiles SET last_seen_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(row.user_id)
  ]);
  const activeBan = !!row.banned && (!row.temp_ban_until || new Date(row.temp_ban_until) > new Date());
  const payload = activeBan ? { ok: true, sessionCreated: true, moderated: true, moderation_status: 'banned', redirect: '/moderation.html', user: { username: row.username, display_name: row.display_name } } : { ok: true, user: { username: row.username, display_name: row.display_name, is_bot: !!row.is_bot }, sessionCreated: true };
  return json(payload, 200, { 'set-cookie': [cookie('groblox_session', raw, 2592000), cookie('gblocks_session', raw, 2592000)] });
}
