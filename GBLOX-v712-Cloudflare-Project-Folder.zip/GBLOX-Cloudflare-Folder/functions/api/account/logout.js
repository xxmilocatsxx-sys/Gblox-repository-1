import { json, getCookie, tokenHash, legacyTokenHash, clearCookie } from './_shared.js';
export async function onRequestPost({ request, env }) {
  const raw = getCookie(request, 'groblox_session') || getCookie(request, 'gblocks_session');
  if (raw && env.DB) {
    await env.DB.batch([
      env.DB.prepare('DELETE FROM account_sessions WHERE token_hash IN (?,?)').bind(await tokenHash(raw), await legacyTokenHash(raw)),
      env.DB.prepare('DELETE FROM gblocks_sessions WHERE token_hash IN (?,?)').bind(await tokenHash(raw), await legacyTokenHash(raw))
    ]);
  }
  return json({ ok: true, signedIn: false }, 200, { 'set-cookie': [clearCookie('groblox_session'), clearCookie('gblocks_session')] });
}
