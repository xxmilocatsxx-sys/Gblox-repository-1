import { json, getCookie, tokenHash, legacyTokenHash } from './_shared.js';
export async function onRequestGet({ request, env }) {
  if (!env.DB) return json({ signedIn: false, user: null, error: 'GBLOX database is not connected.' }, 503);
  const raw = getCookie(request, 'groblox_session') || getCookie(request, 'gblocks_session');
  if (!raw) return json({ signedIn: false, user: null });
  const hashes = [await tokenHash(raw), await legacyTokenHash(raw)];
  const row = await env.DB.prepare("SELECT p.user_id,p.user_number,p.username,p.display_name,p.role,p.verified,p.banned,p.terminated,p.temp_ban_until,p.ban_note,p.is_bot FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash IN (?,?) AND s.expires_at>datetime('now') LIMIT 1").bind(...hashes).first();
  if (!row) return json({ signedIn: false, user: null });
  row.public_id = `GBlocks User #${row.user_number}`;
  const activeBan = !!row.banned && (!row.temp_ban_until || new Date(row.temp_ban_until) > new Date());
  if (row.terminated) return json({ signedIn: true, user: row, moderated: true, moderation_status: 'terminated', redirect: '/moderation.html' });
  if (activeBan) return json({ signedIn: true, user: row, moderated: true, moderation_status: 'banned', redirect: '/moderation.html' });
  return json({ signedIn: true, user: row });
}
