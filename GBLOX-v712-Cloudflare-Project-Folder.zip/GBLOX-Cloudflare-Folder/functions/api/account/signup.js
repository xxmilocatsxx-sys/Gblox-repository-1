import { json, readJson, b64url, passwordHash, makeToken, tokenHash, legacyTokenHash, cookie, usernameProblem, clientIpHash } from './_shared.js';

export async function onRequestPost({ request, env }) {
  if (!env.DB) return json({ error: 'GBLOX database is not connected yet. Create the D1 database and bind it as DB.' }, 503);
  const body = await readJson(request);
  if (!body || typeof body !== 'object') return json({ error: 'Invalid signup request.' }, 400);
  const username = String(body.username || '').trim();
  const displayName = String(body.display_name || username).trim().slice(0, 40) || username;
  const gender = String(body.gender || '').trim().toLowerCase();
  const password = String(body.password || '');
  const issue = usernameProblem(username);
  if (issue) return json({ error: issue }, 400);
  if (!['male', 'female'].includes(gender)) return json({ error: 'Choose Male or Female for your account gender.' }, 400);
  if (password.length < 8) return json({ error: 'Password must be at least 8 characters.' }, 400);
  if (password.length > 128) return json({ error: 'Password is too long.' }, 400);

  const ipHash = await clientIpHash(request);
  if (ipHash) {
    await env.DB.prepare("DELETE FROM gblox_signup_rate_limits WHERE created_at < datetime('now','-48 hours')").run();
    const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM gblox_signup_rate_limits WHERE ip_hash=? AND created_at > datetime('now','-1 hour')").bind(ipHash).first('n');
    if (Number(count || 0) >= 15) return json({ error: 'Too many account-creation attempts from this network. Please wait and try again later.', retryAfterSeconds: 3600 }, 429);
    await env.DB.prepare('INSERT INTO gblox_signup_rate_limits(ip_hash) VALUES(?)').bind(ipHash).run();
  }

  const taken = await env.DB.prepare('SELECT 1 FROM profiles WHERE username=? COLLATE NOCASE UNION ALL SELECT 1 FROM gblocks_players WHERE username=? COLLATE NOCASE LIMIT 1').bind(username, username).first();
  if (taken) return json({ error: 'That username is already taken. Sign in to your existing account or choose another username.' }, 409);
  const reservation = await env.DB.prepare('SELECT reserved_for_user_id,reason FROM username_reservations WHERE username=? COLLATE NOCASE LIMIT 1').bind(username).first();
  if (reservation) {
    const former = reservation.reserved_for_user_id ? await env.DB.prepare('SELECT 1 FROM profiles WHERE user_id=?').bind(reservation.reserved_for_user_id).first() : null;
    if (reservation.reason !== 'username_history' || former) return json({ error: 'That username is reserved and cannot be used for a new account.' }, 409);
  }
  const history = await env.DB.prepare('SELECT user_id FROM username_history WHERE username=? COLLATE NOCASE ORDER BY changed_at DESC,id DESC LIMIT 1').bind(username).first();
  if (history && await env.DB.prepare('SELECT 1 FROM profiles WHERE user_id=?').bind(history.user_id).first()) return json({ error: 'That username is still associated with an existing account.' }, 409);

  const userId = crypto.randomUUID();
  const sequence = await env.DB.prepare('UPDATE gblox_user_number_sequence SET next_number=next_number+1 WHERE id=1 RETURNING next_number-1 AS user_number').first();
  if (!sequence) return json({ error: 'Account numbering is unavailable. Please contact the site administrator.' }, 500);
  const userNumber = Number(sequence.user_number);
  const salt = new Uint8Array(16); crypto.getRandomValues(salt);
  const saltText = b64url(salt);
  const hash = await passwordHash(password, salt);
  const avatar = JSON.stringify({ custom: { gender, body: 'classic', face: '⌣', hair: gender === 'female' ? 'brown' : 'none', shirt: gender === 'female' ? '#a855f7' : '#b91c1c', pants: '#17212b', skin: '#f2c94c', items: { hat: 'red-cap' } }, body: 'classic', face: '⌣', outfit: 'default-2021', gender });
  const rawToken = makeToken();
  const th = await tokenHash(rawToken);
  const legacyHash = await legacyTokenHash(rawToken);
  try {
    await env.DB.batch([
      env.DB.prepare('INSERT INTO profiles(user_id,user_number,username,display_name,bio,avatar,gender,role) VALUES(?,?,?,?,?,?,?,?)').bind(userId, userNumber, username, displayName, '', avatar, gender, 'user'),
      env.DB.prepare('INSERT INTO account_credentials(user_id,password_salt,password_hash) VALUES(?,?,?)').bind(userId, saltText, hash),
      env.DB.prepare('INSERT INTO user_settings(user_id,gender) VALUES(?,?)').bind(userId, gender),
      env.DB.prepare('INSERT INTO gblocks_players(user_id,username,display_name,bio,avatar,gender) VALUES(?,?,?,?,?,?)').bind(userId, username, displayName, '', avatar, gender),
      env.DB.prepare('INSERT INTO gobux_accounts(user_id,balance,last_daily_at,gobux_infinite) VALUES(?,?,NULL,0)').bind(userId, 50),
      env.DB.prepare(`INSERT INTO account_sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime('now','+30 days'))`).bind(th, userId),
      env.DB.prepare(`INSERT INTO gblocks_sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime('now','+30 days'))`).bind(legacyHash, userId)
    ]);
  } catch (error) {
    // D1 batch is transactional: no partial account should be left behind.
    const message = String(error?.message || '');
    if (/UNIQUE constraint failed|constraint failed/i.test(message)) return json({ error: 'That username or account number was just taken. Please choose another username.' }, 409);
    return json({ error: 'Account creation failed safely. Please try again.' }, 500);
  }
  return json({ ok: true, user: { username, display_name: displayName, user_number: userNumber, public_id: `GBlocks User #${userNumber}`, restricted_admin: false }, sessionCreated: true }, 200, { 'set-cookie': [cookie('groblox_session', rawToken, 2592000), cookie('gblocks_session', rawToken, 2592000)] });
}
