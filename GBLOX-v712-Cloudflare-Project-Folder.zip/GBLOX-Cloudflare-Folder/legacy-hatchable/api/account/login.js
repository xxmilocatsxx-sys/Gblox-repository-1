import { db } from "hatchable";
import { clientIp, activeIpRestriction, recordLoginIp } from "../../lib/ip-restrictions.js";
// Username safety must not punish existing accounts during login.
export const access = "public";
export const methods = ["POST"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).split("+").join("-").split("/").join("_").replace(/=+$/,"");
const unb64=s=>{s=s.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";const x=atob(s);return Uint8Array.from(x,c=>c.charCodeAt(0))};
async function hash(password,salt){const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:120000,hash:"SHA-256"},key,256);return b64(bits)}
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
async function legacyTokenHash(t){return btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest("SHA-256",enc.encode(t)))))}
function cookie(name,value,maxAge){return name+"="+value+"; Path=/; Max-Age="+maxAge+"; HttpOnly; Secure; SameSite=Lax"}
function token(){const b=new Uint8Array(32);crypto.getRandomValues(b);return b64(b)}
export default async function(req,res){
 const username=String(req.body?.username||"").trim(),password=String(req.body?.password||"");
 if(!username||!password)return res.status(400).json({error:"Enter your username and password."});
 const q=await db.query("SELECT p.user_id,p.username,p.display_name,p.banned,p.terminated,p.temp_ban_until,p.ban_note,p.role,p.is_bot,p.deactivated_at,p.recovery_deadline,c.password_salt,c.password_hash FROM profiles p JOIN account_credentials c ON c.user_id=p.user_id WHERE LOWER(p.username)=LOWER($1)",[username]);
 const row=q.rows[0];if(!row)return res.status(401).json({error:"Incorrect username or password."});
 const actual=await hash(password,unb64(row.password_salt));if(actual!==row.password_hash)return res.status(401).json({error:"Incorrect username or password."});
 const remoteIp=clientIp(req);const ipRestriction=await activeIpRestriction(remoteIp);if(ipRestriction)return res.status(403).json({error:"Sign-in is restricted from this network address.",restricted:true,reason:ipRestriction.reason});
 await recordLoginIp(row.user_id,remoteIp);
 if(row.deactivated_at)return res.status(403).json({error:"This account is deactivated. You can reactivate it at any time.",deactivated:true,reactivation_required:true,username:row.username,recovery_deadline:row.recovery_deadline,redirect:"/account-deactivated.html"});
 if(row.terminated)return res.status(403).json({error:"This account has been terminated.",moderated:true,moderation_status:"terminated",redirect:"/moderation.html"});
 // Login never applies automatic username-based punishment. Existing moderation status is checked below.
 const raw=token(),th=await tokenHash(raw);await db.query("INSERT INTO account_sessions (token_hash,user_id,expires_at) VALUES ($1,$2,NOW()+INTERVAL '30 days')",[th,row.user_id]);
 // Keep the legacy GBLOX player session store in sync so older pages and APIs recognize this same login.
 const legacyHash=await legacyTokenHash(raw);await db.query("INSERT INTO gblocks_sessions (token_hash,user_id,expires_at) SELECT $1,user_id,NOW()+INTERVAL '30 days' FROM gblocks_players WHERE user_id=$2 ON CONFLICT (token_hash) DO NOTHING",[legacyHash,row.user_id]);
 await db.query("INSERT INTO login_history (user_id) VALUES ($1)",[row.user_id]);await db.query("UPDATE profiles SET last_seen_at=NOW() WHERE user_id=$1",[row.user_id]);
 res.setHeader("Cache-Control","no-store");res.setHeader("Set-Cookie",[cookie("groblox_session",raw,2592000),cookie("gblocks_session",raw,2592000)]);
 const activeBan=!!row.banned&&(!row.temp_ban_until||new Date(row.temp_ban_until)>new Date());
 if(row.terminated||activeBan)return res.json({ok:true,sessionCreated:true,moderated:true,moderation_status:row.terminated?"terminated":"banned",redirect:"/moderation.html",user:{username:row.username,display_name:row.display_name}});
 res.json({ok:true,user:{username:row.username,display_name:row.display_name,is_bot:row.is_bot===true},sessionCreated:true});
}