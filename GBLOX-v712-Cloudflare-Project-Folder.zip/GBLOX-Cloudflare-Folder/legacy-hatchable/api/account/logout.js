import { db } from "hatchable";
export const access = "public";
export const methods = ["POST"];
const enc=new TextEncoder();const b64u=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes)));
async function tokenHash(t){return b64u(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
async function legacyTokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function getCookie(req,name){const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));if(!m)return null;try{return decodeURIComponent(m[1])}catch{return m[1]}}
export default async function(req,res){
  const playerRaw=getCookie(req,"groblox_session")||getCookie(req,"gblocks_session");
  const adminRaw=getCookie(req,"gblocks_admin_session");
  if(playerRaw){
    const th=await tokenHash(playerRaw),legacy=await legacyTokenHash(playerRaw);
    const q=await db.query("SELECT user_id FROM account_sessions WHERE token_hash=$1 OR token_hash=$2 LIMIT 1",[th,legacy]);
    if(q.rows[0])await db.query("UPDATE profiles SET last_seen_at=NULL WHERE user_id=$1",[q.rows[0].user_id]);
    await db.query("DELETE FROM account_sessions WHERE token_hash=$1 OR token_hash=$2",[th,legacy]);
    await db.query("DELETE FROM gblocks_sessions WHERE token_hash=$1 OR token_hash=$2",[legacy,th]);
  }
  // An explicit logout from the main account flow must also end any admin session
  // carried by this browser; never alter the target profile's role or bot flag.
  if(adminRaw)await db.query("DELETE FROM admin_sessions WHERE token_hash=$1",[await tokenHash(adminRaw)]);
  res.setHeader("Set-Cookie",[
    "groblox_session=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Secure; SameSite=Lax",
    "gblocks_session=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Secure; SameSite=Lax",
    "gblocks_admin_session=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Secure; SameSite=Lax"
  ]);
  res.setHeader("Cache-Control","no-store, no-cache, must-revalidate, private");
  res.setHeader("Pragma","no-cache");
  res.json({ok:true,signedOut:true,playerSessionRevoked:!!playerRaw,adminSessionRevoked:!!adminRaw});
}