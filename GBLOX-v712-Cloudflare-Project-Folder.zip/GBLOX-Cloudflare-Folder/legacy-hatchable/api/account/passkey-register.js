import { db } from "hatchable";

export const access = "public";
export const methods = ["POST"];

function b64urlToBytes(s) { const t=s.replace(/-/g,"+").replace(/_/g,"/")+"=".repeat((4-s.length%4)%4); const bin=atob(t); return Uint8Array.from(bin,c=>c.charCodeAt(0)); }
function bytesToB64url(a) { let s=""; for(const b of a)s+=String.fromCharCode(b); return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,""); }
function utf8(a){return new TextDecoder().decode(a)}
function readLen(ai,bytes,st){ if(ai<24)return [ai,st]; if(ai===24)return [bytes[st],st+1]; if(ai===25)return [(bytes[st]<<8)|bytes[st+1],st+2]; if(ai===26)return [((bytes[st]*0x1000000)>>>0)|(bytes[st+1]<<16)|(bytes[st+2]<<8)|bytes[st+3],st+4]; throw new Error("Unsupported CBOR length"); }
function cbor(bytes){ let p=0; function val(){const h=bytes[p++],major=h>>5,ai=h&31; if(major===0){const [n,np]=readLen(ai,bytes,p);p=np;return n} if(major===1){const [n,np]=readLen(ai,bytes,p);p=np;return -1-n} if(major===2){const [n,np]=readLen(ai,bytes,p);p=np;const x=bytes.slice(p,p+n);p+=n;return x} if(major===3){const [n,np]=readLen(ai,bytes,p);p=np;const x=bytes.slice(p,p+n);p+=n;return utf8(x)} if(major===4){const [n,np]=readLen(ai,bytes,p);p=np;const a=[];for(let i=0;i<n;i++)a.push(val());return a} if(major===5){const [n,np]=readLen(ai,bytes,p);p=np;const m=new Map();for(let i=0;i<n;i++){const k=val();m.set(k,val())}return m} if(major===7&&ai===20)return false;if(major===7&&ai===21)return true;if(major===7&&ai===22)return null;throw new Error("Unsupported CBOR type")} return val(); }
function derToRaw(sig){ if(sig[0]!==0x30)throw new Error("Invalid signature");let p=2;if(sig[p++]!==0x02)throw new Error("Invalid signature");const rl=sig[p++];let r=sig.slice(p,p+rl);p+=rl;if(sig[p++]!==0x02)throw new Error("Invalid signature");const sl=sig[p++];let s=sig.slice(p,p+sl);while(r.length>32&&r[0]===0)r=r.slice(1);while(s.length>32&&s[0]===0)s=s.slice(1);if(r.length>32||s.length>32)throw new Error("Invalid signature");const out=new Uint8Array(64);out.set(r,32-r.length);out.set(s,64-s.length);return out}
async function sha256Bytes(a){return new Uint8Array(await crypto.subtle.digest("SHA-256",a))}
async function verifyES256(jwk,data,sig){const key=await crypto.subtle.importKey("jwk",jwk,{name:"ECDSA",namedCurve:"P-256"},false,["verify"]);return crypto.subtle.verify({name:"ECDSA",hash:"SHA-256"},key,derToRaw(sig),data)}

export default async function(req,res){
  try{
    const body=req.body||{};const session=req.cookies?.groblox_session;if(!session) return res.status(401).json({error:"Sign in first."});
    const tokenHash=bytesToB64url(await sha256Bytes(new TextEncoder().encode(session)));
    const sr=await db.query("SELECT p.user_id,p.username,p.display_name,p.banned FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[tokenHash]);const user=sr.rows[0];if(!user)return res.status(401).json({error:"Session expired."});if(user.banned)return res.status(403).json({error:"This account is banned."});
    const cr=await db.query("SELECT id,challenge FROM passkey_challenges WHERE user_id=$1 AND purpose='register' AND expires_at>NOW() ORDER BY created_at DESC LIMIT 1",[user.user_id]);const ch=cr.rows[0];if(!ch)return res.status(400).json({error:"Passkey setup expired. Start again."});
    const cd=b64urlToBytes(body.clientDataJSON||"");const client=JSON.parse(utf8(cd));if(client.type!=="webauthn.create"||client.challenge!==ch.challenge||client.origin!=="https://gblocks.hatchable.site")throw new Error("Passkey registration verification failed.");
    const att=b64urlToBytes(body.attestationObject||"");const obj=cbor(att);const auth=obj.get("authData");if(!(auth instanceof Uint8Array)||auth.length<55)throw new Error("Invalid authenticator data.");
    const rpHash=await sha256Bytes(new TextEncoder().encode("gblocks.hatchable.site"));for(let i=0;i<32;i++)if(auth[i]!==rpHash[i])throw new Error("Wrong website origin.");
    const flags=auth[32];if(!(flags&1)||!(flags&4))throw new Error("Passkey must use user verification.");const signCount=((auth[33]*0x1000000)>>>0)|(auth[34]<<16)|(auth[35]<<8)|auth[36];
    const idLen=(auth[53]<<8)|auth[54];const credId=auth.slice(55,55+idLen);const cose=cbor(auth.slice(55+idLen));if(!(cose instanceof Map)||cose.get(1)!==2||cose.get(3)!==-7||cose.get(-1)!==1)throw new Error("This passkey type is not supported.");const x=cose.get(-2),y=cose.get(-3);if(!(x instanceof Uint8Array)||!(y instanceof Uint8Array)||x.length!==32||y.length!==32)throw new Error("Invalid passkey key.");
    const credentialId=bytesToB64url(credId);const jwk={kty:"EC",crv:"P-256",x:bytesToB64url(x),y:bytesToB64url(y),ext:true};
    await db.query("INSERT INTO passkey_credentials (credential_id,user_id,public_key_jwk,sign_count) VALUES ($1,$2,$3::jsonb,$4)",[credentialId,user.user_id,JSON.stringify(jwk),signCount]);
    await db.query("DELETE FROM passkey_challenges WHERE id=$1",[ch.id]);res.json({ok:true});
  }catch(e){res.status(400).json({error:e.message||"Passkey registration failed."})}
}