import { db } from "hatchable";
export const access = "public";
export const methods = ["POST"];
const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes)));
const b64url = bytes => b64(bytes).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
const unb64 = s => { s=String(s||"").replace(/-/g,"+").replace(/_/g,"/"); while(s.length%4)s+="="; return Uint8Array.from(atob(s),c=>c.charCodeAt(0)); };
async function hashPassword(password,salt,iterations,urlSafe=true){const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations,hash:"SHA-256"},key,256);return urlSafe?b64url(bits):b64(bits);}
async function tokenHash(token,url=false){const h=await crypto.subtle.digest("SHA-256",enc.encode(token));return url?b64url(h):b64(h);}
function setCookie(res,name,value){res.setHeader("Set-Cookie",name+"="+value+"; Path=/; Max-Age=2592000; HttpOnly; Secure; SameSite=Lax");}
export default async function(req,res){
 const username=String(req.body?.username||"").trim(),password=String(req.body?.password||"");
 if(!username||!password)return res.status(400).json({error:"Enter your username and password to reactivate your account."});
 let account=null,system="";
 const legacy=await db.query("SELECT p.user_id,p.username,p.display_name,p.deactivated_at,p.recovery_deadline,p.legacy_status,c.password_salt,c.password_hash FROM profiles p JOIN account_credentials c ON c.user_id=p.user_id WHERE LOWER(p.username)=LOWER($1) LIMIT 1",[username]);
 if(legacy.rows[0]){
  const a=legacy.rows[0],actual=await hashPassword(password,unb64(a.password_salt),120000);
  if(actual!==a.password_hash)return res.status(401).json({error:"Incorrect username or password."});
  account=a;system="legacy";
 }else{
  const modern=await db.query("SELECT p.user_id,p.username,p.display_name,p.deactivated_at,p.recovery_deadline,p.legacy_status,c.password_salt,c.password_hash FROM gblocks_players p JOIN gblocks_credentials c ON c.user_id=p.user_id WHERE LOWER(c.username)=LOWER($1) LIMIT 1",[username]);
  if(!modern.rows[0])return res.status(401).json({error:"Incorrect username or password."});
  const a=modern.rows[0],actual=await hashPassword(password,unb64(a.password_salt),210000,false);
  if(actual!==a.password_hash)return res.status(401).json({error:"Incorrect username or password."});
  account=a;system="modern";
 }
 if(!account.deactivated_at)return res.status(409).json({error:"This account is not deactivated. Sign in normally."});
 const uid=String(account.user_id);
 const banned=await db.query("SELECT p.banned,p.terminated,g.moderation_status FROM profiles p FULL JOIN gblocks_players g ON g.user_id=p.user_id WHERE COALESCE(p.user_id,g.user_id)=$1 LIMIT 1",[uid]);
 if(banned.rows[0]?.terminated||banned.rows[0]?.moderation_status==='terminated')return res.status(403).json({error:"This account is terminated and cannot be reactivated through this screen."});
 if(banned.rows[0]?.banned||banned.rows[0]?.moderation_status==='banned')return res.status(403).json({error:"This account is currently banned. Reactivation cannot bypass moderation."});
 await db.query("UPDATE profiles SET deactivated_at=NULL,recovery_deadline=NULL,legacy_status='active',legacy_reviewed_at=NULL WHERE user_id=$1",[uid]);
 await db.query("UPDATE gblocks_players SET deactivated_at=NULL,recovery_deadline=NULL,legacy_status='active',legacy_reviewed_at=NULL,reactivated_at=NOW(),updated_at=NOW() WHERE user_id=$1",[uid]);
 await db.query("INSERT INTO gblocks_account_deactivation_history(user_id,action,username_snapshot,display_name_snapshot,deactivated_at,recovery_deadline) VALUES($1,'reactivated',$2,$3,$4,$5)",[uid,account.username,account.display_name||account.username,account.deactivated_at,account.recovery_deadline]);
 const raw=b64url(crypto.getRandomValues(new Uint8Array(32)));
 if(system==="legacy"){
  await db.query("INSERT INTO account_sessions(token_hash,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 days')",[await tokenHash(raw,true),uid]);
  await db.query("INSERT INTO login_history(user_id) VALUES($1)",[uid]);
  setCookie(res,"groblox_session",raw);
 }else{
  await db.query("INSERT INTO gblocks_sessions(token_hash,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 days')",[await tokenHash(raw,false),uid]);
  setCookie(res,"gblocks_session",raw);
 }
 res.setHeader("Cache-Control","no-store");
 return res.json({ok:true,reactivated:true,message:"Account reactivated. Welcome back.",user:{user_id:uid,username:account.username,display_name:account.display_name}});
}