import { db } from "hatchable";
import { clientIp, activeIpRestriction } from "../../lib/ip-restrictions.js";
import { checkUsername, isRestrictedAdminUsername } from "../../lib/username-policy.js";
import { hashText } from "../../lib/discord.js";
export const access = "public";
export const methods = ["POST"];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function hashPassword(password, saltBytes) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({name:"PBKDF2",salt:saltBytes,iterations:120000,hash:"SHA-256"}, key, 256);
  return b64(bits);
}
function cookie(name,value,maxAge){return `${name}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax`}
function token(){const b=new Uint8Array(32);crypto.getRandomValues(b);return b64(b)}
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
async function legacyTokenHash(t){return btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest("SHA-256",enc.encode(t)))))}

export default async function(req,res){
  const username=String(req.body?.username||"").trim();
  const displayName=String(req.body?.display_name||username).trim().slice(0,40);
  const gender=String(req.body?.gender||"").trim().toLowerCase();
  const password=String(req.body?.password||"");
  if(!["male","female"].includes(gender)) return res.status(400).json({error:"Choose Male or Female for your account gender."});
  if(!/^[A-Za-z0-9_]{3,24}$/.test(username)) return res.status(400).json({error:"Username must be 3–24 characters using letters, numbers, or underscores."});
  if((username.match(/_/g)||[]).length>1) return res.status(400).json({error:"Normal player usernames can contain at most one underscore."});
  const builtInRestricted = isRestrictedAdminUsername(username);
  const permanentBadge = (await db.query("SELECT 1 FROM restricted_admin_badges WHERE username_key=LOWER($1) LIMIT 1",[username])).rows.length > 0;
  const restrictedAdmin = builtInRestricted || permanentBadge;
  const usernamePolicy=checkUsername(username);
  if(usernamePolicy.flagged && !restrictedAdmin) return res.status(400).json({error:"That username is not allowed: "+usernamePolicy.reason});
  if(password.length<8) return res.status(400).json({error:"Password must be at least 8 characters."});
  if(password.length>128) return res.status(400).json({error:"Password is too long."});
  const signupIp=clientIp(req);const signupIpRestriction=await activeIpRestriction(signupIp);if(signupIpRestriction)return res.status(403).json({error:"Account creation is restricted from this network address.",restricted:true,reason:signupIpRestriction.reason});
  // Privacy-conscious signup throttling: hash the network address, retain only
  // short-lived counters, and never ban users based on a shared IP.
  const forwarded=String(req.headers?.["cf-connecting-ip"]||req.headers?.["x-forwarded-for"]||"").split(",")[0].trim();
  const remoteIp=forwarded||String(req.ip||"").trim();
  if(remoteIp){
    const ipHash=await hashText("gblox-signup:"+remoteIp);
    await db.query("DELETE FROM gblox_signup_rate_limits WHERE created_at<NOW()-INTERVAL '48 hours'");
    const attempts=await db.query("SELECT COUNT(*)::int AS n FROM gblox_signup_rate_limits WHERE ip_hash=$1 AND created_at>NOW()-INTERVAL '1 hour'",[ipHash]);
    if(Number(attempts.rows[0]?.n||0)>=15)return res.status(429).json({error:"Too many account-creation attempts from this network. Please wait and try again later.",retryAfterSeconds:3600});
    await db.query("INSERT INTO gblox_signup_rate_limits(ip_hash) VALUES($1)",[ipHash]);
  }
  // Discord is optional and is not part of account registration. Signup proceeds with username and password only.
  // Check both identity stores before creating anything. A username already
  // owned in either namespace must never be reassigned to a fresh user ID.
  const taken=await db.query("SELECT 1 FROM profiles WHERE LOWER(username)=LOWER($1) UNION ALL SELECT 1 FROM gblocks_players WHERE LOWER(username)=LOWER($1) LIMIT 1",[username]);
  if(taken.rows.length) return res.status(409).json({error:"That username is already taken. If you believe this is your existing account, sign in or contact support; a new account will not be created."});
  // Username history is audit data, not identity. A prior name can be reused
  // only after its former account ID is gone, and only if no active account or
  // non-history reservation owns the name.
  const reserved=await db.query("SELECT reserved_for_user_id,reason FROM username_reservations WHERE LOWER(username)=LOWER($1) LIMIT 1",[username]);
  if(reserved.rows[0]) {
    const r=reserved.rows[0];
    const formerStillExists=(await db.query("SELECT 1 FROM profiles WHERE user_id=$1 UNION ALL SELECT 1 FROM gblocks_players WHERE user_id=$1 LIMIT 1",[r.reserved_for_user_id])).rows.length>0;
    if(r.reason!=="username_history" || formerStillExists) return res.status(409).json({error:"That username is reserved and cannot be used for a new account."});
  }
  const historical=await db.query("SELECT user_id FROM username_history WHERE LOWER(username)=LOWER($1) ORDER BY changed_at DESC,id DESC LIMIT 1",[username]);
  if(historical.rows[0]) {
    const formerStillExists=(await db.query("SELECT 1 FROM profiles WHERE user_id=$1 UNION ALL SELECT 1 FROM gblocks_players WHERE user_id=$1 LIMIT 1",[historical.rows[0].user_id])).rows.length>0;
    if(formerStillExists) return res.status(409).json({error:"That username is still associated with an existing account."});
  }
  const salt=new Uint8Array(16);crypto.getRandomValues(salt);
  const saltText=b64(salt);const passwordHash=await hashPassword(password,salt);
  const userId=crypto.randomUUID();
  // Allocate public GBlocks user numbers monotonically from a durable sequence.
  // Never derive an ID from the currently existing profiles: permanent deletion
  // must not make an old public user number available to a new account.
  const numberRow=await db.query("UPDATE gblocks_user_number_sequence SET next_number=next_number+1 WHERE id=1 RETURNING next_number-1 AS user_number");
  if(!numberRow.rows[0]) return res.status(500).json({error:"Account numbering is unavailable. Please try again later."});
  const userNumber=Number(numberRow.rows[0].user_number);
  const female=gender==='female';
  const defaultAvatar={custom:{gender,body:'classic',face:'⌣',hair:female?'brown':'none',shirt:female?'#a855f7':'#b91c1c',pants:'#17212b',skin:'#f2c94c',items:{hat:'red-cap'}},body:'classic',face:'⌣',outfit:'default-2021',gender};
  const fixedAvatar = {image_url: username.toLowerCase()==='toobers93' ? "/toobers93back_alt.png" : "/tubers93-avatar.png", source: "GBlocks fixed avatar"};
  const usesFixedAvatar = ['tubers93','toobers93'].includes(username.toLowerCase());
  const avatarValue=JSON.stringify(usesFixedAvatar?fixedAvatar:(restrictedAdmin?fixedAvatar:defaultAvatar));
  const raw=token();const th=await tokenHash(raw);
  const writes=[
    {sql:"INSERT INTO profiles (user_id, username, display_name, bio, avatar, user_number, gender, role) VALUES ($1,$2,$3,'',$4::jsonb,$5,$6,'user')",params:[userId,username,displayName||username,avatarValue,userNumber,gender]},
    {sql:"INSERT INTO account_credentials (user_id,password_salt,password_hash) VALUES ($1,$2,$3)",params:[userId,saltText,passwordHash]},
    {sql:"INSERT INTO user_settings (user_id,gender,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET gender=EXCLUDED.gender,updated_at=NOW()",params:[userId,gender]},
    {sql:"INSERT INTO gblocks_players (user_id,username,display_name,bio,avatar,gender) VALUES ($1,$2,$3,'',$4::jsonb,$5)",params:[userId,username,displayName||username,avatarValue,gender]},
    {sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,50,NULL,false)",params:[userId]},
    {sql:"INSERT INTO account_sessions (token_hash,user_id,expires_at) VALUES ($1,$2,NOW()+INTERVAL '30 days')",params:[th,userId]},
    {sql:"INSERT INTO gblocks_sessions (token_hash,user_id,expires_at) VALUES ($1,$2,NOW()+INTERVAL '30 days')",params:[await legacyTokenHash(raw),userId]}
  ];
  // Do not create or require a Discord link during signup; users may link later in settings.
  // Admin privileges and badges must never be inferred from a public username.
  // Newly registered accounts always start as normal players; legitimate roles
  // can be granted later by an authenticated administrator to this exact user ID.
  try {
    // Keep all account rows in one transaction. Any unique-key collision rolls
    // back the profile, credentials, wallet and session together.
    await db.transaction(writes);
  } catch (error) {
    const code=error?.code||error?.cause?.code;
    if(code==="23505" || /duplicate key|unique constraint/i.test(String(error?.message||""))) {
      console.warn("Signup rejected by a uniqueness constraint.");
      return res.status(409).json({error:"That username or account number was just taken. Please choose another username or try again. No partial account was created."});
    }
    console.error("Signup transaction failed.");
    return res.status(500).json({error:"Account creation failed safely. Please try again."});
  }
  // Account creation is independent of Discord moderation or bot status.
  // Unsafe usernames are rejected at signup; do not schedule a later punitive account action.
  res.setHeader("Cache-Control","no-store");
  res.setHeader("Set-Cookie",[cookie("groblox_session",raw,2592000),cookie("gblocks_session",raw,2592000)]);
  res.json({ok:true,user:{username,display_name:displayName||username,user_number:userNumber,public_id:`GBlocks User #${userNumber}`,restricted_admin:false},sessionCreated:true});
}