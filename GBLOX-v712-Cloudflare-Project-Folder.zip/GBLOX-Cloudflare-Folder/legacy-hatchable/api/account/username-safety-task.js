export const access = 'scheduler';
export const methods = ['POST'];

export default async function (req, res) {
  const userId = String(req.body?.userId || '');
  const action = String(req.body?.action || '');
  if (!userId || !['reset', 'unban', 'signup_check'].includes(action)) {
    return res.status(400).json({ error: 'Invalid safety task.' });
  }
  // Retired enforcement: older scheduled jobs may still fire, but must never
  // ban, rename, or terminate an account. Username validation happens at signup.
  return res.json({ ok: true, action, userId, enforcementDisabled: true });
}