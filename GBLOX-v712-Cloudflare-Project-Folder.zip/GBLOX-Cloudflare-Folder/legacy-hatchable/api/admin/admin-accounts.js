import { db } from "hatchable";
import { adminCaller, adminTokenHash } from "../../lib/admin-auth.js";
export const access = "public";
export const methods = ["GET","DELETE"];

function cookie(req){
  const h=String(req.headers?.cookie||"");
  return h.match(/(?:^|;\\s*)gblocks_admin_session=([^;]*)/)?.[1]||h.match(/(?:^|;\\s*)groblox_session=([^;]*)/)?.[1]||null;
}
export default async function(req,res){
  const caller=await adminCaller(req);
  if(!caller)return res.status(401).json({error:"Administrator sign-in required."});
  const current=await db.query("SELECT admin_id,username FROM admin_accounts WHERE admin_id=$1",[String(caller.admin_id||"")]);
  if(!current.rows[0])return res.status(403).json({error:"Only a signed-in administrator-panel account can manage administrator-panel accounts."});
  if(req.method==="GET"){
    const q=await db.query("SELECT admin_id,username,banned,terminated,created_at,updated_at FROM admin_accounts ORDER BY created_at ASC, username ASC");
    return res.json({accounts:q.rows.map(a=>({...a,is_current:String(a.admin_id)===String(current.rows[0].admin_id)})),current_admin_id:current.rows[0].admin_id});
  }
  if(req.method==="DELETE"){
    const target=String(req.body?.admin_id||"").trim();
    const confirmText=String(req.body?.confirmation||"");
    if(!target)return res.status(400).json({error:"Choose an administrator-panel account to delete."});
    if(target===String(current.rows[0].admin_id))return res.status(400).json({error:"You cannot delete the administrator account you are currently signed in with. Sign in to another admin account first."});
    if(confirmText!=="DELETE ADMIN ACCOUNT")return res.status(400).json({error:"Type DELETE ADMIN ACCOUNT to confirm."});
    const exists=await db.query("SELECT admin_id,username FROM admin_accounts WHERE admin_id=$1",[target]);
    if(!exists.rows[0])return res.status(404).json({error:"Administrator-panel account not found."});
    const count=await db.query("SELECT COUNT(*)::int AS count FROM admin_accounts");
    if(Number(count.rows[0]?.count||0)<=1)return res.status(400).json({error:"The last administrator-panel account cannot be deleted."});
    await db.query("DELETE FROM admin_sessions WHERE admin_id=$1",[target]);
    await db.query("DELETE FROM admin_accounts WHERE admin_id=$1",[target]);
    return res.json({ok:true,deleted_username:exists.rows[0].username,message:"Administrator-panel account deleted. Any sessions for it have been revoked."});
  }
  return res.status(405).json({error:"Method not allowed."});
}