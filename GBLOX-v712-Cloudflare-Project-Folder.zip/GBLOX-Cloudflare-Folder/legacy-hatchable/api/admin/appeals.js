import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { sendConfiguredDiscordEvent } from "../../lib/discord-webhooks.js";
async function logAppealDecision(appeal,target,admin,decision){await sendConfiguredDiscordEvent("APPEAL",{title:"GBLOCKS LOGS • APPEAL",color:0x1677ff,fields:[{name:"Username",value:String(target?.username||appeal?.username||"Unknown").slice(0,256)},{name:"User ID",value:"GBlocks User #"+String(appeal?.user_number||target?.user_id||appeal?.user_id||"Unknown")},{name:"Moderator",value:String(admin?.username||"Administrator").slice(0,256)},{name:"Status",value:String(decision||"REVIEWED").toUpperCase()},{name:"Appeal",value:String(appeal?.appeal_text||"No appeal text").slice(0,1000)}],timestamp:new Date().toISOString()}).catch(()=>{});}
export const access="public"; export const methods=["GET","POST"];
export default async function(req,res){
 const admin=await adminCaller(req); if(!admin)return res.status(403).json({error:"Administrator access required."});
 if(req.method==="GET"){
   const q=await db.query("SELECT id,user_id,username,ban_reason,appeal_text,status,decision,reviewed_by,reviewed_at,created_at FROM moderation_appeals ORDER BY CASE WHEN status='pending' THEN 0 ELSE 1 END, created_at DESC LIMIT 200");
   return res.json({appeals:q.rows});
 }
 const id=Number(req.body?.id), decision=String(req.body?.decision||"").toLowerCase();
 if(!Number.isSafeInteger(id)||!["approved","denied","closed","permanent_remove"].includes(decision))return res.status(400).json({error:"Invalid appeal action."});
 const a=(await db.query("SELECT * FROM moderation_appeals WHERE id=$1 LIMIT 1",[id])).rows[0];
 if(!a)return res.status(404).json({error:"Appeal not found."});
 if(a.status!=="pending"&&a.status!=="escalation_required")return res.status(409).json({error:"This appeal has already been decided."});
 const target=(await db.query("SELECT user_id,username,banned,terminated,ban_note,role,user_number FROM profiles WHERE user_id=$1 LIMIT 1",[a.user_id])).rows[0];
 if(!target)return res.status(404).json({error:"Account not found."});
 if(target.role==="administrator")return res.status(403).json({error:"Administrator player accounts require owner-level handling."});

 if(decision==="closed"){
   await db.query("UPDATE moderation_appeals SET status='closed',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",[admin.username,id]);
   await logAppealDecision(a,target,admin,"closed");
   return res.json({ok:true,id,decision:"closed",status:"closed"});
 }
 if(decision==="permanent_remove"){
   // Preserve username history as an audit trail, but detach the reusable
   // name from this deleted account. History must never restore privileges.
   await db.query("INSERT INTO username_history(username,user_id) SELECT p.username,p.user_id FROM profiles p WHERE p.user_id=$1 AND NOT EXISTS (SELECT 1 FROM username_history h WHERE h.user_id=p.user_id AND LOWER(h.username)=LOWER(p.username))",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM username_reservations WHERE reserved_for_user_id=$1",[a.user_id]);
   await db.query("DELETE FROM restricted_admin_badges WHERE username_key IN (LOWER($1),LOWER($2))",[target.username,a.username]).catch(()=>{});
   // Delete both representations for this exact user ID so a permanently
   // deleted account cannot leave a stale username in the other account store.
   await db.query("DELETE FROM account_sessions WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM account_credentials WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM gblocks_sessions WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM gblocks_credentials WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM gblocks_notifications WHERE user_id=$1 OR actor_user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM direct_messages WHERE sender_id=$1 OR receiver_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM moderation_appeals WHERE user_id=$1",[a.user_id]);
   // Preserve groups, but revoke every membership and group permission tied
   // to this immutable player ID before deleting the account.
   await db.query("DELETE FROM group_members WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM group_messages WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM follows WHERE follower_id=$1 OR following_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM user_follows WHERE follower_id=$1 OR following_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM premium_subscriptions WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM gobux_accounts WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM user_settings WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.query("DELETE FROM login_history WHERE user_id=$1",[a.user_id]).catch(()=>{});
   await db.transaction([
    {sql:"UPDATE groups SET owner_id='unknown-owner',claimed_owner_id=NULL WHERE owner_id=$1 OR claimed_owner_id=$1",params:[a.user_id]},
    {sql:"DELETE FROM gblocks_players WHERE user_id=$1",params:[a.user_id]},
    {sql:"DELETE FROM profiles WHERE user_id=$1",params:[a.user_id]}
   ]);
   await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",["PERMANENT_ACCOUNT_DELETED",a.user_id,a.username,String(admin.admin_id),admin.username,"Appeal panel permanently removed the account",JSON.stringify({appealId:id,userNumber:target.user_number??null})]);
   await logAppealDecision(a,target,admin,"permanent_remove");
   return res.json({ok:true,id,decision:"permanent_remove",status:"deleted",message:"Account permanently removed."});
 }

 if(decision==="approved" && target.banned){
   const until=new Date(Date.now()+86400000);
   await db.transaction([
    {sql:"UPDATE moderation_appeals SET status='decided',decision='approved',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:[admin.username,id]},
    {sql:"UPDATE profiles SET banned=true,terminated=false,temp_ban_until=$1,ban_note=$2,last_ban_duration_days=1 WHERE user_id=$3",params:[until,"Appeal approved by administrator; 1-day moderation remains.",a.user_id]}
   ]);
 }else if(decision==="approved" && target.terminated){
   const automaticUsername=String(target.ban_note||"").toLowerCase().includes("automatic username moderation");
   if(automaticUsername){
     const candidate=await db.query("SELECT 'GBLOCKS_User_'||p.user_number::text AS username FROM profiles p WHERE p.user_id=$1 AND p.user_number IS NOT NULL AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.user_id<>p.user_id AND lower(x.username)=lower('GBLOCKS_User_'||p.user_number::text)) LIMIT 1",[a.user_id]);
     if(!candidate.rows[0])return res.status(409).json({error:"Could not generate a safe replacement username."});
     const newUsername=candidate.rows[0].username;
     const oldUsername=target.username;
     await db.transaction([
      {sql:"UPDATE moderation_appeals SET status='decided',decision='approved',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:[admin.username,id]},
      {sql:"INSERT INTO username_reservations(username,reserved_for_user_id,reason) VALUES($1,$2,$3) ON CONFLICT(username) DO UPDATE SET reserved_for_user_id=EXCLUDED.reserved_for_user_id,reason=EXCLUDED.reason",params:[oldUsername,a.user_id,"inappropriate_username_permanent_reservation"]},
      {sql:"DELETE FROM username_history WHERE user_id=$1 AND lower(username)=lower($2)",params:[a.user_id,oldUsername]},
      {sql:"UPDATE profiles SET username=$1,display_name=$1,banned=false,terminated=false,temp_ban_until=NULL,ban_note='',verified=false WHERE user_id=$2",params:[newUsername,a.user_id]},
      // account_credentials stores password hashes only; username lives in profiles.
      {sql:"UPDATE gblocks_credentials SET username=$1 WHERE user_id=$2",params:[newUsername,a.user_id]}
     ]);
     return res.json({ok:true,id,decision,status:"decided",action:"UNBAN_AND_RENAME",oldUsername,newUsername,oldUsernameReserved:true});
   }
   await db.transaction([
    {sql:"UPDATE moderation_appeals SET status='decided',decision='approved',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:[admin.username,id]},
    {sql:"UPDATE profiles SET banned=false,terminated=false,temp_ban_until=NULL,ban_note='' WHERE user_id=$1",params:[a.user_id]}
   ]);
 }else{
   await db.transaction([
    {sql:"UPDATE moderation_appeals SET status='decided',decision='denied',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:[admin.username,id]}
   ]);
 }
 await logAppealDecision(a,target,admin,decision);
 return res.json({ok:true,id,decision,status:"decided"});
}