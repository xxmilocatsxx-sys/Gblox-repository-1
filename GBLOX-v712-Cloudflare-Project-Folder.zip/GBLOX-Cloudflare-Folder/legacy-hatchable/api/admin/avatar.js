import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access = "public";
export const methods = ["GET","POST"];
export default async function(req,res) {
 const administrator=await adminCaller(req);
 if(!administrator) return res.status(401).json({error:"Administrator username and password required.",code:"NOT_SIGNED_IN"});
 if(req.method==="GET") {
  const q=String(req.query?.q||"").trim();
  const args=[]; let sql="SELECT user_id,user_number,username,display_name,avatar FROM profiles";
  if(q){sql+=" WHERE username ILIKE $1 OR display_name ILIKE $1";args.push("%"+q+"%");}
  sql+=" ORDER BY user_number ASC,created_at ASC LIMIT 250";
  const {rows}=await db.query(sql,args);
  return res.json({players:rows});
 }
 const userId=String(req.body?.user_id||"").trim();
 let imageUrl=String(req.body?.image_url||"").trim();
 if(!userId) return res.status(400).json({error:"Choose a player account."});
 if(imageUrl.length>1400000) return res.status(413).json({error:"Image is too large. Choose an image under 900 KB."});
 if(imageUrl && !(/^https:\/\//i.test(imageUrl)||/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/i.test(imageUrl))) return res.status(400).json({error:"Use an HTTPS image URL or upload a PNG, JPG, WEBP, or GIF image."});
 const found=await db.query("SELECT user_id,avatar FROM profiles WHERE user_id=$1 LIMIT 1",[userId]);
 if(!found.rows[0]) return res.status(404).json({error:"Player account not found."});
 const current=found.rows[0].avatar && typeof found.rows[0].avatar==="object" ? found.rows[0].avatar : {};
 const avatar=imageUrl ? {...current,image_url:imageUrl,source:"admin avatar updater"} : {...current,image_url:null,source:null};
 await db.query("UPDATE profiles SET avatar=$1::jsonb WHERE user_id=$2",[JSON.stringify(avatar),userId]);
 return res.json({ok:true,message:imageUrl?"Player avatar updated.":"Player avatar reset to the default.",user_id:userId,avatar});
}