import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { checkBio } from "../../lib/moderation-policy.js";

export const access = "public";
export const methods = ["GET", "POST"];

const DELETED = "[Content Deleted]";

async function requireAdmin(req, res) {
  const admin = await adminCaller(req);
  if (!admin) {
    res.status(401).json({ error: "Administrator login required.", code: "NOT_SIGNED_IN" });
    return null;
  }
  return admin;
}

function cleanStatus(value) {
  return ["all", "not_reviewed", "reviewed", "content_deleted"].includes(value) ? value : "all";
}

export default async function (req, res) {
  const admin = await requireAdmin(req, res);
  if (!admin) return;

  if (req.method === "GET") {
    const status = cleanStatus(String(req.query?.status || "all"));
    const search = String(req.query?.search || "").trim().slice(0, 120);
    const limit = Math.min(Math.max(Number.parseInt(req.query?.limit, 10) || 50, 1), 100);
    const cursor = String(req.query?.cursor || "").trim();
    const params = [];
    const where = [];

    if (status !== "all") {
      params.push(status);
      where.push("p.bio_moderation_status = $" + params.length);
    }
    if (search) {
      params.push("%" + search + "%");
      where.push("(p.username ILIKE $" + params.length + " OR p.user_id ILIKE $" + params.length + " OR p.bio ILIKE $" + params.length + ")");
    }
    if (cursor) {
      params.push(cursor);
      where.push("p.user_id > $" + params.length);
    }

    params.push(limit + 1);
    const sql = "SELECT p.user_id,p.username,p.display_name,p.bio,p.bio_moderation_status,p.bio_moderation_last_reviewed_at,p.bio_deleted_by_moderation " +
      "FROM profiles p " + (where.length ? "WHERE " + where.join(" AND ") : "") +
      " ORDER BY p.user_id ASC LIMIT $" + params.length;
    const result = await db.query(sql, params);
    const rows = result.rows.slice(0, limit).map(row => ({
      user_id: String(row.user_id),
      username: row.username,
      display_name: row.display_name,
      bio: row.bio,
      moderation_status: row.bio_moderation_status || (row.bio_deleted_by_moderation ? "content_deleted" : "not_reviewed"),
      last_moderation_time: row.bio_moderation_last_reviewed_at,
      content_deleted: Boolean(row.bio_deleted_by_moderation) || row.bio_moderation_status === "content_deleted"
    }));
    return res.json({ ok: true, bios: rows, next_cursor: result.rows.length > limit ? rows[rows.length - 1]?.user_id || null : null });
  }

  const body = req.body && typeof req.body === "object" ? req.body : {};
  const action = String(body.action || "");

  if (action === "check_all_players") {
    const batchSize = 100;
    let lastUserId = "";
    let scanned = 0;
    let deleted = 0;
    let reviewed = 0;

    while (true) {
      const batch = await db.query(
        "SELECT user_id,username,bio FROM profiles WHERE user_id > $1 AND COALESCE(TRIM(bio),'') <> '' AND bio_deleted_by_moderation=false ORDER BY user_id ASC LIMIT $2",
        [lastUserId, batchSize]
      );
      if (!batch.rows.length) break;

      for (const row of batch.rows) {
        scanned++;
        const result = checkBio(row.bio);
        if (!result.flagged) {
          await db.query(
            "UPDATE profiles SET bio_moderation_status='reviewed',bio_moderation_last_reviewed_at=NOW() WHERE user_id=$1 AND bio_deleted_by_moderation=false",
            [row.user_id]
          );
          reviewed++;
          continue;
        }

        await db.transaction([
          { sql: "INSERT INTO bio_moderation_history(user_id,username,action,original_bio,resulting_bio,actor_admin_id,actor_admin_username,reason) VALUES($1,$2,'AUTOMATIC_DELETE',$3,$4,$5,$6,'Admin started All Players bio moderation check.')", params: [row.user_id,row.username,row.bio,DELETED,admin.admin_id,admin.username] },
          { sql: "UPDATE profiles SET bio=$1,bio_moderation_status='content_deleted',bio_moderation_last_reviewed_at=NOW(),bio_deleted_by_moderation=true WHERE user_id=$2 AND bio_deleted_by_moderation=false", params: [DELETED,row.user_id] },
          { sql: "UPDATE gblocks_players SET bio=$1,bio_deleted_by_moderation=true WHERE user_id=$2", params: [DELETED,row.user_id] }
        ]);
        deleted++;
      }

      lastUserId = String(batch.rows[batch.rows.length - 1].user_id);
      if (batch.rows.length < batchSize) break;
    }

    return res.json({
      ok: true,
      action,
      scanned,
      reviewed,
      deleted,
      message: "All GBlocks player bios were checked with the server-side bio moderation rules. No AI provider was used and no accounts were banned or terminated."
    });
  }

  const userId = String(body.user_id || "").trim();
  if (!userId || !["mark_reviewed", "delete", "restore"].includes(action)) {
    return res.status(400).json({ error: "Invalid bio moderation request." });
  }

  const current = await db.query("SELECT user_id,username,bio,bio_moderation_status,bio_deleted_by_moderation FROM profiles WHERE user_id=$1 LIMIT 1", [userId]);
  const profile = current.rows[0];
  if (!profile) return res.status(404).json({ error: "GBlocks player profile not found." });

  if (action === "mark_reviewed") {
    await db.transaction([
      { sql: "UPDATE profiles SET bio_moderation_status='reviewed',bio_moderation_last_reviewed_at=NOW(),bio_deleted_by_moderation=false WHERE user_id=$1", params: [userId] },
      { sql: "UPDATE gblocks_players SET bio_deleted_by_moderation=false WHERE user_id=$1", params: [userId] },
      { sql: "INSERT INTO bio_moderation_history(user_id,username,action,original_bio,resulting_bio,actor_admin_id,actor_admin_username,reason) VALUES($1,$2,'MARK_REVIEWED',$3,$3,$4,$5,'Admin marked bio as reviewed.')", params: [userId, profile.username, profile.bio, admin.admin_id, admin.username] }
    ]);
    return res.json({ ok: true, action, moderation_status: "reviewed" });
  }

  if (action === "delete") {
    if (profile.bio === DELETED && profile.bio_deleted_by_moderation) {
      return res.json({ ok: true, action, moderation_status: "content_deleted", message: "Bio is already deleted." });
    }
    await db.transaction([
      { sql: "INSERT INTO bio_moderation_history(user_id,username,action,original_bio,resulting_bio,actor_admin_id,actor_admin_username,reason) VALUES($1,$2,'DELETE',$3,$4,$5,$6,$7)", params: [userId, profile.username, profile.bio, DELETED, admin.admin_id, admin.username, String(body.reason || "Admin deleted bio.").slice(0, 500)] },
      { sql: "UPDATE profiles SET bio=$1,bio_moderation_status='content_deleted',bio_moderation_last_reviewed_at=NOW(),bio_deleted_by_moderation=true WHERE user_id=$2", params: [DELETED, userId] },
      { sql: "UPDATE gblocks_players SET bio=$1,bio_deleted_by_moderation=true WHERE user_id=$2", params: [DELETED, userId] }
    ]);
    return res.json({ ok: true, action, moderation_status: "content_deleted", bio: DELETED });
  }

  const history = await db.query("SELECT id,original_bio,resulting_bio,action,created_at FROM bio_moderation_history WHERE user_id=$1 AND action IN ('DELETE','AUTOMATIC_DELETE') ORDER BY created_at DESC LIMIT 1", [userId]);
  const previous = history.rows[0];
  if (!previous || !previous.original_bio || previous.original_bio === DELETED || checkBio(previous.original_bio).flagged) {
    return res.status(409).json({ error: "The previous bio is not available or still violates the current GBlocks bio rules." });
  }

  await db.transaction([
    { sql: "UPDATE profiles SET bio=$1,bio_moderation_status='reviewed',bio_moderation_last_reviewed_at=NOW(),bio_deleted_by_moderation=false WHERE user_id=$2", params: [previous.original_bio, userId] },
    { sql: "UPDATE gblocks_players SET bio=$1,bio_deleted_by_moderation=false WHERE user_id=$2", params: [previous.original_bio, userId] },
    { sql: "INSERT INTO bio_moderation_history(user_id,username,action,original_bio,resulting_bio,actor_admin_id,actor_admin_username,reason) VALUES($1,$2,'RESTORE',$3,$3,$4,$5,'Admin explicitly restored the previous bio.')", params: [userId, profile.username, previous.original_bio, admin.admin_id, admin.username] }
  ]);
  return res.json({ ok: true, action, moderation_status: "reviewed", bio: previous.original_bio });
}