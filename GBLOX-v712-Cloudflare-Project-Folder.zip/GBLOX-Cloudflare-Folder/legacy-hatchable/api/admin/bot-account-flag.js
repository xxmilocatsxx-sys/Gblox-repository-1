import { db } from "hatchable";
import { hashText, cookieValue } from "../../lib/discord.js";
export const access="public";
export const methods=["POST"];
async function admin(req){
 const raw=cookieValue(req,"gblocks_admin_session")||cookieValue(req,"groblox_session");
 if(!raw)return null;
 const q=await db.query("SELECT a.admin_id,a.username FROM admin_sessions s JOIN admin_accounts a ON a.admin_id=s.admin_id WHERE s.token_hash=$1 AND s.expires_at>NOW() AND a.banned=false AND a.terminated=false LIMIT 1",[await hashText(raw)]);
 return q.rows[0]||null;
}
export default async function(req,res){
 const actor=await admin(req);
 if(!actor)return res.status(401).json({error:"Administrator sign-in required."});
 const origin=String(req.headers?.origin||"");
 if(origin&&origin!=="https://gblocks.hatchable.site")return res.status(403).json({error:"Cross-origin request blocked."});
 const userId=String(req.body?.user_id||"").trim();
 const username=String(req.body?.username||"").trim();
 const enabled=req.body?.is_bot;
 if(typeof enabled!=="boolean")return res.status(400).json({error:"is_bot must be true or false."});
 if(!userId&&!username)return res.status(400).json({error:"Provide a user_id or username."});
 let found=userId ? await db.query("SELECT user_id,username,is_bot FROM profiles WHERE user_id=$1 LIMIT 1",[userId]) : {rows:[]};
 if(!found.rows[0]&&username)found=await db.query("SELECT user_id,username,is_bot FROM profiles WHERE LOWER(username)=LOWER($1) LIMIT 1",[username]);
 const p=found.rows[0];
 if(!p)return res.status(404).json({error:"GBLOX player not found."});
 await db.query("UPDATE profiles SET is_bot=$1 WHERE user_id=$2",[enabled,p.user_id]);
 await db.query("UPDATE gblocks_players SET is_bot=$1,updated_at=NOW() WHERE user_id=$2",[enabled,p.user_id]).catch(()=>{});
 await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",[enabled?"discord_bot_exemption_enabled":"discord_bot_exemption_disabled",p.user_id,p.username,actor.admin_id,actor.username,enabled?"Administrator marked account as a system/bot account":"Administrator removed system/bot exemption",JSON.stringify({is_bot:enabled})]);
 return res.json({ok:true,user_id:p.user_id,username:p.username,is_bot:enabled,discord_exempt:enabled});
}