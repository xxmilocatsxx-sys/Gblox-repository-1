import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access = "public";
export const methods = ["POST"];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function hashPassword(password,salt) {
  const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);
  return b64(await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:120000,hash:"SHA-256"},key,256));
}
function randomToken(n=32) { const b=new Uint8Array(n); crypto.getRandomValues(b); return b64(b); }
function makeUsername(prefix,n) { return prefix + String(n).padStart(4,"0"); }
async function queryWithBackoff(sql, params = []) {
  let lastError;
  for (let retry = 0; retry < 6; retry++) {
    try { return await db.query(sql, params); }
    catch (e) {
      lastError = e;
      const code = String(e?.code || e?.message || "").toLowerCase();
      const rateLimited = code.includes("rate_limited") || code.includes("rate limited") || code.includes("too many requests") || code.includes("429");
      if (!rateLimited || retry === 5) throw e;
      await new Promise(resolve => setTimeout(resolve, Math.min(30000, 1500 * Math.pow(2, retry))));
    }
  }
  throw lastError;
}

export default async function(req,res) {
  const admin=await adminCaller(req);
  if(!admin) return res.status(401).json({error:"Administrator login required."});
  const origin=String(req.headers?.origin||"");
  if(origin && origin!=="https://gblocks.hatchable.site") return res.status(403).json({error:"Cross-origin request blocked."});
  const body=req.body||{};
  const count=Number(body.count);
  const prefix=String(body.prefix||"GBLOXBot").trim();
  const requestedStart=Number(body.startAt);
  const startAt=Number.isSafeInteger(requestedStart)&&requestedStart>0?requestedStart:1;
  if(!Number.isInteger(count)||count<1||count>50) return res.status(400).json({error:"Choose a batch size from 1 to 50."});
  if(!/^[A-Za-z][A-Za-z0-9]{2,14}$/.test(prefix)) return res.status(400).json({error:"Prefix must be 3–15 letters/numbers, start with a letter, and contain no underscores."});
  const made=[];
  let attempts=0;
  while(made.length<count && attempts<2000) {
    attempts++;
    // Continue from the caller's durable candidate cursor so large jobs do not rescan the same names each request.
    const candidate=makeUsername(prefix,startAt+attempts-1);
    const taken=await queryWithBackoff("SELECT 1 FROM profiles WHERE LOWER(username)=LOWER($1) UNION ALL SELECT 1 FROM gblocks_players WHERE LOWER(username)=LOWER($1) UNION ALL SELECT 1 FROM username_reservations WHERE LOWER(username)=LOWER($1) LIMIT 1",[candidate]);
    if(taken.rows.length) continue;
    const historical=await queryWithBackoff("SELECT 1 FROM username_history WHERE LOWER(username)=LOWER($1) LIMIT 1",[candidate]);
    if(historical.rows.length) continue;
    const userId=crypto.randomUUID();
    const numberRow=await queryWithBackoff("UPDATE gblocks_user_number_sequence SET next_number=next_number+1 WHERE id=1 RETURNING next_number-1 AS user_number");
    if(!numberRow.rows[0]) return res.status(500).json({error:"Account numbering is unavailable. Batch stopped safely.",created:made,nextStartAt:startAt+attempts});
    const userNumber=Number(numberRow.rows[0].user_number);
    const gender=(made.length%2===0)?"male":"female";
    const salt=new Uint8Array(16); crypto.getRandomValues(salt);
    const saltText=b64(salt);
    const passwordHash=await hashPassword(randomToken(24),salt);
    const avatar=JSON.stringify({body:"classic",face:"⌣",outfit:"default-2021",gender});
    const writes=[
      {sql:"INSERT INTO profiles (user_id,username,display_name,bio,avatar,user_number,gender,role,is_bot) VALUES ($1,$2,$2,'GBLOX system bot account',$3::jsonb,$4,$5,'bot',true)",params:[userId,candidate,avatar,userNumber,gender]},
      {sql:"INSERT INTO account_credentials (user_id,password_salt,password_hash) VALUES ($1,$2,$3)",params:[userId,saltText,passwordHash]},
      {sql:"INSERT INTO user_settings (user_id,gender,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (user_id) DO UPDATE SET gender=EXCLUDED.gender,updated_at=NOW()",params:[userId,gender]},
      {sql:"INSERT INTO gblocks_players (user_id,username,display_name,bio,avatar,gender,is_bot) VALUES ($1,$2,$2,'GBLOX system bot account',$3::jsonb,$4,true)",params:[userId,candidate,avatar,gender]},
      {sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,50,NULL,false)",params:[userId]},
      {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ('bot_account_created',$1,$2,$3,$4,'Admin-created GBLOX bot', $5::jsonb)",params:[userId,candidate,String(admin.user_id||admin.admin_id||""),String(admin.username||""),JSON.stringify({is_bot:true,user_number:userNumber,batch_prefix:prefix})]}
    ];
    let committed=false;
    let lastError=null;
    for(let retry=0;retry<5;retry++) {
      try {
        await db.transaction(writes);
        committed=true;
        break;
      } catch(e) {
        lastError=e;
        const code=String(e?.code||e?.message||"").toLowerCase();
        const rateLimited=code.includes("rate_limited")||code.includes("rate limited")||code.includes("too many requests")||code.includes("429");
        if(!rateLimited||retry===4) break;
        // Use exponential backoff instead of retrying into the same database throttle window.
        // Keep the same candidate account during retries; do not advance the username cursor.
        await new Promise(resolve=>setTimeout(resolve,1000*Math.pow(2,retry)));
      }
    }
    if(!committed) {
      console.error("Bot batch item failed safely.",lastError?.code||lastError?.message||"");
      const code=String(lastError?.code||lastError?.message||"").toLowerCase();
      const rateLimited=code.includes("rate_limited")||code.includes("rate limited")||code.includes("too many requests")||code.includes("429");
      return res.status(rateLimited?429:409).json({error:rateLimited?"GBLOX database is temporarily rate-limiting account creation. The batch paused safely; wait a minute before retrying. Successfully created accounts are listed.":"Batch stopped after a database conflict. Successfully created accounts are listed; no partial rows were committed for the failed account.",created:made,nextStartAt:startAt+attempts});
    }
    made.push({username:candidate,user_number:userNumber});
    await new Promise(resolve=>setTimeout(resolve,150));
  }
  return res.json({ok:true,requested:count,createdCount:made.length,created:made,remainingInThisBatch:count-made.length,nextStartAt:startAt+attempts});
}