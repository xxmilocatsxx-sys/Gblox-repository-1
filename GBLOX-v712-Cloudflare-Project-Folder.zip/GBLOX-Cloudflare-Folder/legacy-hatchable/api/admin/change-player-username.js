import { db } from 'hatchable';
import { adminCaller } from '../../lib/admin-auth.js';
import { checkUsername } from '../../lib/username-policy.js';

export const access='public';
export const methods=['POST'];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:'Administrator login required.',code:'NOT_SIGNED_IN'});

  const userId=String(req.body?.currentUserId||'').trim();
  const currentUsername=String(req.body?.currentUsername||'').trim();
  const newUsername=String(req.body?.newUsername||'').trim();
  if(!userId&&!currentUsername)return res.status(400).json({error:'Select the GBlocks player account to change.'});
  if(!/^[A-Za-z0-9_]{3,24}$/.test(newUsername))return res.status(400).json({error:'Username must be 3–24 characters using letters, numbers, or underscores.'});
  if((newUsername.match(/_/g)||[]).length>1)return res.status(400).json({error:'Usernames can contain at most one underscore.'});
  const policy=checkUsername(newUsername);
  if(policy.flagged)return res.status(400).json({error:'That username is not allowed: '+policy.reason});

  const found=userId
    ? await db.query('SELECT user_id,username,display_name FROM profiles WHERE user_id=$1',[userId])
    : await db.query('SELECT user_id,username,display_name FROM profiles WHERE LOWER(username)=LOWER($1) ORDER BY user_id LIMIT 1',[currentUsername]);
  if(!found.rows[0])return res.status(404).json({error:'GBlocks player account not found.'});
  const account=found.rows[0],oldUsername=String(account.username||''),targetId=String(account.user_id);
  if(newUsername.toLowerCase()===oldUsername.toLowerCase())return res.status(400).json({error:'That is already the username.'});

  // Never swap identities: a username already owned by another player is a conflict.
  const ownerResult=await db.query('SELECT user_id,username FROM profiles WHERE LOWER(username)=LOWER($1) AND user_id<>$2 LIMIT 1',[newUsername,targetId]);
  if(ownerResult.rows[0])return res.status(409).json({error:'That username is already used by @'+ownerResult.rows[0].username+'. Choose a different username; no accounts were changed.',code:'USERNAME_TAKEN'});

  const reservationResult=await db.query('SELECT reserved_for_user_id FROM username_reservations WHERE LOWER(username)=LOWER($1) LIMIT 1',[newUsername]);
  if(reservationResult.rows[0]&&String(reservationResult.rows[0].reserved_for_user_id)!==targetId){
    return res.status(409).json({error:'That username is reserved for another account and cannot be assigned.',code:'USERNAME_RESERVED'});
  }
  const oldReservation=await db.query('SELECT reserved_for_user_id FROM username_reservations WHERE LOWER(username)=LOWER($1) LIMIT 1',[oldUsername]);
  if(oldReservation.rows[0]&&String(oldReservation.rows[0].reserved_for_user_id)!==targetId){
    return res.status(409).json({error:'The current username has a reservation conflict. No changes were made; resolve the reservation before retrying.',code:'OLD_USERNAME_RESERVATION_CONFLICT'});
  }

  const history=(await db.query('SELECT username FROM username_history WHERE user_id=$1 ORDER BY changed_at ASC,id ASC',[targetId])).rows.map(r=>r.username);
  const temporary='admin_tmp_'+targetId.replace(/[^A-Za-z0-9]/g,'').slice(-10)+'_'+Date.now().toString(36);
  try{
    await db.transaction([
      {sql:'UPDATE profiles SET username=$1 WHERE user_id=$2',params:[temporary,targetId]},
      {sql:'UPDATE gblocks_players SET username=$1,updated_at=NOW() WHERE user_id=$2',params:[temporary,targetId]},
      {sql:'UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2',params:[temporary,targetId]},
      {sql:'INSERT INTO username_history(username,user_id) VALUES($1,$2)',params:[oldUsername,targetId]},
      {sql:'DELETE FROM username_reservations WHERE LOWER(username)=LOWER($1) AND reserved_for_user_id=$2',params:[oldUsername,targetId]},
      {sql:"INSERT INTO username_reservations(username,reserved_for_user_id,reason) VALUES($1,$2,'username_history') ON CONFLICT(username) DO NOTHING",params:[oldUsername,targetId]},
      {sql:'UPDATE profiles SET username=$1 WHERE user_id=$2',params:[newUsername,targetId]},
      {sql:'UPDATE gblocks_players SET username=$1,updated_at=NOW() WHERE user_id=$2',params:[newUsername,targetId]},
      {sql:'UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2',params:[newUsername,targetId]},
      {sql:'DELETE FROM username_reservations WHERE LOWER(username)=LOWER($1) AND reserved_for_user_id=$2',params:[newUsername,targetId]},
      {sql:'INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)',params:['ADMIN_USERNAME_CHANGE',targetId,newUsername,String(admin.admin_id||admin.user_id||''),String(admin.username||'Administrator'),'Administrator changed the GBlocks username',JSON.stringify({oldUsername,newUsername,displayNamePreserved:account.display_name})]}
    ]);
  }catch(e){
    console.error('Admin username change failed:',e?.message||e);
    return res.status(500).json({error:'Username change failed. No successful change was confirmed; check the account before retrying.'});
  }
  return res.json({ok:true,userId:targetId,oldUsername,newUsername,displayName:account.display_name,history:[...history,oldUsername],message:'Changed @'+oldUsername+' to @'+newUsername+'. Display name and account data were preserved; the old username is reserved for this same account.'});
}