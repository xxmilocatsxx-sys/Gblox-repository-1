import { storage, db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import crypto from "node:crypto";
export const access="public";
export const methods=["GET","POST","DELETE"];
const allowed=new Set(["image/png","image/jpeg","image/webp","image/gif"]);
const validGender=g=>["female","male","default"].includes(String(g||"").toLowerCase())?String(g).toLowerCase():"default";
async function avatarMap(){
 const r=await db.query("SELECT gender,filename,storage_key,content_type,bytes,updated_at FROM default_avatar_assets");
 const out={female:null,male:null,default:null};
 for(const item of r.rows){try{out[item.gender]={filename:item.filename,content_type:item.content_type,bytes:Number(item.bytes||0),updated_at:item.updated_at,url:await storage.url(item.storage_key)}}catch(err){console.warn("Skipping missing managed default avatar asset",item.gender,item.storage_key)}}
 // Backward-compatible fallback if the migration has not yet copied the old singleton.
 if(!out.default){const old=(await db.query("SELECT filename,storage_key,content_type,bytes,updated_at FROM default_avatar_asset WHERE id=1")).rows[0];if(old){try{out.default={...old,bytes:Number(old.bytes||0),url:await storage.url(old.storage_key)}}catch(err){console.warn("Legacy default avatar file is missing; using built-in fallback",old.storage_key)}}}
 return out;
}
export default async function(req,res){
 const caller=await adminCaller(req);
 if(!caller)return res.status(401).json({error:"Administrator username and password required.",code:"NOT_SIGNED_IN"});
 try{
  if(req.method==="GET"){const avatars=await avatarMap();return res.json({avatars,fallback:"/avatar-default.svg"});}
  const gender=validGender(req.query?.gender||req.body?.gender);
  if(req.method==="DELETE"){
   const old=await db.query("SELECT storage_key FROM default_avatar_assets WHERE gender=$1",[gender]);
   if(old.rows[0]?.storage_key)await storage.del(old.rows[0].storage_key);
   await db.query("DELETE FROM default_avatar_assets WHERE gender=$1",[gender]);
   return res.json({ok:true,message:"The "+gender+" default avatar was reset. Player custom avatars are unchanged."});
  }
  const file=(req.files||[]).find(f=>f.field==="file");
  if(!file)return res.status(400).json({error:"Choose an avatar image to upload."});
  if(file.buffer.length>900*1024)return res.status(413).json({error:"Image must be 900 KB or smaller."});
  if(!allowed.has(file.contentType))return res.status(415).json({error:"Use PNG, JPG, WEBP, or GIF."});
  const b=file.buffer;
  const valid=(file.contentType==="image/png"&&b.length>=8&&b[0]===137&&b[1]===80&&b[2]===78&&b[3]===71)||(file.contentType==="image/jpeg"&&b.length>=3&&b[0]===255&&b[1]===216&&b[2]===255)||(file.contentType==="image/gif"&&b.length>=6&&String.fromCharCode(...b.slice(0,3))==="GIF")||(file.contentType==="image/webp"&&b.length>=12&&String.fromCharCode(...b.slice(0,4))==="RIFF"&&String.fromCharCode(...b.slice(8,12))==="WEBP");
  if(!valid)return res.status(415).json({error:"The file contents do not match the selected image type."});
  const ext={"image/png":"png","image/jpeg":"jpg","image/webp":"webp","image/gif":"gif"}[file.contentType];
  const key="images/default-avatar/"+gender+"/"+crypto.randomUUID()+"."+ext;
  await storage.put(key,b,file.contentType);
  const old=await db.query("SELECT storage_key FROM default_avatar_assets WHERE gender=$1",[gender]);
  const filename=file.filename||("default-avatar-"+gender+"."+ext);
  await db.query("INSERT INTO default_avatar_assets(gender,filename,storage_key,content_type,bytes,updated_at) VALUES($1,$2,$3,$4,$5,now()) ON CONFLICT(gender) DO UPDATE SET filename=EXCLUDED.filename,storage_key=EXCLUDED.storage_key,content_type=EXCLUDED.content_type,bytes=EXCLUDED.bytes,updated_at=now()",[gender,filename,key,file.contentType,b.length]);
  if(old.rows[0]?.storage_key)await storage.del(old.rows[0].storage_key);
  return res.json({ok:true,message:"The "+gender+" default avatar was updated. Custom player avatars are unchanged.",avatar:{gender,filename,content_type:file.contentType,bytes:b.length,url:await storage.url(key)}});
 }catch(e){console.error("default-avatar error",e);return res.status(500).json({error:"Default avatar update failed. Please try again."});}
}