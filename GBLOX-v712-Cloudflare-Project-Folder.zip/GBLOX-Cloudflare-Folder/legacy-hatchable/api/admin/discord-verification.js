import { db } from "hatchable";
import { hashText, cookieValue, syncVerifiedRole, removeVerifiedRole } from "../../lib/discord.js";
export const access="public";
export const methods=["GET","POST"];
async function admin(req){
 const raw=cookieValue(req,"gblocks_admin_session")||cookieValue(req,"groblox_session");if(!raw)return null;
 const q=await db.query("SELECT a.admin_id,a.username FROM admin_sessions s JOIN admin_accounts a ON a.admin_id=s.admin_id WHERE s.token_hash=$1 AND s.expires_at>NOW() AND a.banned=false AND a.terminated=false LIMIT 1",[await hashText(raw)]);
 return q.rows[0]||null;
}
export default async function(req,res){
 const actor=await admin(req);if(!actor)return res.status(401).json({error:"Administrator sign-in required."});
 if(req.method==="GET"){
  const q=await db.query("SELECT l.discord_user_id,l.discord_username,l.user_id,p.username,p.display_name,l.verified_at,l.linked_at,l.role_status,l.role_error,l.revoked_at FROM gblox_discord_links l LEFT JOIN profiles p ON p.user_id=l.user_id ORDER BY l.linked_at DESC LIMIT 200");
  const limits=await db.query("SELECT COUNT(*)::int AS attempts,COUNT(DISTINCT ip_hash)::int AS networks FROM gblox_signup_rate_limits WHERE created_at>NOW()-INTERVAL '24 hours'");
  return res.json({links:q.rows,signup_rate_limits:limits.rows[0]||{attempts:0,networks:0}});
 }
 const origin=String(req.headers?.origin||"");if(origin&&origin!=="https://gblocks.hatchable.site")return res.status(403).json({error:"Cross-origin request blocked."});
 const action=String(req.body?.action||""),discordId=String(req.body?.discord_user_id||"");
 if(!/^\d{17,20}$/.test(discordId))return res.status(400).json({error:"A valid Discord user ID is required."});
 const link=await db.query("SELECT l.user_id,l.revoked_at,p.username FROM gblox_discord_links l LEFT JOIN profiles p ON p.user_id=l.user_id WHERE l.discord_user_id=$1",[discordId]);
 if(!link.rows[0])return res.status(404).json({error:"Discord link not found."});
 if(action==="retry-role"&&link.rows[0].revoked_at)return res.status(409).json({error:"This Discord verification has been revoked and cannot be retried."});
 if(action==="retry-role"){
  const result=await syncVerifiedRole(discordId);
  await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES('discord_role_retry',$1,$2,$3,$4,'Administrator retried Discord role assignment',$5::jsonb)",[link.rows[0].user_id,link.rows[0].username,actor.admin_id,actor.username,JSON.stringify({discord_user_id:discordId,status:result.status})]);
  return res.json({ok:true,role_status:result.status});
 }
 if(action==="revoke"){
  const removed=await removeVerifiedRole(discordId);
  await db.query("UPDATE gblox_discord_links SET revoked_at=COALESCE(revoked_at,NOW()),role_status='revoked',role_error=$2 WHERE discord_user_id=$1",[discordId,removed.status==="failed"?removed.error:null]);
  await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES('discord_verification_revoked',$1,$2,$3,$4,'Administrator revoked Discord verification',$5::jsonb)",[link.rows[0].user_id,link.rows[0].username,actor.admin_id,actor.username,JSON.stringify({discord_user_id:discordId})]);
  return res.json({ok:true,revoked:true});
 }
 return res.status(400).json({error:"Unsupported administrator action."});
}