import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { ALLOWED_EVENTS, validDiscordWebhook, maskWebhook } from "../../lib/discord-webhooks.js";
export const access = "public";
export const methods = ["GET","POST"];
const events = [...ALLOWED_EVENTS];
function cleanEvents(value) { const list = Array.isArray(value) ? value : []; return [...new Set(list.map(x => String(x).toUpperCase()).filter(x => ALLOWED_EVENTS.has(x)))]; }
export default async function(req,res) {
 const admin = await adminCaller(req);
 if (!admin || admin.is_bot) return res.status(403).json({error:"Administrator account access required."});
 if (req.method === "GET") {
  const q = await db.query("SELECT id,name,webhook_url,events,enabled,created_by,created_at,updated_at FROM gblocks_discord_webhooks ORDER BY created_at DESC,id DESC");
  return res.json({webhooks:q.rows.map(x=>({id:x.id,name:x.name,events:x.events,enabled:x.enabled,created_by:x.created_by,created_at:x.created_at,updated_at:x.updated_at,masked_url:maskWebhook(x.webhook_url)})),events});
 }
 const body = req.body || {}; const action = String(body.action || "save").toLowerCase(); const id = Number(body.id);
 if (action === "delete") {
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({error:"Choose a valid webhook."});
  const q=await db.query("DELETE FROM gblocks_discord_webhooks WHERE id=$1 RETURNING id",[id]);
  if(!q.rows[0]) return res.status(404).json({error:"Webhook not found."});
  return res.json({ok:true,deleted:true,id});
 }
 if (action === "toggle") {
  if (!Number.isSafeInteger(id) || id < 1 || typeof body.enabled !== "boolean") return res.status(400).json({error:"Invalid webhook state."});
  const q=await db.query("UPDATE gblocks_discord_webhooks SET enabled=$1,updated_at=NOW() WHERE id=$2 RETURNING id,enabled",[body.enabled,id]);
  if(!q.rows[0]) return res.status(404).json({error:"Webhook not found."});
  return res.json({ok:true,...q.rows[0]});
 }
 if (action === "test") {
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({error:"Choose a saved webhook to test."});
  const q=await db.query("SELECT id,name,webhook_url FROM gblocks_discord_webhooks WHERE id=$1",[id]); const hook=q.rows[0];
  if(!hook) return res.status(404).json({error:"Webhook not found."});
  if(!validDiscordWebhook(hook.webhook_url)) return res.status(400).json({error:"Saved webhook URL is invalid."});
  try {
   const r=await fetch(hook.webhook_url,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({username:"GBLOCKS Logs",embeds:[{title:"GBLOCKS LOGS • WEBHOOK TEST",description:"Webhook connection test succeeded.",color:0x1677ff,fields:[{name:"Webhook",value:String(hook.name).slice(0,256)},{name:"Sent by",value:String(admin.username||"Administrator").slice(0,256)}],timestamp:new Date().toISOString()}],allowed_mentions:{parse:[]}})});
   if(!r.ok) return res.status(502).json({error:"Discord rejected the test message (HTTP "+r.status+"). Check the webhook in Discord."});
   return res.json({ok:true,tested:true,message:"Test message sent."});
  } catch { return res.status(502).json({error:"Could not reach Discord. Check the webhook URL and try again."}); }
 }
 const name=String(body.name||"").trim().slice(0,100); const eventsList=cleanEvents(body.events); const enabled=body.enabled!==false; const url=String(body.webhook_url||"").trim();
 if(!name) return res.status(400).json({error:"Enter a name for this webhook."});
 if(!eventsList.length) return res.status(400).json({error:"Select at least one moderation event."});
 if(url && !validDiscordWebhook(url)) return res.status(400).json({error:"Enter a valid HTTPS Discord webhook URL from discord.com or discordapp.com."});
 if(Number.isSafeInteger(id)&&id>0){
  let q;
  if(url) q=await db.query("UPDATE gblocks_discord_webhooks SET name=$1,webhook_url=$2,events=$3,enabled=$4,updated_at=NOW() WHERE id=$5 RETURNING id,name,events,enabled,webhook_url",[name,url,eventsList,enabled,id]);
  else q=await db.query("UPDATE gblocks_discord_webhooks SET name=$1,events=$2,enabled=$3,updated_at=NOW() WHERE id=$4 RETURNING id,name,events,enabled,webhook_url",[name,eventsList,enabled,id]);
  if(!q.rows[0]) return res.status(404).json({error:"Webhook not found."});
  return res.json({ok:true,webhook:{id:q.rows[0].id,name:q.rows[0].name,events:q.rows[0].events,enabled:q.rows[0].enabled,masked_url:maskWebhook(q.rows[0].webhook_url)}});
 }
 if(!url) return res.status(400).json({error:"Paste a Discord webhook URL."});
 const q=await db.query("INSERT INTO gblocks_discord_webhooks(name,webhook_url,events,enabled,created_by) VALUES($1,$2,$3,$4,$5) RETURNING id,name,webhook_url,events,enabled",[name,url,eventsList,enabled,String(admin.username||admin.admin_id||"Administrator")]);
 const x=q.rows[0]; return res.json({ok:true,webhook:{id:x.id,name:x.name,events:x.events,enabled:x.enabled,masked_url:maskWebhook(x.webhook_url)}});
}