import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public"; export const methods=["GET","POST"];
export default async function(req,res){
  const admin=await adminCaller(req); if(!admin)return res.status(401).json({error:"Administrator login required."});
  if(req.method==="GET"){
    const q=await db.query("SELECT e.id,e.transaction_id,e.user_id,p.username,e.gross_amount_cents,e.provider_fee_cents,e.net_amount_cents,e.currency,e.status,e.payout_reference,e.payout_note,e.earned_at,e.paid_at,e.updated_at FROM gobux_earnings_ledger e LEFT JOIN profiles p ON p.user_id=e.user_id ORDER BY e.earned_at DESC LIMIT 500");
    const s=await db.query("SELECT COALESCE(SUM(CASE WHEN status='awaiting_payout' THEN net_amount_cents ELSE 0 END),0) AS awaiting_cents,COALESCE(SUM(net_amount_cents),0) AS total_cents,COUNT(*) AS entries FROM gobux_earnings_ledger");
    return res.json({summary:{awaiting_payout:(Number(s.rows[0].awaiting_cents)/100).toFixed(2),total:(Number(s.rows[0].total_cents)/100).toFixed(2),entries:Number(s.rows[0].entries)},earnings:q.rows.map(x=>({...x,gross_amount:(Number(x.gross_amount_cents)/100).toFixed(2),provider_fee:(Number(x.provider_fee_cents)/100).toFixed(2),net_amount:(Number(x.net_amount_cents)/100).toFixed(2)}))});
  }
  const tx=String(req.body?.transaction_id||""); if(!tx)return res.status(400).json({error:"Transaction ID required."});
  if(req.body?.action!=="mark_paid")return res.status(400).json({error:"Unknown action."});
  const ref=String(req.body?.payout_reference||"").trim().slice(0,120),note=String(req.body?.payout_note||"").trim().slice(0,500);
  const q=await db.query("UPDATE gobux_earnings_ledger SET status='paid',payout_reference=$1,payout_note=$2,paid_at=COALESCE(paid_at,NOW()),updated_at=NOW() WHERE transaction_id=$3 AND status='awaiting_payout' RETURNING transaction_id",[ref||null,note||null,tx]);
  if(!q.rows.length)return res.status(404).json({error:"Awaiting-payout earnings entry not found."});
  return res.json({ok:true,message:"Earnings entry marked paid in the ledger. This does not move money through Hatchable."});
}