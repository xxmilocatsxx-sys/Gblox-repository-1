import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access = "public";
export const methods = ["POST"];
export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});
  const username=String(req.body?.username||"").trim();
  const infinite=req.body?.infinite===true;
  const raw=Number(req.body?.amount);
  if(!username)return res.status(400).json({error:"Enter a username."});
  if(!infinite && (!Number.isSafeInteger(raw)||raw<1))return res.status(400).json({error:"Enter a whole Gobux amount of at least 1, or choose Infinite Gobux."});
  const amount=Math.min(Number.isSafeInteger(raw)?raw:0,300000000);
  const target=await db.query("SELECT user_id,username FROM profiles WHERE username=$1 LIMIT 1",[username]);
  if(!target.rows.length)return res.status(404).json({error:"GBLOCKS user not found."});
  const uid=target.rows[0].user_id;
  const q=await db.query("INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,$2,NULL,$3) ON CONFLICT (user_id) DO UPDATE SET balance=CASE WHEN $3 THEN gobux_accounts.balance ELSE LEAST(500000000000000000000000000000000000000000000000000000000000000000000000000000000::numeric,gobux_accounts.balance+$2::numeric) END,gobux_infinite=$3,updated_at=now() RETURNING balance,gobux_infinite",[uid,amount,infinite]);
  res.json({ok:true,username:target.rows[0].username,granted:infinite?"infinite":amount,balance:infinite?"∞":Number(q.rows[0].balance),infinite:Boolean(q.rows[0].gobux_infinite),maxBalance:300000000});
}