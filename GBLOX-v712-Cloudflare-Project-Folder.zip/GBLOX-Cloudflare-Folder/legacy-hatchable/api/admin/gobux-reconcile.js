import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access="public"; export const methods=["POST"];
export default async function(req,res){
const admin=await adminCaller(req);if(!admin)return res.status(401).json({error:"Administrator login required."});
const q=await db.query("SELECT transaction_id,user_id,gobux_amount FROM gobux_purchase_ledger WHERE reconciliation_required=true AND status='pending' AND provider_status='paid' ORDER BY created_at ASC LIMIT 100");let ok=0,failed=0;
for(const p of q.rows){try{
await db.query("INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",[p.user_id]);
const w=await db.query("UPDATE gobux_accounts SET balance=balance+$1,updated_at=NOW() WHERE user_id=$2 RETURNING balance,gobux_infinite",[Number(p.gobux_amount),p.user_id]);if(!w.rows.length)throw new Error("wallet update failed");
const b=w.rows[0];const u=await db.query("UPDATE gobux_purchase_ledger SET status='completed',provider_status='paid',resulting_balance=$1,reconciliation_required=false,paid_at=COALESCE(paid_at,NOW()),updated_at=NOW() WHERE transaction_id=$2 AND status<>'completed' RETURNING transaction_id",[b.gobux_infinite?null:Number(b.balance),p.transaction_id]);if(u.rows.length)ok++;
}catch(e){failed++;console.error("Admin Gobux reconciliation failed",p.transaction_id,e)}}
res.json({ok:true,reconciled:ok,failed});
}