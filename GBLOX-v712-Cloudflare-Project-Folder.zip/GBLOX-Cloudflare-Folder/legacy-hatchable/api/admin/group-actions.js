import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { refreshGroupVerification, refreshGroupOwnerAdminPlayerVerification } from "../../lib/verification.js";
export const access="public";
export const methods=["POST"];
export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});
  const id=String(req.body?.group_id||"").trim();
  const action=String(req.body?.action||"").trim().toLowerCase();
  const reason=String(req.body?.reason||"").trim().slice(0,500);
  const map={lock:[true,false,false],unlock:[false,false,false],ban:[null,true,false],unban:[null,false,false],delete:[null,null,true]};
  if(!id||(!Object.prototype.hasOwnProperty.call(map,action)&&action!=="claim"))return res.status(400).json({error:"Choose a group and a valid action."});
  try{
    const found=await db.query("SELECT id,name,owner_id,claimed_owner_id,moderation_locked,moderation_banned,moderation_deleted,(EXISTS(SELECT 1 FROM profiles p WHERE p.user_id=groups.owner_id) OR EXISTS(SELECT 1 FROM profiles cp WHERE cp.user_id=groups.claimed_owner_id)) AS owner_exists FROM groups WHERE id=$1",[id]);
    if(!found.rows[0]||found.rows[0].moderation_deleted)return res.status(404).json({error:"Community not found."});
    if(action==="claim"){
      // Beta Testers is claimed through claimed_owner_id so automated membership sync remains intact.
      if(found.rows[0].owner_exists)return res.status(409).json({error:"This group already has an existing account owner. Admin claiming is only available when the owner is unknown."});
      let claimantId=admin.user_id?String(admin.user_id):"";
      if(!claimantId){const profile=await db.query("SELECT user_id FROM profiles WHERE lower(username)=lower($1) AND role IN ('admin','administrator') AND banned=false AND terminated=false ORDER BY created_at ASC LIMIT 1",[admin.username]);claimantId=String(profile.rows[0]?.user_id||"");}
      if(!claimantId)return res.status(403).json({error:"Sign in with an administrator player account to claim an orphaned group."});
      const eligible=await db.query("SELECT user_id FROM profiles WHERE user_id=$1 AND role IN ('admin','administrator') AND banned=false AND terminated=false LIMIT 1",[claimantId]);
      if(!eligible.rows[0])return res.status(403).json({error:"Only an active administrator player account can claim this group."});
      const isBeta=String(found.rows[0].id)==="beta-testers"||String(found.rows[0].name).toLowerCase()==="beta testers";
      if(isBeta){
        await db.query("UPDATE groups SET claimed_owner_id=$1 WHERE id=$2 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.user_id=groups.owner_id) AND NOT EXISTS(SELECT 1 FROM profiles cp WHERE cp.user_id=groups.claimed_owner_id)",[claimantId,id]);
      }else{
        await db.query("UPDATE groups SET owner_id=$1 WHERE id=$2 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.user_id=groups.owner_id)",[claimantId,id]);
      }
      const check=await db.query("SELECT CASE WHEN id='beta-testers' OR lower(name)=lower('Beta Testers') THEN claimed_owner_id ELSE owner_id END AS owner_id FROM groups WHERE id=$1",[id]);
      if(String(check.rows[0]?.owner_id)!==claimantId)return res.status(409).json({error:"The group owner changed before the claim completed. Refresh and try again."});
      await db.query("DELETE FROM group_members WHERE group_id=$1 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.user_id=group_members.user_id)",[id]);
      await db.query("INSERT INTO group_members(group_id,user_id,role) VALUES($1,$2,'owner') ON CONFLICT(group_id,user_id) DO UPDATE SET role='owner'",[id,claimantId]);
      await refreshGroupVerification(id);
      console.log(JSON.stringify({event:"GROUP_CLAIMED",group_id:id,group_name:found.rows[0].name,admin:admin.username,new_owner_id:claimantId,previous_owner_id:found.rows[0].owner_id,reason}));
      return res.json({ok:true,action:"claim",group_id:id,owner_id:claimantId,message:"Orphaned group claimed successfully. You are now the group owner."});
    }
    const vals=map[action];
    const updated=await db.query("UPDATE groups SET moderation_locked=COALESCE($1,moderation_locked), moderation_banned=COALESCE($2,moderation_banned), moderation_deleted=COALESCE($3,moderation_deleted), moderation_reason=$4, moderation_updated_at=NOW() WHERE id=$5 RETURNING id,name,moderation_locked,moderation_banned,moderation_deleted",[vals[0],vals[1],vals[2],reason||('Admin action: '+action),id]);
    await refreshGroupVerification(id);
    await refreshGroupOwnerAdminPlayerVerification();
    console.log(JSON.stringify({event:"GROUP_MODERATION",action,group_id:id,group_name:found.rows[0].name,admin:admin.username,reason}));
    return res.json({ok:true,group:updated.rows[0],message:action==="delete"?"Community removed from public view.":"Community moderation updated."});
  }catch(e){console.error("group moderation failed",String(e?.message||e));return res.status(500).json({error:"Could not update community moderation."});}
}