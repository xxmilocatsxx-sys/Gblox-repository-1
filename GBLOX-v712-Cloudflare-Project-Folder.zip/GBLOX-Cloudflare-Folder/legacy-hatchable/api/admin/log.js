import { db } from "hatchable";

export const access = "admin";
export const methods = ["POST"];

const ALLOWED = new Set(["BAN","UNBAN","TERMINATE","RESET","USERNAME_RESET","GOBUX_CHANGE","ACCOUNT_CREATED","ADMIN_ACTION","ERROR","SECURITY_EVENT"]);

function text(value, max = 1000) {
  return value == null ? null : String(value).slice(0, max);
}

export default async function (req, res) {
  const body = req.body || {};
  const action = String(body.action || "").toUpperCase();
  if (!ALLOWED.has(action)) return res.status(400).json({ error: "Unsupported log action" });

  const actor = req.member || {};
  const targetUserId = text(body.targetUserId, 120);
  const targetUsername = text(body.targetUsername, 100);
  const reason = text(body.reason, 1000);
  const details = body.details && typeof body.details === "object" ? body.details : {};

  await db.query(
    "INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)",
    [action, targetUserId, targetUsername, text(actor.id,120), text(actor.handle || actor.display_name,100), reason, JSON.stringify(details)]
  );

  // Send through the GBLOCKS Discord bot when configured; keep the existing
  // webhooks as a fallback so logging continues while the bot is being set up.
  const moderationAction = ["BAN", "UNBAN", "TERMINATE", "RESET", "USERNAME_RESET"].includes(action);
  const botToken = process.env.GROBLOX_DISCORD_BOT_TOKEN;
  const channelId = moderationAction
    ? (process.env.GROBLOX_DISCORD_BANS_CHANNEL_ID || process.env.GROBLOX_DISCORD_LOG_CHANNEL_ID)
    : process.env.GROBLOX_DISCORD_LOG_CHANNEL_ID;
  const webhook = moderationAction
    ? (process.env.GROBLOX_DISCORD_BANS_WEBHOOK || process.env.GROBLOX_DISCORD_WEBHOOK)
    : process.env.GROBLOX_DISCORD_WEBHOOK;

  const fields = [
    { name: "Action", value: action.replaceAll("_", " "), inline: true },
    ...(targetUsername || targetUserId ? [{ name: "Target", value: text(targetUsername || targetUserId, 300), inline: true }] : []),
    ...(reason ? [{ name: "Reason", value: reason, inline: false }] : []),
    ...(actor.handle || actor.display_name ? [{ name: "Actor", value: text(actor.handle || actor.display_name, 200), inline: true }] : []),
    { name: "Details", value: "```json\n" + JSON.stringify(details).slice(0, 900) + "\n```", inline: false }
  ];

  const embed = { title: `GBLOCKS • ${action.replaceAll("_", " ")}`, fields, timestamp: new Date().toISOString() };

  if (webhook) {
    try {
      await fetch(webhook, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ username: "GBLOCKS Logs", embeds: [embed] })
      });
    } catch (_) {}
  } else if (botToken && channelId) {
    try {
      await fetch(`https://discord.com/api/v10/channels/${encodeURIComponent(channelId)}/messages`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bot ${botToken}`
        },
        body: JSON.stringify({ embeds: [embed] })
      });
    } catch (_) {}
  }

  res.json({ ok: true });
}