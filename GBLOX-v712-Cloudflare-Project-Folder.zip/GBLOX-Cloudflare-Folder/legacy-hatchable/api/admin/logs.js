import { db } from "hatchable";

export const access = "admin";
export const methods = ["GET"];

export default async function (req, res) {
  const limit = Math.min(Math.max(Number(req.query?.limit || 100), 1), 250);
  const { rows } = await db.query(
    "SELECT id,action,target_user_id,target_username,actor_user_id,actor_username,reason,details,created_at FROM audit_logs ORDER BY created_at DESC LIMIT $1",
    [limit]
  );
  res.json({ logs: rows });
}