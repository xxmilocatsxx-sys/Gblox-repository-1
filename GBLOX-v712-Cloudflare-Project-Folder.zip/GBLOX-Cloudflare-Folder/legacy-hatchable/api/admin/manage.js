import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
export const access = "public";
export const methods = ["POST"];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});

  const username=String(req.body?.username||"").trim();
  const action=req.body?.action;
  if(!username||!["grant","revoke","creator","creator_alt","user","premium"].includes(action)){
    return res.status(400).json({error:"Invalid request."});
  }

  const target=await db.query(
    "SELECT user_id,username,role,creator_role FROM profiles WHERE LOWER(username)=LOWER($1)",
    [username]
  );
  if(!target.rows[0])return res.status(404).json({error:"User not found."});
  const t=target.rows[0];
  // admin_accounts and profiles are separate identity namespaces. A matching username is not the same account.
  if(action==="premium"){
    return res.status(400).json({error:"Use the Premium Controls section to choose a Premium gift duration."});
  }

  if(action==="grant"){
    if(t.role==="administrator")return res.json({ok:true,username:t.username,role:t.role,creator_role:t.creator_role});
    await db.query("UPDATE profiles SET role='administrator' WHERE user_id=$1",[t.user_id]);
    return res.json({ok:true,username:t.username,role:"administrator",creator_role:t.creator_role});
  }

  if(action==="revoke"){
    if(String(t.user_id)===String(admin.user_id||""))return res.status(400).json({error:"You cannot remove your own administrator role."});
    await db.query("UPDATE profiles SET role='user' WHERE user_id=$1",[t.user_id]);
    return res.json({ok:true,username:t.username,role:"user",creator_role:t.creator_role});
  }

  if(action==="creator"||action==="creator_alt"){
    const special=action==="creator"?"creator":"creator_alt";
    await db.query("UPDATE profiles SET creator_role=$1 WHERE user_id=$2",[special,t.user_id]);
    return res.json({ok:true,username:t.username,role:t.role,creator_role:special});
  }

  if(action==="user"){
    await db.query("UPDATE profiles SET creator_role=NULL WHERE user_id=$1",[t.user_id]);
    return res.json({ok:true,username:t.username,role:t.role,creator_role:null});
  }

  return res.status(400).json({error:"Invalid request."});
}