import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";

export const access = "public";
export const methods = ["POST"];

function addMonths(date, months) {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
}

function addYears(date, years) {
  const d = new Date(date);
  d.setFullYear(d.getFullYear() + years);
  return d;
}

export default async function (req, res) {
  const admin = await adminCaller(req);
  if (!admin) return res.status(401).json({ error: "Administrator login required." });

  const username = String(req.body?.username || "").trim();
  const plan = String(req.body?.plan || "").trim();
  if (!username || !["5_months", "500_years"].includes(plan)) {
    return res.status(400).json({ error: "Choose a username and Premium plan." });
  }

  const target = await db.query(
    "SELECT user_id, username FROM profiles WHERE lower(username)=lower($1) LIMIT 1",
    [username]
  );
  if (!target.rows[0]) return res.status(404).json({ error: "Gblocks user not found." });

  const now = new Date();
  const fiveMonths = plan === "5_months";
  const weeklyAmount = fiveMonths ? 10000 : 9897000;
  const expiresAt = fiveMonths ? addMonths(now, 5) : addYears(now, 500);
  const uid = String(target.rows[0].user_id);

  const nextPayoutAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  await db.transaction([
    {
      sql: "INSERT INTO premium_subscriptions (user_id,plan,weekly_amount,started_at,expires_at,next_payout_at,active,gifted_by,updated_at,is_permanent) VALUES ($1,$2,$3,$4,$5,$7,true,$6,$4,false) ON CONFLICT (user_id) DO UPDATE SET plan=EXCLUDED.plan,weekly_amount=EXCLUDED.weekly_amount,started_at=EXCLUDED.started_at,expires_at=EXCLUDED.expires_at,next_payout_at=EXCLUDED.next_payout_at,active=true,gifted_by=EXCLUDED.gifted_by,updated_at=EXCLUDED.updated_at,is_permanent=false",
      params: [uid, plan, weeklyAmount, now, expiresAt, admin.username, nextPayoutAt]
    },
    {
      sql: "INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,$2,NULL,false) ON CONFLICT (user_id) DO UPDATE SET balance=gobux_accounts.balance+$2,updated_at=now()",
      params: [uid, weeklyAmount]
    }
  ]);

  res.json({
    ok: true,
    username: target.rows[0].username,
    plan,
    weeklyAmount,
    expiresAt: expiresAt.toISOString(),
    message: fiveMonths
      ? "5-month Premium gifted. 10,000 Gobux was added now and will be added every week."
      : "500-year Premium gifted. 9.897M Gobux was added now and will be added every week."
  });
}