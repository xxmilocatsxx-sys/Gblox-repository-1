import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";

export const access="public";
export const methods=["GET","POST"];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({isAdmin:false,error:"Administrator login required."});

  if(req.method==="GET"){
    return res.json({isAdmin:true,admin_username:admin.username,is_bot:Boolean(admin.is_bot)});
  }

  const targetUserId=String(req.body?.target_user_id||"").trim();
  const targetUsername=String(req.body?.username||"").trim();
  const action=String(req.body?.action||"").trim().toLowerCase();
  if(!targetUserId&&!targetUsername)return res.status(400).json({error:"Target player account is required."});
  if(!["ban","terminate","timeban","unban"].includes(action))return res.status(400).json({error:"Invalid moderation action."});

  let target={rows:[]};
  let legacy={rows:[]};
  if(targetUserId){
    target=await db.query("SELECT user_id,username FROM gblocks_players WHERE user_id=$1 LIMIT 1",[targetUserId]);
    if(!target.rows[0]) legacy=await db.query("SELECT user_id,username FROM profiles WHERE user_id=$1 LIMIT 1",[targetUserId]);
  }
  // If the supplied ID is stale/mismatched, fall back to the profile username.
  if(!target.rows[0]&&!legacy.rows[0]&&targetUsername){
    target=await db.query("SELECT user_id,username FROM gblocks_players WHERE LOWER(username)=LOWER($1) LIMIT 1",[targetUsername]);
    if(!target.rows[0]) legacy=await db.query("SELECT user_id,username FROM profiles WHERE LOWER(username)=LOWER($1) LIMIT 1",[targetUsername]);
  }
  const resolvedTarget=target.rows[0]||legacy.rows[0]||null;
  if(!resolvedTarget)return res.status(404).json({error:"GBlocks player account not found."});
  // Keep all state-changing moderation logic in the existing audited admin endpoint.
  const body={...req.body,target_user_id:String(resolvedTarget.user_id),username:String(resolvedTarget.username)};
  if(action==="ban") body.action="permanent_ban";
  if(action==="terminate") body.action="terminated";
  if(action==="timeban") body.action="banned";
  if(action==="unban") body.action="unban";
  if(["ban","terminate","timeban"].includes(action) && !String(body.moderator_note||"").trim())return res.status(400).json({error:"Moderator note is required for this action."});

  // Server-side requests must never derive the public origin from req.url;
  // Hatchable may expose req.url as a loopback address such as 127.0.0.1.
  // Use the browser-facing project origin explicitly.
  const base="https://gblocks.hatchable.site";
  const upstream=await fetch(base+"/api/admin/ban",{
    method:"POST",
    headers:{"content-type":"application/json","cookie":String(req.headers?.cookie||""),"x-gblocks-bot-key":String(req.headers?.["x-gblocks-bot-key"]||"")},
    body:JSON.stringify(body)
  });
  const data=await upstream.json().catch(()=>({error:"Moderation request failed."}));
  return res.status(upstream.status).json(data);
}