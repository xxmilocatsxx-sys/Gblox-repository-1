import { db } from 'hatchable';
import { adminCaller } from '../../lib/admin-auth.js';

export const access = 'public';
export const methods = ['POST'];

export default async function (req, res) {
  const adminUser = await adminCaller(req);
  if (!adminUser) return res.status(401).json({ error: "Administrator login required.", code: "NOT_SIGNED_IN" });

  const username = String(req.body?.username || '').trim();
  const confirmation = String(req.body?.confirmation || '').trim();
  const reason = String(req.body?.reason || '').trim().slice(0, 500);
  if (!username) return res.status(400).json({ error: 'Enter a username.' });
  if (confirmation !== username) return res.status(400).json({ error: 'Type the exact username to confirm the reset.' });
  if (!reason) return res.status(400).json({ error: 'A documented moderation reason is required for permanent deletion.' });

  const target = await db.query("SELECT user_id,username,display_name,role,user_number FROM profiles WHERE LOWER(username)=LOWER($1)", [username]);
  const legacyAccount = target.rows[0] || null;
  let account = legacyAccount;
  let accountTable = 'profiles';

  // Also support the current GBlocks player namespace.
  if (!account) {
    const current = await db.query("SELECT user_id,username,display_name FROM gblocks_players WHERE LOWER(username)=LOWER($1)", [username]);
    account = current.rows[0] || null;
    accountTable = 'gblocks_players';
  }
  if (!account) return res.status(404).json({ error: 'User not found.' });

  // Admins may permanently delete other administrator-role player accounts to recover from compromised accounts.
  // Never allow an administrator to permanently delete the account they are currently using.
  if (account.role === 'administrator' && String(account.user_id) === String(adminUser.user_id || adminUser.admin_id || '')) {
    return res.status(400).json({ error: 'You cannot permanently delete the administrator account you are currently using. Sign in as another administrator.' });
  }

  const oldUsername = account.username;
  const oldUserId = String(account.user_id);

  // Permanent deletion RELEASES every username belonging to this account.
  // Remove both reservation rows and username-history rows so signup/change-username
  // checks cannot continue blocking any old name from this deleted account.
  await db.query('DELETE FROM username_reservations WHERE reserved_for_user_id=$1', [oldUserId]);
  await db.query('DELETE FROM username_history WHERE user_id=$1', [oldUserId]);

  // A permanent deletion must clean both account stores for the SAME user ID.
  // Do not match by username here: another account may legitimately use that name.
  await db.query('DELETE FROM account_sessions WHERE user_id=$1', [oldUserId]).catch(()=>{});
  await db.query('DELETE FROM account_credentials WHERE user_id=$1', [oldUserId]).catch(()=>{});
  await db.query('DELETE FROM gblocks_sessions WHERE user_id=$1', [oldUserId]).catch(()=>{});
  await db.query('DELETE FROM gblocks_credentials WHERE user_id=$1', [oldUserId]).catch(()=>{});
  // Transfer every owned group before the player/profile rows disappear. The sentinel
  // is intentionally not a player ID, so the deleted account cannot remain linked.
  await db.transaction([
    { sql: "UPDATE groups SET owner_id='unknown-owner', claimed_owner_id=NULL WHERE owner_id=$1 OR claimed_owner_id=$1", params: [oldUserId] },
    { sql: "DELETE FROM gblocks_players WHERE user_id=$1", params: [oldUserId] },
    { sql: "DELETE FROM profiles WHERE user_id=$1", params: [oldUserId] }
  ]);

  await db.query(
    "INSERT INTO audit_logs (action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)",
    ["PERMANENT_ACCOUNT_DELETED", oldUserId, oldUsername, String(adminUser.admin_id), adminUser.username, reason, JSON.stringify({ oldUsername, userNumber: account.user_number ?? null, usernamesReleased: true, documentedReason: reason })]
  );

  const webhook = process.env.GROBLOX_DISCORD_BANS_WEBHOOK || process.env.GROBLOX_DISCORD_WEBHOOK;
  if (webhook) {
    try {
      await fetch(webhook, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          username: "GBLOCKS Moderation Logs",
          embeds: [{
            title: "GBLOCKS • USERNAME RESET",
            fields: [
              { name: "Old Username", value: String(account.username).slice(0, 200), inline: true },
              { name: "Status", value: "Permanently deleted • all usernames released", inline: true },
              { name: "Administrator", value: String(adminUser.username).slice(0, 200), inline: true },
              { name: "User ID", value: String(account.user_id), inline: false }
            ],
            timestamp: new Date().toISOString()
          }]
        })
      });
    } catch (_) {}
  }

  return res.json({ ok: true, deleted: true, oldUsername, usernamesReleased: true, userId: oldUserId, message: `Permanently deleted ${oldUsername}. All usernames belonging to this account are available again.` });
}