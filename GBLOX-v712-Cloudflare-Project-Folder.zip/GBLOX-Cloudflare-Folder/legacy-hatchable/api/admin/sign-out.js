import { db } from "hatchable";
import { adminTokenHash } from "../../lib/admin-auth.js";
export const access = "public";
export const methods = ["POST"];

export default async function(req,res){
  const cookies=Object.fromEntries(String(req.headers?.cookie||"").split(";").map(part=>{
    const i=part.indexOf("=");
    if(i<0)return ["",""];
    const name=part.slice(0,i).trim();
    const value=part.slice(i+1).trim();
    return [name,value];
  }).filter(([name])=>Boolean(name)));
  const readToken=name=>{
    const raw=cookies[name];
    if(!raw)return null;
    try{return decodeURIComponent(raw)}catch{return raw}
  };
  const adminToken=readToken("gblocks_admin_session");
  const playerToken=readToken("groblox_session");
  const legacyToken=readToken("gblocks_session");
  const revoked=[];
  // Revoke only the session tokens supplied with this logout request.
  if(adminToken){
    await db.query("DELETE FROM admin_sessions WHERE token_hash=$1",[await adminTokenHash(adminToken)]);
    revoked.push("administrator");
  }
  if(playerToken){
    await db.query("DELETE FROM account_sessions WHERE token_hash=$1",[await adminTokenHash(playerToken)]);
    revoked.push("main-site");
  }
  if(legacyToken){
    await db.query("DELETE FROM gblocks_sessions WHERE token_hash=$1",[await adminTokenHash(legacyToken)]);
    revoked.push("legacy-player");
  }
  res.setHeader("Cache-Control","no-store, no-cache, must-revalidate, private");
  res.setHeader("Pragma","no-cache");
  res.setHeader("Expires","0");
  res.setHeader("Set-Cookie",[
    "gblocks_admin_session=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Secure; SameSite=Lax",
    "groblox_session=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Secure; SameSite=Lax",
    "gblocks_session=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Secure; SameSite=Lax"
  ]);
  return res.json({ok:true,signedOut:true,revoked,message:revoked.length?"Signed out and revoked the active session(s) used by the GBLOX Administrator Panel.":"No administrator or player session cookies were present."});
}