import { db } from "hatchable";
import { adminCaller } from "../../lib/admin-auth.js";
import { checkBio, checkModerationUsername } from "../../lib/moderation-policy.js";

export const access="public";
export const methods=["POST"];

export default async function(req,res){
  const admin=await adminCaller(req);
  if(!admin)return res.status(401).json({error:"Administrator login required.",code:"NOT_SIGNED_IN"});

  const dryRun=Boolean(req.body?.dry_run);
  const rows=await db.query("SELECT user_id,username,display_name,bio,moderation_free_username_change FROM gblocks_players ORDER BY created_at ASC, user_id ASC");

  const flagged=[];
  for(const p of rows.rows){
    const usernameCheck=checkModerationUsername(p.username);
    const bioCheck=checkBio(p.bio);
    if(!usernameCheck.flagged&&!bioCheck.flagged)continue;
    flagged.push({
      userId:String(p.user_id),
      oldUsername:String(p.username),
      userNumber:p.user_number,
      reasons:[
        ...(usernameCheck.flagged?["username"]:[]),
        ...(bioCheck.flagged?["bio"]:[])
      ],
      usernameViolation:usernameCheck.flagged,
      bioViolation:bioCheck.flagged
    });
  }

  if(dryRun)return res.json({ok:true,dryRun:true,scanned:rows.rows.length,flagged});

  const results=[];
  for(const item of flagged){
    const current=await db.query(
      "SELECT user_id,username,display_name,bio,moderation_free_username_change FROM gblocks_players WHERE user_id=$1 LIMIT 1",
      [item.userId]
    );
    const p=current.rows[0];
    if(!p)continue;

    const usernameCheck=checkModerationUsername(p.username);
    const bioCheck=checkBio(p.bio);
    if(!usernameCheck.flagged&&!bioCheck.flagged)continue;

    const oldUsername=String(p.username);
    const tx=await db.transaction([
      {sql:"SELECT user_id,username FROM gblocks_players WHERE user_id=$1 FOR UPDATE",params:[item.userId]},
      {sql:"INSERT INTO username_history(username,user_id) SELECT username,user_id FROM gblocks_players WHERE user_id=$1",params:[item.userId]},
      {sql:"INSERT INTO username_reservations(username,reserved_for_user_id,reason) SELECT username,user_id,'account_violation_checker' FROM gblocks_players WHERE user_id=$1 ON CONFLICT(username) DO NOTHING",params:[item.userId]},
      {sql:`WITH candidate AS (
         SELECT 'GBLOCKS_User_'||pr.user_number::text AS username
         FROM profiles pr
         WHERE pr.user_id=$1 AND pr.user_number IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.user_id<>pr.user_id AND LOWER(x.username)=LOWER('GBLOCKS_User_'||pr.user_number::text))
         LIMIT 1
       )
       UPDATE gblocks_players p SET username=c.username,display_name=c.username,bio='[Content Deleted]'
       FROM candidate c WHERE p.user_id=$1`,params:[item.userId]},
      {sql:"UPDATE profiles SET username='GBLOCKS_User_'||user_number::text,display_name='GBLOCKS_User_'||user_number::text,bio='[Content Deleted]' WHERE user_id=$1 AND user_number IS NOT NULL",params:[item.userId]},
      {sql:"UPDATE gblocks_credentials SET username=(SELECT username FROM gblocks_players WHERE user_id=$1),updated_at=NOW() WHERE user_id=$1",params:[item.userId]},
      {sql:"UPDATE gblocks_players SET moderation_free_username_change=CASE WHEN $1 THEN TRUE ELSE moderation_free_username_change END WHERE user_id=$2",params:[usernameCheck.flagged,item.userId]},
      {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) SELECT 'AUTOMATIC_USERNAME_RESET',p.user_id,p.username,$1,$2,'Account Violation Checker confirmed an explicit violation.',$3::jsonb FROM gblocks_players p WHERE p.user_id=$4",params:[String(admin.user_id),admin.username,JSON.stringify({oldUsername,usernameViolation:usernameCheck.flagged,bioViolation:bioCheck.flagged,freeUsernameChangeGranted:usernameCheck.flagged,checker:"Account Violation Checker"}),item.userId]}
    ]);
    const updated=await db.query("SELECT username FROM gblocks_players WHERE user_id=$1",[item.userId]);
    const newUsername=updated.rows[0]?.username;
    if(!newUsername)continue;

    results.push({
      userId:item.userId,
      oldUsername,
      newUsername,
      reasons:[
        ...(usernameCheck.flagged?["username"]:[]),
        ...(bioCheck.flagged?["bio"]:[])
      ],
      freeUsernameChangeGranted:usernameCheck.flagged
    });
  }

  return res.json({ok:true,dryRun:false,scanned:rows.rows.length,flagged:flagged.length,resetCount:results.length,results});
}