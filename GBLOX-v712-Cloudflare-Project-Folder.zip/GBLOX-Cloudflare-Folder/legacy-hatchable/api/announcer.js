import { db } from "hatchable";
export const access="public";
export const methods=["GET"];

export default async function(req,res){
  const q=await db.query("SELECT id,title,body,updated_at FROM gblocks_announcements ORDER BY updated_at DESC LIMIT 1");
  return res.json({announcement:q.rows[0]||null});
}