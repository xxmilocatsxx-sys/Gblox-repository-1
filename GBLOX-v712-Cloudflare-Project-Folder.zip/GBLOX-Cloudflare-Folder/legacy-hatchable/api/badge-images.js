import { storage, db } from 'hatchable';
export const access = 'public';
export const methods = ['GET'];
export default async function(req,res){
 try { const r=await db.query('SELECT slot, storage_key, content_type, updated_at FROM badge_image_assets ORDER BY slot'); const items=await Promise.all(r.rows.map(async x=>({slot:x.slot,url:await storage.url(x.storage_key),content_type:x.content_type,updated_at:x.updated_at}))); res.setHeader('Cache-Control','no-store'); return res.json({items}); }
 catch(e){ console.error('public badge images error',e); return res.status(500).json({error:'Unable to load badge images.'}); }
}