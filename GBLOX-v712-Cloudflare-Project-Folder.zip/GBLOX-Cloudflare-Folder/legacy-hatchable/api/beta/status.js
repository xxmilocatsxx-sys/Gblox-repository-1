import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

const enc = new TextEncoder();

function cookie(req, name) {
  if (req.cookies?.[name]) return String(req.cookies[name]);
  const raw = String(req.headers?.cookie || "");
  const m = raw.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]*)"));
  return m ? decodeURIComponent(m[1]) : "";
}

async function hashToken(token, urlSafe=false) {
  const bytes = await crypto.subtle.digest("SHA-256", enc.encode(token));
  let out = btoa(String.fromCharCode(...new Uint8Array(bytes)));
  return urlSafe ? out.replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"") : out;
}

async function findUser(req) {
  const gblocksToken = String(req.headers?.["x-gblocks-session"] || req.headers?.["X-Gblocks-Session"] || cookie(req, "gblocks_session") || "").trim();
  if (gblocksToken) {
    const hashes = [await hashToken(gblocksToken, false), await hashToken(gblocksToken, true)];
    const q = await db.query(
      "SELECT p.user_id,p.username,p.role,ps.plan AS premium_plan,ps.active AS premium_active,ps.is_permanent AS premium_permanent,ps.expires_at AS premium_expires_at FROM gblocks_sessions s JOIN profiles p ON p.user_id=s.user_id LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true WHERE s.token_hash=ANY($1::text[]) AND s.expires_at>NOW() LIMIT 1",
      [hashes]
    );
    if (q.rows[0]) return q.rows[0];
  }

  const legacyToken = String(cookie(req, "groblox_session") || "").trim();
  if (legacyToken) {
    const hashes = [await hashToken(legacyToken, true), await hashToken(legacyToken, false)];
    const q = await db.query(
      "SELECT p.user_id,p.username,p.role,ps.plan AS premium_plan,ps.active AS premium_active,ps.is_permanent AS premium_permanent,ps.expires_at AS premium_expires_at FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id LEFT JOIN premium_subscriptions ps ON ps.user_id=p.user_id AND ps.active=true WHERE s.token_hash=ANY($1::text[]) AND s.expires_at>NOW() LIMIT 1",
      [hashes]
    );
    if (q.rows[0]) return q.rows[0];
  }

  return null;
}

export default async function(req, res) {
  const u = await findUser(req);
  if (!u) return res.json({ signedIn: false, tester: false, sources: [], betaAccess: false });

  const admin = u.role === "admin" || u.role === "administrator";
  const premium = !!u.premium_active && (!!u.premium_permanent || (!!u.premium_expires_at && new Date(u.premium_expires_at).getTime() > Date.now()));
  const sources = [];
  if (admin) sources.push("admin");
  if (premium) sources.push("premium");

  await db.query(
    "INSERT INTO gblocks_beta_testers (user_id,source,active,updated_at) VALUES ($1,$2,true,NOW()) ON CONFLICT (user_id) DO UPDATE SET source=EXCLUDED.source,active=true,updated_at=NOW()",
    [u.user_id, sources.join("+") || "none"]
  );

  const releaseQ=await db.query("SELECT released,phase,release_number,beta_update_count FROM gblocks_studio_release WHERE id=1");
  const release=releaseQ.rows[0]||{released:false,phase:"development",release_number:0,beta_update_count:0};
  let studioAccess=false;
  let studioPhase="development";
  let betaUpdateCount=Number(release.beta_update_count||0);

  studioPhase=release.phase;
  if(release.phase==="general"){
    studioAccess=true;
  }else if(sources.length>0){
    studioAccess=true;
    if(release.released){
      await db.query(
        "INSERT INTO gblocks_studio_beta_updates(release_number,user_id) VALUES($1,$2) ON CONFLICT(release_number,user_id) DO NOTHING",
        [Number(release.release_number),String(u.user_id)]
      );
      const countQ=await db.query(
        "SELECT COUNT(*)::int AS count FROM gblocks_studio_beta_updates WHERE release_number=$1",
        [Number(release.release_number)]
      );
      betaUpdateCount=Number(countQ.rows[0]?.count||0);
    }
  }

  return res.json({
    signedIn: true,
    tester: sources.length > 0,
    betaAccess: sources.length > 0,
    studioAccess,
    studioPhase,
    studioBetaUpdateCount: betaUpdateCount,
    studioRequiredBetaUpdates: 2,
    sources,
    username: u.username,
    premiumPlan: premium ? u.premium_plan : null
  });
}