import {db} from 'hatchable';
export const access='public';
export const methods=['POST'];

const prices={'red-cap':15,'blue-cap':20,'happy-face':25,'cool-face':35,'blue-tee':5,'black-hoodie':20,'blue-jeans':15,'black-pants':10,'blue-backpack':60,'cat-buddy':75,'retro-cola':35,'classic-noob':0,'founder-builder':75,'chicken-admin':60,'classic-visor':40,'bigger-head':55,'teapot-hat':90,'shaggy-hair':65,'pixel-tux':20,'heart-tee':15,'bandito-shirt':25,'classic-sword':100,'super-bomb':120,'rocket-launcher':150,'tripmine':125,'bloxiade':30,'pizza':30,'ban-hammer':555000000000000};
const ADMIN_FREE_ITEMS=new Set(['ban-hammer']);

const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function tokenHash(t){return b64(await crypto.subtle.digest('SHA-256',enc.encode(t)))}
function getCookie(req,name){if(req.cookies?.[name])return String(req.cookies[name]);const c=String(req.headers?.cookie||'');const m=c.match(new RegExp('(?:^|;\\s*)'+name+'=([^;]*)'));return m?decodeURIComponent(m[1]):null}
async function sessionUser(req){
 const gblocksRaw=getCookie(req,'gblocks_session');
 const raw=gblocksRaw || getCookie(req,'groblox_session'); if(!raw)return null;
 const th=await tokenHash(raw);
 const table=gblocksRaw?'gblocks_sessions':'account_sessions';
 const q=await db.query(`SELECT p.user_id,p.username,p.banned,p.terminated,p.role FROM ${table} s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,[th]);
 const u=q.rows[0]; return u&& !u.banned && !u.terminated ? u:null;
}

export default async function(req,res){
  const user=await sessionUser(req);
  if(!user)return res.status(401).json({error:'Log in to buy catalog items.'});
  const buyerWallet=await db.query('SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1',[String(user.user_id)]);
  if(!buyerWallet.rows[0])await db.query('INSERT INTO gobux_accounts (user_id,balance,gobux_infinite) VALUES ($1,0,false) ON CONFLICT (user_id) DO NOTHING',[String(user.user_id)]);
  if(String(user.username||'').toLowerCase()==='gbloxbuilder')return res.status(403).json({error:'The Builder catalog recipient account cannot purchase catalog items.'});
  const itemId=String(req.body?.item_id||'');
  let basePrice=prices[itemId];
  let eventItem=null;
  if(basePrice===undefined){
    const eventLookup=await db.query("SELECT id,price,is_on_sale,sale_end_at,stock_limit,stock_sold FROM gblox_catalog_event_items WHERE id=$1 LIMIT 1",[itemId]);
    eventItem=eventLookup.rows[0]||null;
    if(!eventItem)return res.status(400).json({error:'Invalid catalog item.'});
    if(!eventItem.is_on_sale || new Date(eventItem.sale_end_at).getTime()<=Date.now()){
      await db.query("UPDATE gblox_catalog_event_items SET is_on_sale=FALSE WHERE id=$1 AND sale_end_at<=NOW()",[itemId]);
      return res.status(410).json({error:'This Halloween item is Off Sale. Items purchased during the event remain in your inventory.'});
    }
    if(eventItem.stock_limit!==null && Number(eventItem.stock_sold)>=Number(eventItem.stock_limit))return res.status(410).json({error:'This item is sold out.'});
    basePrice=Number(eventItem.price);
  }
  const isAdmin=String(user.role||'').toLowerCase()==='administrator';
  const price=(ADMIN_FREE_ITEMS.has(itemId)&&isAdmin)?0:basePrice;

  const owned=await db.query('SELECT 1 FROM catalog_inventory WHERE user_id=$1 AND item_id=$2',[user.user_id,itemId]);
  if(owned.rows.length)return res.status(409).json({error:'You already own this item.'});

  // Stable recipient binding: resolve the existing Builder account once by its canonical username,
  // then use its immutable user_id for credits and transaction records.
  const builderLookup=await db.query("SELECT user_id FROM profiles WHERE LOWER(username)='gbloxbuilder' LIMIT 1");
  const builderId=builderLookup.rows[0]?.user_id;
  if(!builderId)return res.status(503).json({error:'The Builder GBlocks player account does not exist. Your Gobux was not charged.'});
  if(String(builderId)===String(user.user_id))return res.status(400).json({error:'The Builder catalog recipient cannot purchase from their own catalog.'});
  await db.query("INSERT INTO gobux_accounts (user_id,balance,gobux_infinite) VALUES ($1,0,false) ON CONFLICT (user_id) DO NOTHING",[String(builderId)]);

  try{
    const txId=price>0?`CAT-${crypto.randomUUID()}`:null;
    const tx=await db.transaction([
      ...(eventItem?[{sql:"SELECT 1 / CASE WHEN EXISTS (SELECT 1 FROM gblox_catalog_event_items WHERE id=$1 AND is_on_sale=TRUE AND sale_end_at>NOW() AND (stock_limit IS NULL OR stock_sold<stock_limit)) THEN 1 ELSE 0 END",params:[itemId]}]:[]),
      {sql:"WITH debited AS (UPDATE gobux_accounts SET balance=balance-$1 WHERE user_id=$2 AND (gobux_infinite=true OR balance >= $1) RETURNING user_id) SELECT 1 / CASE WHEN EXISTS (SELECT 1 FROM debited) THEN 1 ELSE 0 END AS debit_ok",params:[price,String(user.user_id)]},
      ...(price>0?[
        {sql:"INSERT INTO gobux_pending_credits (transaction_id,recipient_user_id,source_type,source_id,amount,available_at) VALUES ($1,$2,'catalog',$3,$4,NOW()+INTERVAL '5 days')",params:[txId,String(builderId),itemId,String(price)]},
        {sql:"INSERT INTO gobux_transactions (transaction_id,user_id,counterparty_user_id,amount,direction,source_type,status,pending_until) VALUES ($1,$2,$3,$4,'debit','catalog','completed',NULL)",params:[txId,String(user.user_id),String(builderId),String(price)]},
        {sql:"INSERT INTO gobux_transactions (transaction_id,user_id,counterparty_user_id,amount,direction,source_type,status,pending_until) VALUES ($1,$2,$3,$4,'credit','catalog','pending',NOW()+INTERVAL '5 days')",params:[`PEND-${txId}`,String(builderId),String(user.user_id),String(price)]}
      ]:[]),
      {sql:"INSERT INTO catalog_inventory (user_id,item_id) VALUES ($1,$2)",params:[String(user.user_id),itemId]}
    ]);
    // Debit guard is enforced inside the transaction; no separate result-index assumption.
    const wallet=await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1",[String(user.user_id)]);
    if(!wallet.rows[0])return res.status(500).json({error:'Purchase failed. Your Gobux was not charged.'});
    const infinite=Boolean(wallet.rows[0].gobux_infinite);
    return res.json({ok:true,item_id:itemId,price,balance:infinite?"∞":Number(wallet.rows[0].balance||0),infinite,recipient:'GbloxBuilder',message:price?'Item purchased! '+price+' Gobux is pending for GbloxBuilder for 5 days.':'Item added to your inventory.'});
  }catch(e){
    const msg=String(e||'').toLowerCase();
    if(msg.includes('duplicate'))return res.status(409).json({error:'You already own this item.'});
    if(msg.includes('division')||msg.includes('zero')||msg.includes('check')||msg.includes('balance'))return res.status(402).json({error:'Not enough Gobux.'});
    return res.status(500).json({error:'Purchase failed. Your Gobux was not charged.'});
  }
}