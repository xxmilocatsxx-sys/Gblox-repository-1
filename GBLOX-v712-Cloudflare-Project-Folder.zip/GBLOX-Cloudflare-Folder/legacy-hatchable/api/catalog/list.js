import { db } from 'hatchable';
export const access = 'public';
export const methods = ['GET'];
const items=[
{id:'red-cap',name:'Classic Red Cap',cat:'Hats',price:15,icon:'🧢'},
{id:'blue-cap',name:'Classic Blue Cap',cat:'Hats',price:20,icon:'🧢'},
{id:'happy-face',name:'Classic Smile Face',cat:'Faces',price:25,icon:'🙂'},
{id:'cool-face',name:'Cool Face',cat:'Faces',price:35,icon:'😎'},
{id:'blue-tee',name:'GBLOCKS Blue Tee',cat:'Shirts',price:5,icon:'👕'},
{id:'black-hoodie',name:'Classic Black Hoodie',cat:'Shirts',price:20,icon:'🧥'},
{id:'blue-jeans',name:'Dark Blue Jeans',cat:'Pants',price:15,icon:'👖'},
{id:'black-pants',name:'Classic Black Pants',cat:'Pants',price:10,icon:'👖'},
{id:'blue-backpack',name:'Blue Neon Backpack',cat:'Accessories',price:60,icon:'🎒'},
{id:'cat-buddy',name:'GBLOCKS Cat Buddy',cat:'Accessories',price:75,icon:'🐱'},
{id:'retro-cola',name:'Retro Soda',cat:'Gear',price:35,icon:'🥤'},
{id:'classic-noob',name:'Classic Noob',cat:'Classic',price:0,icon:'🧑'},
{id:'founder-builder',name:'Founder Builder',cat:'Classic',price:75,icon:'⛑️'},
{id:'chicken-admin',name:'Chicken Admin',cat:'Classic',price:60,icon:'🍗'},
{id:'classic-visor',name:'Classic Visor',cat:'Hats',price:40,icon:'🕶️'},
{id:'bigger-head',name:'Bigger Head',cat:'Hats',price:55,icon:'🗿'},
{id:'teapot-hat',name:'Teapot Hat',cat:'Hats',price:90,icon:'🫖'},
{id:'shaggy-hair',name:'Shaggy Hair',cat:'Hats',price:65,icon:'💇'},
{id:'pixel-tux',name:'Pixel Tuxedo',cat:'Shirts',price:20,icon:'🤵'},
{id:'heart-tee',name:'I-Heart Classic Tee',cat:'Shirts',price:15,icon:'❤️'},
{id:'bandito-shirt',name:'Bandito Outfit',cat:'Shirts',price:25,icon:'🤠'},
{id:'classic-sword',name:'Classic Sword',cat:'Gear',price:100,icon:'⚔️'},
{id:'super-bomb',name:'Super Bomb',cat:'Gear',price:120,icon:'💣'},
{id:'rocket-launcher',name:'Retro Rocket Launcher',cat:'Gear',price:150,icon:'🚀'},
{id:'tripmine',name:'Subspace Tripmine',cat:'Gear',price:125,icon:'💗'},
{id:'bloxiade',name:'Bloxiade',cat:'Gear',price:30,icon:'🥤'},
{id:'pizza',name:'Classic Pizza',cat:'Gear',price:30,icon:'🍕'},
{id:'ban-hammer',name:'Ban Hammer',cat:'Gear',price:555000000000000,icon:'🔨',adminFree:true}
];
export default async function(req,res){
  const now = new Date();
  const { rows } = await db.query("SELECT id,name,cat,price,icon,description,event_key,sale_end_at,is_on_sale,stock_limit,stock_sold FROM gblox_catalog_event_items WHERE event_key='halloween-2026' ORDER BY price ASC");
  const eventItems = rows.map(x => ({...x, price:Number(x.price), onSale:Boolean(x.is_on_sale) && new Date(x.sale_end_at).getTime()>now.getTime() && (x.stock_limit==null || Number(x.stock_sold)<Number(x.stock_limit)), limited:Boolean(x.stock_limit!=null), saleEndAt:x.sale_end_at, eventKey:x.event_key}));
  return res.json({items:[...items,...eventItems]});
}