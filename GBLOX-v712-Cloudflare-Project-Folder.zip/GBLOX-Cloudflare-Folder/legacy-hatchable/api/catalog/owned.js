import { db } from 'hatchable';
export const access='public';
export const methods=['GET'];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function tokenHash(t){return b64(await crypto.subtle.digest('SHA-256',enc.encode(t)))}
function getCookie(req,name){if(req.cookies?.[name])return String(req.cookies[name]);const c=String(req.headers?.cookie||'');const m=c.match(new RegExp('(?:^|;\\s*)'+name+'=([^;]*)'));return m?decodeURIComponent(m[1]):null}
async function sessionUser(req){
 const raw=getCookie(req,'groblox_session'); if(!raw)return null;
 const th=await tokenHash(raw);
 const q=await db.query("SELECT p.user_id,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[th]);
 const u=q.rows[0]; return u && !u.banned && !u.terminated ? u:null;
}
export default async function(req,res){
 const user=await sessionUser(req);
 if(!user)return res.status(401).json({error:'Log in to view your inventory.'});
 const {rows}=await db.query('SELECT item_id,purchased_at FROM catalog_inventory WHERE user_id=$1 ORDER BY purchased_at DESC',[user.user_id]);
 res.json({items:rows});
}