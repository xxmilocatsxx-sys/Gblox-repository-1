import { config, db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

export default async function (req, res) {
  const supplied = String(req.headers?.["x-gblocks-bot-key"] || "").trim();
  const configured = String((await config.get("GBLOCKS_CHECKER_BOT_KEY")) || "").trim();

  if (!supplied || !configured || supplied !== configured) {
    return res.status(401).json({ ok: false, authorized: false });
  }

  const q = await db.query(
    "SELECT user_id, username, role FROM profiles WHERE LOWER(username)=LOWER('Checker') LIMIT 1"
  );
  const bot = q.rows[0];

  return res.json({
    ok: true,
    authorized: true,
    bot_found: !!bot,
    bot_username: bot?.username || "Checker",
    role: bot?.role || null
  });
}