import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

export default async function(req,res){
  const q=await db.query(
    "SELECT id,event_key,title,body,event_date,created_at FROM gblox_bot_events WHERE event_date >= CURRENT_DATE - INTERVAL '30 days' ORDER BY event_date DESC,created_at DESC LIMIT 40"
  );
  return res.json({ok:true,events:q.rows||[]});
}