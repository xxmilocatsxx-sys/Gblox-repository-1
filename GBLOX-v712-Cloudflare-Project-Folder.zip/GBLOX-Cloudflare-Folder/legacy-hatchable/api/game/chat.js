import { db } from "hatchable";
export const access = "public";
export const methods = ["GET","POST"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function cookie(req,name){const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));return m?m[1]:null}
async function me(req){const raw=cookie(req,"groblox_session");if(!raw)return null;const th=await tokenHash(raw);const q=await db.query("SELECT p.user_id,p.username,p.display_name,p.role,p.banned FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",[th]);return q.rows[0]&&!q.rows[0].banned?q.rows[0]:null}
function clean(v,max){return String(v??"").trim().slice(0,max)}
export default async function(req,res){
  const serverId=clean(req.query?.server||req.body?.server,120), gameId=Number(req.query?.game_id||req.body?.game_id);
  if(!serverId||!Number.isSafeInteger(gameId))return res.status(400).json({error:"Invalid server."});
  const user=await me(req); if(!user)return res.status(401).json({error:"Please log in to chat."});
  const ownedServer=await db.query("SELECT server_id FROM game_servers WHERE server_id=$1 AND game_id=$2 LIMIT 1",[serverId,gameId]);
  if(!ownedServer.rows[0])return res.status(404).json({error:"Server not found for this game."});
  await db.query("UPDATE game_servers SET last_active_at=NOW() WHERE server_id=$1",[serverId]);
  await db.query("DELETE FROM game_server_players WHERE server_id=$1 AND last_seen_at<NOW()-INTERVAL '45 seconds'",[serverId]);
  const count=await db.query("SELECT COUNT(*)::int AS n FROM game_server_players WHERE server_id=$1",[serverId]);
  const already=await db.query("SELECT 1 FROM game_server_players WHERE server_id=$1 AND user_id=$2",[serverId,user.user_id]);
  if(!already.rows[0] && count.rows[0].n>=40)return res.status(409).json({error:"This server is full (40/40).",full:true,count:40,max:40});
  if(!already.rows[0]){
    await db.query("INSERT INTO game_server_players(server_id,user_id,username,last_seen_at) VALUES($1,$2,$3,NOW())",[serverId,user.user_id,user.username]);
    if(user.username.toLowerCase()==="tubers93"){
      const prior=await db.query("SELECT 1 FROM game_chat_messages WHERE server_id=$1 AND username='Tubers93' AND is_system=true LIMIT 1",[serverId]);
      if(!prior.rows[0])await db.query("INSERT INTO game_chat_messages(server_id,user_id,username,message,is_system) VALUES($1,$2,$3,$4,true)",[serverId,user.user_id,"System","Owner of GBLOCKS has joined this server"]);
    }
  }else await db.query("UPDATE game_server_players SET last_seen_at=NOW() WHERE server_id=$1 AND user_id=$2",[serverId,user.user_id]);
  if(req.method==="POST"){
    const text=clean(req.body?.message,180);
    const recent=await db.query("SELECT COUNT(*)::int AS n FROM game_chat_messages WHERE user_id=$1 AND created_at>=NOW()-INTERVAL '10 seconds'",[user.user_id]);
    if(recent.rows[0].n>=6)return res.status(429).json({error:"Chat rate limit reached. Slow down for a moment."});
    if(text){await db.query("INSERT INTO game_chat_messages(server_id,user_id,username,message,is_system) VALUES($1,$2,$3,$4,false)",[serverId,user.user_id,user.username,text]);}
  }
  const msgs=await db.query("SELECT m.id,m.username,m.message,m.is_system,m.created_at,m.user_id,COALESCE(p.verified,false) AS verified FROM game_chat_messages m LEFT JOIN profiles p ON p.user_id=m.user_id WHERE m.server_id=$1 ORDER BY m.id DESC LIMIT 60",[serverId]);
  const latest=msgs.rows.reverse();
  const now=await db.query("SELECT COUNT(*)::int AS n FROM game_server_players WHERE server_id=$1 AND last_seen_at>=NOW()-INTERVAL '45 seconds'",[serverId]);
  res.json({messages:latest,count:now.rows[0].n,max:40,serverId,username:user.username});
}