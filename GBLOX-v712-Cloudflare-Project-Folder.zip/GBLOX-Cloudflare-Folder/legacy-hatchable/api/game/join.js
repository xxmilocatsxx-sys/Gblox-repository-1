import { db } from "hatchable";
export const access = "public";
export const methods = ["POST"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function cookie(req,name){const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));return m?m[1]:null}
async function me(req){
  const gblocksRaw=cookie(req,"gblocks_session");
  const raw=gblocksRaw || cookie(req,"groblox_session"); if(!raw)return null;
  const th=await tokenHash(raw);
  const table=gblocksRaw?"gblocks_sessions":"account_sessions";
  const q=await db.query(`SELECT p.user_id,p.username,p.display_name,p.role,p.banned,p.terminated FROM ${table} s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()`,[th]);
  return q.rows[0]&&!q.rows[0].banned&&!q.rows[0].terminated?q.rows[0]:null
}
export default async function(req,res){
  const gameId=String(req.body?.game_id||"").trim();
  if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(gameId))return res.status(400).json({error:"Invalid game."});
  const game=(await db.query("SELECT id FROM games WHERE id=$1 LIMIT 1",[gameId])).rows[0];
  if(!game)return res.status(404).json({error:"Game not found."});
  const user=await me(req); if(!user)return res.status(401).json({error:"Please log in to join a game."});
  const servers=await db.query("SELECT s.server_id,COUNT(p.user_id)::int AS count FROM game_servers s LEFT JOIN game_server_players p ON p.server_id=s.server_id AND p.last_seen_at>=NOW()-INTERVAL '45 seconds' WHERE s.game_id=$1 GROUP BY s.server_id ORDER BY count ASC,s.server_id ASC",[gameId]);
  let selected=null;
  for(const row of servers.rows){
    if(row.count<40){selected=row.server_id;break;}
  }
  if(!selected) selected=`game-${gameId}-${Date.now().toString(36)}`;
  await db.query("INSERT INTO game_servers(server_id,game_id,last_active_at) VALUES($1,$2,NOW()) ON CONFLICT(server_id) DO UPDATE SET last_active_at=NOW(),game_id=EXCLUDED.game_id",[selected,gameId]);
  await db.query("INSERT INTO game_server_players(server_id,user_id,username,last_seen_at) VALUES($1,$2,$3,NOW()) ON CONFLICT(server_id,user_id) DO UPDATE SET username=EXCLUDED.username,last_seen_at=NOW()",[selected,String(user.user_id),user.username]);
  await db.query("UPDATE games SET players=(SELECT COUNT(*) FROM game_server_players sp JOIN game_servers gs ON gs.server_id=sp.server_id WHERE gs.game_id=games.id AND sp.last_seen_at>=NOW()-INTERVAL '45 seconds'),visits=visits+1,updated_at=NOW() WHERE id=$1",[gameId]);
  const count=await db.query("SELECT COUNT(*)::int AS n FROM game_server_players WHERE server_id=$1 AND last_seen_at>=NOW()-INTERVAL '45 seconds'",[selected]);
  res.json({serverId:selected,count:count.rows[0].n,max:40,username:user.username});
}