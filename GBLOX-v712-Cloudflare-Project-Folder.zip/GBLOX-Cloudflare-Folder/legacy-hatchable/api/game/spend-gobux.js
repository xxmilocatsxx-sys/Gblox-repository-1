import { db } from "hatchable";

export const access = "public";
export const methods = ["POST"];

const PRICE = 20;
const CREATOR_REWARD = PRICE * 2;
const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");

async function tokenHash(t){
  return b64(await crypto.subtle.digest("SHA-256", enc.encode(t)));
}
function getCookie(req,name){
  const c=String(req.headers?.cookie||"");
  const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));
  return m ? m[1] : null;
}

async function sessionUser(req){
  const gblocksRaw=getCookie(req,"gblocks_session");
  const raw=gblocksRaw || getCookie(req,"groblox_session");
  if(!raw) return null;
  const th=await tokenHash(raw);
  const table=gblocksRaw?"gblocks_sessions":"account_sessions";
  const q=await db.query(
    `SELECT p.user_id,p.username,p.banned,p.terminated,g.gobux_infinite,g.balance FROM ${table} s JOIN profiles p ON p.user_id=s.user_id LEFT JOIN gobux_accounts g ON g.user_id=p.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,
    [th]
  );
  const u=q.rows[0];
  return u && !u.banned && !u.terminated ? u : null;
}

export default async function(req,res){
  const user=await sessionUser(req);
  if(!user) return res.status(401).json({error:"Log in to play this game."});

  let transactionId=String(req.body?.transaction_id||"").trim();
  if(transactionId.length<16 || transactionId.length>128){
    return res.status(400).json({error:"Invalid transaction ID."});
  }

  const existing=await db.query(
    "SELECT transaction_id,amount,created_at FROM gobux_game_purchases WHERE transaction_id=$1 AND buyer_user_id=$2 LIMIT 1",
    [transactionId,user.user_id]
  );
  if(existing.rows[0]){
    const wallet=await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1",[user.user_id]);
    return res.json({
      ok:true,
      duplicate:true,
      transaction_id:transactionId,
      amount:PRICE,
      recipient:"Builder",
      balance:wallet.rows[0]?.gobux_infinite ? "∞" : Number(wallet.rows[0]?.balance||0)
    });
  }

  // Resolve Alt from the real GBlocks player profile. Admin accounts are
  // Stable recipient binding: resolve the Alt account by immutable user_id, never by username.
  const recipient=await db.query(
    "SELECT p.user_id,p.username FROM profiles p WHERE p.user_id=$1 LIMIT 1",
    ["c66afd7c-03ea-42bc-b771-69b836f7049f"]
  );
  if(!recipient.rows[0]) return res.status(503).json({error:"The Builder GBlocks player account does not exist. Your Gobux was not charged."});

  const altId="c66afd7c-03ea-42bc-b771-69b836f7049f";
  try{
    const transfer=await db.transaction([
      {
        sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",
        params:[String(user.user_id)]
      },
      {
        sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",
        params:[altId]
      },
      {
        sql:"UPDATE gobux_accounts SET balance=CASE WHEN gobux_infinite THEN balance ELSE balance-$1 END,updated_at=NOW() WHERE user_id=$2 AND (gobux_infinite=true OR balance >= $1) RETURNING user_id",
        params:[PRICE,String(user.user_id)]
      },
      {
        sql:"INSERT INTO gobux_pending_credits (transaction_id,recipient_user_id,source_type,source_id,amount,available_at) VALUES ($1,$2,'game',$3,$4,NOW()+INTERVAL '5 days')",
        params:["GAME-"+transactionId,altId,transactionId,String(CREATOR_REWARD)]
      },
      {
        sql:"INSERT INTO gobux_transactions (transaction_id,user_id,counterparty_user_id,amount,direction,source_type,status,pending_until) VALUES ($1,$2,$3,$4,'debit','game','completed',NULL)",
        params:[transactionId,String(user.user_id),altId,String(PRICE)]
      },
      {
        sql:"INSERT INTO gobux_transactions (transaction_id,user_id,counterparty_user_id,amount,direction,source_type,status,pending_until) VALUES ($1,$2,$3,$4,'credit','game','pending',NOW()+INTERVAL '5 days')",
        params:["GAME-"+transactionId,altId,String(user.user_id),String(CREATOR_REWARD)]
      },
      {
        sql:"INSERT INTO gobux_game_purchases (transaction_id,buyer_user_id,recipient_user_id,amount,pending_transaction_id) VALUES ($1,$2,$3,$4,$5)",
        params:[transactionId,String(user.user_id),altId,PRICE,"GAME-"+transactionId]
      }
    ]);
  if(!transfer.results?.[2]?.rows?.length) throw new Error("balance check failed");
  }catch(e){
    const msg=String(e||"");
    if(msg.toLowerCase().includes("duplicate") && msg.includes("gobux_game_purchases")){
      const again=await db.query("SELECT transaction_id,amount FROM gobux_game_purchases WHERE transaction_id=$1 AND buyer_user_id=$2 LIMIT 1",[transactionId,String(user.user_id)]);
      if(again.rows[0]) return res.json({ok:true,duplicate:true,transaction_id:transactionId,amount:PRICE,recipient:"Builder"});
    }
    if(msg.toLowerCase().includes("check") || msg.toLowerCase().includes("balance")){
      return res.status(402).json({error:"You need 20 Gobux to purchase this."});
    }
    return res.status(500).json({error:"Purchase failed. Your Gobux was not charged."});
  }

  const wallet=await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1",[String(user.user_id)]);
  return res.json({
    ok:true,
    transaction_id:transactionId,
    amount:PRICE,
    recipient:"Builder",
    balance:wallet.rows[0]?.gobux_infinite ? "∞" : Number(wallet.rows[0]?.balance||0),
    message:"Purchase successful! 20 Gobux was spent. Builder earns 40 Gobux, pending for 5 days."
  });
}