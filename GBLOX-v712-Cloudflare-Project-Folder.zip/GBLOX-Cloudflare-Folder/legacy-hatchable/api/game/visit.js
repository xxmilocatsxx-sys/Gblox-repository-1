import { db } from "hatchable";
export const access = "public";
export const methods = ["POST"];
const enc = new TextEncoder();
const b64 = x => btoa(String.fromCharCode(...new Uint8Array(x)));
const b64url = x => b64(x).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
async function hashes(t) {
  const digest = await crypto.subtle.digest("SHA-256", enc.encode(t));
  return [b64(digest), b64url(digest)];
}
function cookie(req, name) {
  if (req.cookies?.[name]) return String(req.cookies[name]);
  const raw = String(req.headers?.cookie || "");
  const match = raw.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]*)"));
  return match ? decodeURIComponent(match[1]) : "";
}
export default async function(req, res) {
  const gameId = String(req.body?.game_id || "").trim();
  const sessionId = String(req.body?.visit_session_id || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(gameId)) return res.status(400).json({ error: "Invalid game." });
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(sessionId)) return res.status(400).json({ error: "Invalid visit session." });
  const gblocksToken = cookie(req, "gblocks_session");
  const legacyToken = cookie(req, "groblox_session");
  const tokenValue = gblocksToken || legacyToken;
  if (!tokenValue) return res.status(401).json({ error: "Log in to visit a game." });
  const tokenHashes = await hashes(tokenValue);
  let userQuery = { rows: [] };
  if (gblocksToken) {
    userQuery = await db.query(
      "SELECT p.user_id,p.banned,p.terminated FROM gblocks_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=ANY($1::text[]) AND s.expires_at>NOW() LIMIT 1",
      [tokenHashes]
    );
  }
  if (!userQuery.rows.length && legacyToken) {
    const legacyHashes = await hashes(legacyToken);
    userQuery = await db.query(
      "SELECT p.user_id,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=ANY($1::text[]) AND s.expires_at>NOW() LIMIT 1",
      [legacyHashes]
    );
  }
  const user = userQuery.rows[0];
  if (!user || user.banned || user.terminated) return res.status(403).json({ error: "Account cannot visit games." });
  const exists = await db.query("SELECT id,visits FROM games WHERE id=$1", [gameId]);
  if (!exists.rows.length) return res.status(404).json({ error: "Game not found." });
  const receipt = await db.query(
    "INSERT INTO game_visit_receipts(user_id,game_id,visit_session_id) SELECT $1,$2,$3 WHERE NOT EXISTS (SELECT 1 FROM game_visit_receipts WHERE user_id=$1 AND game_id=$2 AND visited_at > NOW() - INTERVAL '1 minute') ON CONFLICT(user_id,game_id,visit_session_id) DO NOTHING RETURNING game_id",
    [user.user_id, gameId, sessionId]
  );
  if (!receipt.rows.length) {
    const current = await db.query("SELECT visits FROM games WHERE id=$1", [gameId]);
    return res.json({ visits: current.rows[0]?.visits ?? exists.rows[0].visits ?? 0, counted: false });
  }
  const bumped = await db.query("UPDATE games SET visits=visits+1 WHERE id=$1 RETURNING visits", [gameId]);
  if (!bumped.rows.length) return res.status(404).json({ error: "Game not found." });
  return res.json({ visits: bumped.rows[0].visits, counted: true });
}