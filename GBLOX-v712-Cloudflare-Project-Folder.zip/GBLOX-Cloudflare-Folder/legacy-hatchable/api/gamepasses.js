import { db } from "hatchable";
export const access="public";
export const methods=["GET","POST"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function hash(v){return b64(await crypto.subtle.digest("SHA-256",enc.encode(v)))}
function cookie(req,name){if(req.cookies?.[name])return String(req.cookies[name]);const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));return m?decodeURIComponent(m[1]):null}
async function viewer(req){const raw=cookie(req,"gblocks_session")||cookie(req,"groblox_session");if(!raw)return null;const h=await hash(raw);const table=cookie(req,"gblocks_session")?"gblocks_sessions":"account_sessions";const q=await db.query(`SELECT p.user_id,p.username,p.banned,p.terminated FROM ${table} s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1`,[h]);return q.rows[0]||null}
export default async function(req,res){
 res.setHeader("Cache-Control","no-store");
 if(req.method==="GET"){
  const owner=String(req.query?.userid||req.query?.userId||"").trim();
  if(!owner)return res.status(400).json({error:"userid is required"});
  const q=await db.query("SELECT gp.id,gp.name,gp.description,gp.price,gp.owner_user_id,gp.created_at,p.username AS owner_username,false AS owned FROM gamepasses gp JOIN profiles p ON p.user_id=gp.owner_user_id WHERE gp.owner_user_id=$1 AND gp.active=true ORDER BY gp.created_at DESC",[owner]);
  // Ownership is resolved against the signed-in account; anonymous visitors see owned=false.
  const u=await viewer(req);let rows=q.rows;
  if(u) {const owned=await db.query("SELECT gamepass_id FROM gamepass_purchases WHERE buyer_user_id=$1",[u.user_id]);const ids=new Set(owned.rows.map(x=>x.gamepass_id));rows=rows.map(x=>({...x,owned:ids.has(x.id)}));}
  else rows=rows.map(x=>({...x,owned:false}));
  return res.json({gamepasses:rows,viewer_user_id:u?.user_id||null});
 }
 if(req.method==="POST"){
  const u=await viewer(req);if(!u)return res.status(401).json({error:"Log in to create a gamepass."});if(u.banned||u.terminated)return res.status(403).json({error:"This account cannot create gamepasses."});
  const name=String(req.body?.name||"").trim(),description=String(req.body?.description||"").trim().slice(0,500),price=Number(req.body?.price);
  if(name.length<2||name.length>50)return res.status(400).json({error:"Name must be 2–50 characters."});
  if(!Number.isInteger(price)||price<1||price>1000000)return res.status(400).json({error:"Price must be between 1 and 1,000,000 Gobux."});
  const id="gp_"+crypto.randomUUID().replace(/-/g,"");
  await db.query("INSERT INTO gamepasses(id,owner_user_id,name,description,price) VALUES($1,$2,$3,$4,$5)",[id,u.user_id,name,description,price]);
  return res.status(201).json({ok:true,id,name,description,price});
 }
 return res.status(405).json({error:"Method not allowed"});
}