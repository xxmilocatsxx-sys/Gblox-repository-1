import { db } from "hatchable";
import { clientIp, activeIpRestriction, recordLoginIp } from "../../lib/ip-restrictions.js";

export const access = "public";
export const methods = ["POST"];

const te=new TextEncoder();
function b64ToBytes(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
function bytesToB64(bytes){return btoa(String.fromCharCode(...bytes));}
function bytesToB64Url(bytes){return bytesToB64(bytes).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");}
async function hashPassword(password,salt){const key=await crypto.subtle.importKey("raw",te.encode(password),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:210000,hash:"SHA-256"},key,256);return bytesToB64(new Uint8Array(bits));}
function randomBytes(n){const a=new Uint8Array(n);crypto.getRandomValues(a);return a;}
async function hashToken(token){const data=await crypto.subtle.digest("SHA-256",te.encode(token));return bytesToB64(new Uint8Array(data));}
export default async function(req,res){
 const body=req.body||{},username=String(body.username||"").trim(),password=typeof body.password==="string"?body.password:"";
 if(!username||!password)return res.status(400).json({error:"Enter your username and password."});
 const q=await db.query("SELECT c.user_id,c.username,c.password_salt,c.password_hash,p.display_name,p.moderation_status,p.moderation_note,p.deactivated_at,p.recovery_deadline FROM gblocks_credentials c JOIN gblocks_players p ON p.user_id=c.user_id WHERE lower(c.username)=lower($1) LIMIT 1",[username]);
 if(!q.rows.length)return res.status(401).json({error:"Incorrect username or password."});
 const account=q.rows[0],actual=await hashPassword(password,b64ToBytes(account.password_salt));
 if(actual!==account.password_hash)return res.status(401).json({error:"Incorrect username or password."});if(account.deactivated_at)return res.status(403).json({error:"This account is deactivated. You can reactivate it at any time.",deactivated:true,reactivation_required:true,username:account.username,recovery_deadline:account.recovery_deadline,redirect:"/account-deactivated.html"});
 if(account.moderation_status!=="active")return res.status(403).json({error:"This account is currently "+(account.moderation_status==="terminated"?"Terminated":"Banned")+".",moderation_status:account.moderation_status,moderation_note:account.moderation_note||""});
 const remoteIp=clientIp(req);const restriction=await activeIpRestriction(remoteIp);if(restriction)return res.status(403).json({error:"Sign-in is restricted from this network address.",restricted:true,reason:restriction.reason});
 await recordLoginIp(account.user_id,remoteIp);
 const raw=bytesToB64Url(randomBytes(32)),tokenHash=await hashToken(raw);
 await db.query("DELETE FROM gblocks_sessions WHERE expires_at < NOW()");
 await db.query("INSERT INTO gblocks_sessions(token_hash,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 days')",[tokenHash,account.user_id]);
 await db.query("INSERT INTO login_history(user_id) VALUES($1)",[account.user_id]);
 res.cookie("gblocks_session",raw,{httpOnly:true,secure:true,sameSite:"lax",path:"/",maxAge:2592000});
 return res.json({ok:true,session_token:raw,user:{user_id:account.user_id,username:account.username,display_name:account.display_name}});
}