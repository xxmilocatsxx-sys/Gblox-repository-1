import { db } from "hatchable";

export const access = "public";
export const methods = ["POST"];
const te=new TextEncoder();
function bytesToB64(bytes){return btoa(String.fromCharCode(...bytes));}
function bytesToB64Url(bytes){return bytesToB64(bytes).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");}
async function hashPassword(password,salt){const key=await crypto.subtle.importKey("raw",te.encode(password),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:210000,hash:"SHA-256"},key,256);return bytesToB64(new Uint8Array(bits));}
function randomBytes(n){const a=new Uint8Array(n);crypto.getRandomValues(a);return a;}
function makeId(){return Array.from(randomBytes(16),b=>b.toString(16).padStart(2,"0")).join("");}
function validUsername(v){return /^[A-Za-z0-9_]{3,20}$/.test(v);}
function validPassword(v){return typeof v==="string"&&v.length>=8&&v.length<=128;}
async function hashToken(token){const data=await crypto.subtle.digest("SHA-256",te.encode(token));return bytesToB64(new Uint8Array(data));}
export default async function(req,res){
 const body=req.body||{},username=String(body.username||"").trim(),displayName=String(body.display_name||"").trim().slice(0,40),password=typeof body.password==="string"?body.password:"",bio=String(body.bio||"").slice(0,160);
 if(!validUsername(username))return res.status(400).json({error:"Username must be 3-20 letters, numbers, or underscores."});
 if(!displayName)return res.status(400).json({error:"Display name is required."});
 if(displayName.toLowerCase()==='builder')return res.status(409).json({error:"The display name Builder is reserved for the official GBlocks Builder account."});
 if(!validPassword(password))return res.status(400).json({error:"Password must be 8-128 characters."});
 const taken=await db.query("SELECT user_id FROM gblocks_players WHERE lower(username)=lower($1) OR EXISTS (SELECT 1 FROM jsonb_array_elements_text(username_history) h WHERE lower(h)=lower($1)) LIMIT 1",[username]);
 const credentialTaken=await db.query("SELECT user_id FROM gblocks_credentials WHERE lower(username)=lower($1) LIMIT 1",[username]);
 if(taken.rows.length||credentialTaken.rows.length)return res.status(409).json({error:"That username is already taken or was previously used. Choose another username."});
 const userId=makeId(),salt=randomBytes(16),passwordHash=await hashPassword(password,salt);const numberRow=await db.query("UPDATE gblocks_user_number_sequence SET next_number=next_number+1 WHERE id=1 RETURNING next_number-1 AS user_number");if(!numberRow.rows[0])return res.status(500).json({error:"Account numbering is unavailable. Please try again later."});const userNumber=Number(numberRow.rows[0].user_number);
 try{
  await db.query("INSERT INTO gblocks_credentials(user_id,username,password_salt,password_hash) VALUES($1,$2,$3,$4)",[userId,username,bytesToB64(salt),passwordHash]);
  const isGobuxAdmin = username.toLowerCase() === "gobuxadmin";
  const isTubers93 = username.toLowerCase() === "tubers93";
  const tubers93Avatar={image_url:"/tubers93-avatar.png",source:"GBlocks fixed Tubers93 avatar"};
  const toobers93Avatar={image_url:"/toobers93back_alt.png",source:"GBlocks fixed Toobers93 avatar"};
  const fixedAvatar=username.toLowerCase()==='toobers93'?toobers93Avatar:tubers93Avatar;
  await db.query("INSERT INTO gblocks_players(user_id,username,display_name,bio,username_history,avatar,gobux) VALUES($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7)",[userId,username,displayName,bio,JSON.stringify([username]),JSON.stringify((isTubers93||username.toLowerCase()==='toobers93')?fixedAvatar:{}),100]);
  await db.query("INSERT INTO profiles(user_id,username,display_name,avatar,user_number,role) VALUES($1,$2,$3,$4::jsonb,$5,$6)",[userId,username,displayName,JSON.stringify((isTubers93||username.toLowerCase()==='toobers93')?fixedAvatar:{}),userNumber,(isTubers93||username.toLowerCase()==='toobers93')?'administrator':'user']);
  if(isTubers93 || username.toLowerCase()==='toobers93'){
    await db.query("INSERT INTO profiles(user_id,username,display_name,avatar,role) VALUES($1,$2,$3,$4::jsonb,'administrator') ON CONFLICT(user_id) DO UPDATE SET username=$2,display_name=$3,avatar=$4::jsonb,role='administrator'",[userId,username,displayName,JSON.stringify(fixedAvatar)]);
  }
  if(isTubers93){
    await db.query("INSERT INTO restricted_admin_badges(username_key,username,badge_name,badge_icon,applied_by) VALUES(LOWER($1),$1,'Restricted Admin','⚠️','System signup policy') ON CONFLICT(username_key) DO UPDATE SET username=EXCLUDED.username,badge_name='Restricted Admin',badge_icon='⚠️'",[username]);
  }
  if(isGobuxAdmin){
    await db.query("INSERT INTO profiles(user_id,username,display_name,verified,follower_bonus,role) VALUES($1,$2,$3,true,5000,'user') ON CONFLICT(user_id) DO UPDATE SET verified=true,follower_bonus=5000",[userId,username,displayName]);
  }
  await db.query("INSERT INTO gobux_accounts(user_id,balance,last_daily_at,gobux_infinite) VALUES($1,100,NULL,false) ON CONFLICT(user_id) DO NOTHING",[userId]);
  await db.query("INSERT INTO username_history(username,user_id) VALUES($1,$2)",[username,userId]);
 }catch(e){await db.query("DELETE FROM gblocks_credentials WHERE user_id=$1",[userId]).catch(()=>{});return res.status(500).json({error:"Account could not be created. Please try again."});}
 const raw=bytesToB64Url(randomBytes(32)),tokenHash=await hashToken(raw);
 await db.query("INSERT INTO gblocks_sessions(token_hash,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 days')",[tokenHash,userId]);
 res.cookie("gblocks_session",raw,{httpOnly:true,secure:true,sameSite:"lax",path:"/",maxAge:2592000});
 return res.status(201).json({ok:true,session_token:raw,user:{user_id:userId,user_number:userNumber,public_id:`GBlocks User #${userNumber}`,username,display_name:displayName}});
}