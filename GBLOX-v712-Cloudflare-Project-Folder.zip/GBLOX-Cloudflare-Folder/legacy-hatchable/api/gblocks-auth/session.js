import { db } from "hatchable";
export const access="public"; export const methods=["GET"];
const te=new TextEncoder();
function bytesToB64(bytes){return btoa(String.fromCharCode(...bytes));}
function tokenFrom(req){let t=req.headers?.["x-gblocks-session"]||req.headers?.["X-Gblocks-Session"]||null;if(t)return String(t).trim();t=req.cookies?.gblocks_session||req.cookies?.groblox_session||null;if(t){try{return decodeURIComponent(String(t))}catch{return String(t)}}const raw=String(req.headers?.cookie||req.headers?.Cookie||"");for(const part of raw.split(";")){const i=part.indexOf("=");if(i<0)continue;const name=part.slice(0,i).trim();if(name!=="gblocks_session"&&name!=="groblox_session")continue;const value=part.slice(i+1).trim();try{return decodeURIComponent(value)}catch{return value}}return ""}
async function hashToken(token){const data=await crypto.subtle.digest("SHA-256",te.encode(token));return bytesToB64(new Uint8Array(data));}
export default async function(req,res){
 const token=tokenFrom(req);if(!token)return res.status(401).json({authenticated:false});
 const q=await db.query("SELECT s.user_id,p.username,p.display_name,p.bio,p.avatar,COALESCE(g.balance,0) AS gobux,p.moderation_status,p.moderation_note,p.temp_ban_until,p.moderation_violation_count,p.last_ban_duration_days,p.deactivated_at,p.legacy_status,p.legacy_bot_enabled FROM gblocks_sessions s JOIN gblocks_players p ON p.user_id=s.user_id LEFT JOIN gobux_accounts g ON g.user_id=p.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await hashToken(token)]);
 if(!q.rows.length)return res.status(401).json({authenticated:false});
 let p=q.rows[0];
 if(p.moderation_status==="banned" && p.temp_ban_until && new Date(p.temp_ban_until)<=new Date()){
   const restored=await db.query("UPDATE gblocks_players SET moderation_status='active',moderation_note='',temp_ban_until=NULL WHERE user_id=$1 RETURNING username,display_name,bio,moderation_status,moderation_note,temp_ban_until,moderation_violation_count,last_ban_duration_days",[p.user_id]);
   p={...p,...(restored.rows[0]||{})};
 }
 const active=p.moderation_status==="banned" || p.moderation_status==="terminated";
 const history=await db.query("SELECT logged_in_at FROM login_history WHERE user_id=$1 ORDER BY logged_in_at DESC LIMIT 20",[p.user_id]);
 return res.json({authenticated:true,player:p,login_history:history.rows.map(x=>x.logged_in_at),moderation:{active,status:p.moderation_status,unban_at:p.temp_ban_until,reason:p.moderation_note||"",duration_days:p.last_ban_duration_days||0}});
}