import { db } from "hatchable";
export const access = "public";
export const methods = ["POST"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function getCookie(req,name){const c=String(req.headers?.cookie||"");const m=c.match(new RegExp("(?:^|;\\s*)"+name+"=([^;]*)"));return m?m[1]:null}
export default async function(req,res){
  const raw=getCookie(req,"gblocks_session") || getCookie(req,"groblox_session");
  if(!raw)return res.status(401).json({signedIn:false,error:"Log in to claim your daily Gobux."});
  const th=await tokenHash(raw);
  const session=await db.query(
    "SELECT s.user_id,p.username,p.banned,p.terminated FROM gblocks_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",
    [th]
  );
  if(!session.rows[0])return res.status(401).json({signedIn:false,error:"Log in to claim your daily Gobux."});
  const u=session.rows[0];
  if(u.banned||u.terminated)return res.status(403).json({signedIn:false,error:"Account is not active."});
  await db.query("INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",[String(u.user_id)]);
  const reward=5;
  const claimed=await db.query("UPDATE gobux_accounts SET balance=CASE WHEN gobux_infinite THEN balance ELSE balance+$1 END,last_daily_at=NOW(),updated_at=NOW() WHERE user_id=$2 AND (last_daily_at IS NULL OR last_daily_at < date_trunc('day',NOW())) RETURNING balance,gobux_infinite",[reward,String(u.user_id)]);
  if(!claimed.rows.length){
    const wallet=await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1",[String(u.user_id)]);
    const w=wallet.rows[0];
    return res.json({signedIn:true,claimed:false,reward:0,balance:w?.gobux_infinite?"∞":Number(w?.balance||0),infinite:Boolean(w?.gobux_infinite),message:"Daily Gobux already claimed today."});
  }
  const row=claimed.rows[0];
  res.json({signedIn:true,claimed:true,reward:row.gobux_infinite?0:reward,balance:row.gobux_infinite?"∞":Number(row.balance),infinite:Boolean(row.gobux_infinite),message:row.gobux_infinite?"Daily Gobux checked in.":"You received 5 daily Gobux!"});
}