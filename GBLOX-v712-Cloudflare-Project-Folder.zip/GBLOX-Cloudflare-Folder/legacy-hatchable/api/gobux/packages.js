export const access="public";
export const methods=["GET"];
const PACKAGES=[{id:"gobux_100",gobux:100,cents:99},{id:"gobux_500",gobux:500,cents:499},{id:"gobux_1000",gobux:1000,cents:999},{id:"gobux_5000",gobux:5000,cents:3999},{id:"gobux_10000",gobux:10000,cents:6999}];
export default async function(req,res){res.json({currency:"USD",packages:PACKAGES.map(p=>({...p,price:(p.cents/100).toFixed(2)}))});}