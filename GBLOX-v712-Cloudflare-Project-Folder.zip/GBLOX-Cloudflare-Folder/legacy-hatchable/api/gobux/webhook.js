import { db, config, webhooks } from "hatchable";
export const access="public"; export const methods=["POST"];
async function grant(tx,providerId){
await db.query("BEGIN");
try{
await db.query("SELECT pg_advisory_xact_lock(hashtext($1))",[tx]);
const q=await db.query("SELECT transaction_id,user_id,gobux_amount,money_amount_cents,currency,status FROM gobux_purchase_ledger WHERE transaction_id=$1 LIMIT 1",[tx]);const p=q.rows[0];
if(!p){await db.query("ROLLBACK");return false}
if(p.status==="completed"){await db.query("COMMIT");return true}
await db.query("INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",[p.user_id]);
const w=await db.query("UPDATE gobux_accounts SET balance=balance+$1,updated_at=NOW() WHERE user_id=$2 RETURNING balance,gobux_infinite",[Number(p.gobux_amount),p.user_id]);if(!w.rows.length)throw new Error("wallet update failed");
const b=w.rows[0];
const u=await db.query("UPDATE gobux_purchase_ledger SET status='completed',provider_status='paid',provider_transaction_id=COALESCE(provider_transaction_id,$1),resulting_balance=$2,reconciliation_required=false,paid_at=COALESCE(paid_at,NOW()),updated_at=NOW() WHERE transaction_id=$3 AND status<>'completed' RETURNING transaction_id",[providerId,b.gobux_infinite?null:Number(b.balance),tx]);
if(!u.rows.length){await db.query("ROLLBACK");return true}
await db.query("INSERT INTO gobux_earnings_ledger (transaction_id,user_id,gross_amount_cents,provider_fee_cents,net_amount_cents,currency,status,earned_at,updated_at) VALUES ($1,$2,$3,0,$3,$4,'awaiting_payout',NOW(),NOW()) ON CONFLICT (transaction_id) DO NOTHING",[tx,p.user_id,Number(p.money_amount_cents),String(p.currency||"usd").toLowerCase()]);
await db.query("INSERT INTO audit_logs (action,target_user_id,target_username,reason,details) SELECT 'GOBUX_REAL_MONEY_PURCHASE',$1,p.username,'Confirmed provider payment',$2::jsonb FROM profiles p WHERE p.user_id=$1",[p.user_id,JSON.stringify({transaction_id:tx,gobux_amount:Number(p.gobux_amount),provider_transaction_id:providerId||null,resulting_balance:b.gobux_infinite?"∞":Number(b.balance)})]);
await db.query("COMMIT");return true;
}catch(e){try{await db.query("ROLLBACK")}catch{}throw e}
}
export default async function(req,res){
let secret="";try{secret=String(await config.get("STRIPE_WEBHOOK_SECRET")||"")}catch{return res.status(503).json({error:"Webhook secret is not configured."})}
const sig=String(req.headers?.["stripe-signature"]||"");const parts=Object.fromEntries(sig.split(",").filter(Boolean).map(k=>k.split("=").map(s=>s.trim())));if(!parts.t||!parts.v1)return res.status(400).json({error:"Invalid Stripe signature."});
const ok=await webhooks.verifyHmac({raw:parts.t+"."+req.rawBody,signature:parts.v1,secret,timestamp:parts.t});if(!ok)return res.status(400).json({error:"Invalid Stripe signature."});
const e=req.body||{},type=String(e.type||""),o=e.data?.object||{},tx=String(o.metadata?.transaction_id||o.client_reference_id||"");
if(type==="checkout.session.completed"||type==="checkout.session.async_payment_succeeded"){
if(type==="checkout.session.completed"&&o.payment_status!=="paid")return res.json({received:true,pending:true});
if(!tx)return res.status(400).json({error:"Missing transaction ID."});
const q=await db.query("UPDATE gobux_purchase_ledger SET provider_transaction_id=COALESCE(provider_transaction_id,$1),provider_payment_intent_id=COALESCE(provider_payment_intent_id,$2),provider_status='paid',paid_at=COALESCE(paid_at,NOW()),updated_at=NOW() WHERE transaction_id=$3 RETURNING transaction_id",[String(o.id||""),String(o.payment_intent||""),tx]);if(!q.rows.length)return res.json({received:true,ignored:true});
try{await grant(tx,String(o.id||""))}catch(err){await db.query("UPDATE gobux_purchase_ledger SET reconciliation_required=true,status='pending',provider_status='paid',updated_at=NOW() WHERE transaction_id=$1",[tx]);console.error("Gobux reconciliation required",tx,err)}
return res.json({received:true})}
if(type==="checkout.session.expired"&&tx){await db.query("UPDATE gobux_purchase_ledger SET status='cancelled',provider_status='expired',updated_at=NOW() WHERE transaction_id=$1 AND status<>'completed'",[tx]);return res.json({received:true})}
if(type==="payment_intent.payment_failed"&&tx){await db.query("UPDATE gobux_purchase_ledger SET status='failed',provider_status='payment_failed',updated_at=NOW() WHERE transaction_id=$1 AND status<>'completed'",[tx]);return res.json({received:true})}
if(type==="charge.refunded"){const pi=String(o.payment_intent||"");await db.query("UPDATE gobux_purchase_ledger SET status='refunded',provider_status='refunded',refund_review_required=true,updated_at=NOW() WHERE provider_payment_intent_id=$1",[pi]);return res.json({received:true})}
if(type==="charge.dispute.created"){const pi=String(o.payment_intent||"");await db.query("UPDATE gobux_purchase_ledger SET dispute_review_required=true,provider_status='disputed',updated_at=NOW() WHERE provider_payment_intent_id=$1",[pi]);return res.json({received:true})}
res.json({received:true,ignored:true});
}