import { db, storage } from "hatchable";
export const access="public";
export const methods=["GET"];

const enc=new TextEncoder(),b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
async function h(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
async function viewer(req){
  const t=String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1];
  if(!t)return null;
  const r=await db.query("SELECT p.user_id FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",[await h(t)]);
  return r.rows[0]||null;
}
export default async function(req,res){
  try{
    const q=String(req.query?.q||"").trim();
    const v=await viewer(req);
    const viewerId=v?.user_id||null;
    let r;
    if(viewerId){
      r=await db.query(
        "SELECT g.id,g.name,g.description,g.icon_url,g.icon_storage_key,COALESCE(g.claimed_owner_id,g.owner_id) AS owner_id,g.created_at,g.is_private,g.verified,COALESCE(cp.display_name,cp.username,op.display_name,op.username,CASE WHEN COALESCE(g.claimed_owner_id,g.owner_id)='unknown-owner' THEN 'Unknown Owner' ELSE 'Unknown Owner' END) AS owner_display_name,COALESCE(cp.username,op.username,CASE WHEN COALESCE(g.claimed_owner_id,g.owner_id)='unknown-owner' THEN 'Unknown Owner' ELSE '' END) AS owner_username,COALESCE(cp.verified,op.verified,FALSE) AS owner_verified,COUNT(gm.user_id)::int AS member_count,COALESCE(vm.role,'') AS viewer_role FROM groups g LEFT JOIN profiles op ON op.user_id=g.owner_id LEFT JOIN profiles cp ON cp.user_id=g.claimed_owner_id LEFT JOIN group_members gm ON gm.group_id=g.id LEFT JOIN group_members vm ON vm.group_id=g.id AND vm.user_id=$2 WHERE COALESCE(g.moderation_deleted,FALSE)=FALSE AND COALESCE(g.moderation_banned,FALSE)=FALSE AND ($1='' OR LOWER(g.name) LIKE LOWER('%'||$1||'%')) AND (g.is_private=false OR vm.user_id IS NOT NULL) GROUP BY g.id,vm.role,op.display_name,op.username,cp.display_name,cp.username,op.verified,cp.verified ORDER BY g.created_at DESC LIMIT 100",
        [q,viewerId]
      );
    }else{
      r=await db.query(
        "SELECT g.id,g.name,g.description,g.icon_url,g.icon_storage_key,COALESCE(g.claimed_owner_id,g.owner_id) AS owner_id,g.created_at,g.is_private,g.verified,COALESCE(cp.display_name,cp.username,op.display_name,op.username,'Unknown owner') AS owner_display_name,COALESCE(cp.username,op.username,'') AS owner_username,COALESCE(cp.verified,op.verified,FALSE) AS owner_verified,COUNT(gm.user_id)::int AS member_count,'' AS viewer_role FROM groups g LEFT JOIN profiles op ON op.user_id=g.owner_id LEFT JOIN profiles cp ON cp.user_id=g.claimed_owner_id LEFT JOIN group_members gm ON gm.group_id=g.id WHERE COALESCE(g.moderation_deleted,FALSE)=FALSE AND COALESCE(g.moderation_banned,FALSE)=FALSE AND ($1='' OR LOWER(g.name) LIKE LOWER('%'||$1||'%')) AND g.is_private=false GROUP BY g.id,op.display_name,op.username,cp.display_name,cp.username,op.verified,cp.verified ORDER BY g.created_at DESC LIMIT 100",
        [q]
      );
    }
    const rows=await Promise.all(r.rows.map(async row=>({...row,icon_url:row.icon_storage_key?await storage.url(row.icon_storage_key):row.icon_url})));res.json(rows);
  }catch(e){
    console.error("groups/list error:",e);
    res.status(500).json({error:"Could not load communities."});
  }
}