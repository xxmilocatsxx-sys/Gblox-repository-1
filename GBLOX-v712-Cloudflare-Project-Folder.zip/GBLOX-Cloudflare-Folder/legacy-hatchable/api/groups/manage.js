import {db} from "hatchable";
import {refreshGroupOwnerAdminPlayerVerification} from "../../lib/verification.js";
export const access="public"; export const methods=["POST"];
const enc=new TextEncoder(),b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,""); async function h(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
async function me(req){const t=String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1];if(!t)return null;const r=await db.query("SELECT p.user_id,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",[await h(t)]);return r.rows[0]||null}
export default async function(req,res){
 const u=await me(req); if(!u)return res.status(401).json({error:"Log in first."});
 const groupId=String(req.body?.group_id||""), target=String(req.body?.user_id||""), role=String(req.body?.role||"member");
 if(!groupId||!target||!["member","admin"].includes(role))return res.status(400).json({error:"Invalid community management request."});
 const special=await db.query("SELECT 1 FROM groups WHERE id=$1 AND lower(name)=lower('Beta Testers') AND owner_id='1'",[groupId]);
 if(special.rows.length)return res.status(403).json({error:"Beta Testers roles are assigned automatically: Premium members are Beta Testers and administrators are Beta Testers+."});
 const actor=await db.query("SELECT role FROM group_members WHERE group_id=$1 AND user_id=$2",[groupId,u.user_id]);
 if(!["owner","admin"].includes(actor.rows[0]?.role))return res.status(403).json({error:"Community owner or admin access required."});
 const targetRow=await db.query("SELECT role FROM group_members WHERE group_id=$1 AND user_id=$2",[groupId,target]);
 if(!targetRow.rows[0])return res.status(404).json({error:"Member not found."});
 if(targetRow.rows[0].role==="owner")return res.status(403).json({error:"The community owner cannot be changed here."});
 if(actor.rows[0].role==="admin"&&targetRow.rows[0].role==="admin"&&role==="member")return res.status(403).json({error:"Only the owner can remove another admin."});
 await db.query("UPDATE group_members SET role=$1 WHERE group_id=$2 AND user_id=$3",[role,groupId,target]);
 await refreshGroupOwnerAdminPlayerVerification();
 res.json({ok:true,role});
}