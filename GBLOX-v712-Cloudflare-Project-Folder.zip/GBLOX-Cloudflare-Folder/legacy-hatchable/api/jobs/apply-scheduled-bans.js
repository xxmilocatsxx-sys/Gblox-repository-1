import { db } from "hatchable";

export const access="scheduler";
export const methods=["POST"];

async function sendDiscord(action, username, userNumber, reason, moderatorNote, duration, adminUsername){
  const webhook=process.env.GROBLOX_DISCORD_BANS_WEBHOOK||process.env.GROBLOX_DISCORD_WEBHOOK;
  const token=process.env.GROBLOX_DISCORD_BOT_TOKEN;
  const channel=process.env.GROBLOX_DISCORD_BANS_CHANNEL_ID||process.env.GROBLOX_DISCORD_LOG_CHANNEL_ID;
  const embed={title:"GBLOCKS • "+action,fields:[
    {name:"User",value:String(username||"Unknown"),inline:true},
    {name:"User ID",value:String(userNumber||"Unknown"),inline:true},
    {name:"Action",value:action==="TERMINATE"?"Terminated":"Banned",inline:true},
    {name:"Reason",value:String(reason||"GBlocks rules violation").slice(0,1000),inline:false},
    {name:"Moderator Note",value:String(moderatorNote||"—").slice(0,1000),inline:false},
    {name:"Duration",value:action==="TERMINATE"?"Permanent":String(duration)+" days",inline:true},
    {name:"Admin",value:String(adminUsername||"Unknown"),inline:true}
  ],timestamp:new Date().toISOString()};
  try{
    if(webhook){
      await fetch(webhook,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({username:"GBLOCKS Logs",embeds:[embed]})});
    }else if(token&&channel){
      await fetch("https://discord.com/api/v10/channels/"+encodeURIComponent(channel)+"/messages",{method:"POST",headers:{"content-type":"application/json",authorization:"Bot "+token},body:JSON.stringify({embeds:[embed]})});
    }
  }catch(_){}
}

export default async function(req,res){
  const due=await db.query("SELECT * FROM scheduled_bans WHERE status='scheduled' AND starts_at<=NOW() ORDER BY starts_at ASC LIMIT 100");
  let applied=0;
  for(const s of due.rows){
    try{
      const p=await db.query("SELECT * FROM profiles WHERE user_id=$1 LIMIT 1",[s.target_user_id]);
      if(!p.rows[0]){
        await db.query("UPDATE scheduled_bans SET status='failed' WHERE id=$1",[s.id]);
        continue;
      }
      const row=p.rows[0];
      if(s.action==="terminated"){
        await db.query("UPDATE profiles SET banned=false,terminated=true,verified=false,ban_note=$1,temp_ban_until=NULL,last_ban_duration_days=0,moderation_violation_count=moderation_violation_count+1 WHERE user_id=$2",[s.reason,s.target_user_id]);
        await db.query("INSERT INTO username_history(username,user_id) SELECT $1,$2 WHERE NOT EXISTS (SELECT 1 FROM username_history WHERE LOWER(username)=LOWER($1) AND user_id=$2)",[row.username,s.target_user_id]);
        await db.query("INSERT INTO username_reservations(username,reserved_for_user_id,reason) VALUES($1,$2,'terminated_account') ON CONFLICT(username) DO NOTHING",[row.username,s.target_user_id]);
      }else{
        const until=s.ends_at?new Date(s.ends_at):new Date(Date.now()+Number(s.duration_days||3)*86400000);
        await db.query("UPDATE profiles SET banned=true,terminated=false,verified=false,ban_note=$1,temp_ban_until=$2,last_ban_duration_days=$3,moderation_violation_count=moderation_violation_count+1 WHERE user_id=$4",[s.reason,until,Number(s.duration_days||0),s.target_user_id]);
      }
      await db.query("UPDATE scheduled_bans SET status='applied',applied_at=NOW() WHERE id=$1",[s.id]);
      await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",[s.action==="terminated"?"TERMINATE":"BAN",s.target_user_id,row.username,s.created_by_user_id,s.created_by_username,s.reason,JSON.stringify({scheduled:true,startsAt:s.starts_at,endsAt:s.ends_at,durationDays:s.duration_days,moderatorNote:s.moderator_note||""})]).catch(()=>{});
      await sendDiscord(s.action==="terminated"?"TERMINATE":"BAN",row.username,row.user_number,s.reason,s.moderator_note||"",s.duration_days,s.created_by_username);
      applied++;
    }catch(_){
      await db.query("UPDATE scheduled_bans SET status='failed' WHERE id=$1",[s.id]).catch(()=>{});
    }
  }
  return res.json({ok:true,checked:due.rows.length,applied});
}