import { db } from "hatchable";

export const access = "public";
export const methods = ["POST"];

const BOTS = ["GblocksBot","ChatGPT","Hatchable","Discord","TikTok","YouTube","X","Reddit","GitHub"];
const ALWAYS_ON = "Add_me_and_get_Ban";
const APP_BOT = "APP";
// Duty rotation changes presence only; official bot bios must remain untouched.

// Maldives is UTC+5. School-duty days are Monday-Friday.
// Add official school-holiday dates here (YYYY-MM-DD) when a weekday is a full no-school day.
// On those full no-school days the bots still rotate one-by-one instead of all sleeping.
const NO_SCHOOL_DATES = new Set([]);

function maldivesDateParts(now = new Date()) {
  const shifted = new Date(now.getTime() + 5 * 60 * 60 * 1000);
  const iso = shifted.toISOString();
  return {
    date: iso.slice(0, 10),
    dayOfWeek: shifted.getUTCDay(),
    minutes: shifted.getUTCHours() * 60 + shifted.getUTCMinutes()
  };
}

function isFullNoSchoolDay(now = new Date()) {
  const { date, dayOfWeek } = maldivesDateParts(now);
  return dayOfWeek === 5 || dayOfWeek === 6 || NO_SCHOOL_DATES.has(date);
}

function isSleepTime(now = new Date()) {
  // Keep the rotation running 24/7. The five-hour night shift is 00:00–05:00
  // Maldives time; daytime shifts run from 05:00 until midnight.
  return false;
}

function activeBot(now = new Date()) {
  const { minutes } = maldivesDateParts(now);

  // Night shift: five one-hour handoffs from midnight through 04:59.
  // Day shift: one-hour handoffs reset at 05:00 local time.
  const elapsed = minutes < 5 * 60 ? minutes : minutes - 5 * 60;
  const dutyIndex = Math.floor(elapsed / 60) % BOTS.length;
  return BOTS[dutyIndex];
}

export default async function(req, res) {
  const sleeping = isSleepTime();
  const active = activeBot();

  // Add_me_and_get_Ban is never put to sleep.
  await db.query(
    "UPDATE profiles SET always_online=true, last_seen_at=NOW() WHERE LOWER(username)=LOWER($1)",
    [ALWAYS_ON]
  );

  // Gblox appears all day on the first of every month and on the opening
  // and closing dates of Ramadan and Eid observances (Maldives local dates).
  // These dates are estimates until confirmed by the Maldives moon-sighting
  // announcement; update the list annually if the official dates differ.
  const { date: localDate } = maldivesDateParts();
  const isFirstOfMonth = localDate.slice(8, 10) === "01";
  const GBLOX_SPECIAL_DATES = new Set([
    // Ramadan and Eid al-Fitr 1448 AH (estimated Maldives dates)
    "2027-02-08", "2027-03-09", "2027-03-10", "2027-03-11",
    // Eid al-Adha 1448 AH (estimated Maldives dates)
    "2027-05-17", "2027-05-18",
    // Ramadan and Eid al-Fitr 1449 AH (estimated Maldives dates)
    "2028-01-28", "2028-02-25", "2028-02-26", "2028-02-27",
    // Eid al-Adha 1449 AH (estimated Maldives dates)
    "2028-05-06", "2028-05-07"
  ]);
  const gbloxOnlineToday = isFirstOfMonth || GBLOX_SPECIAL_DATES.has(localDate);
  await db.query(
    "UPDATE profiles SET always_online=$1, last_seen_at=CASE WHEN $1 THEN NOW() ELSE last_seen_at END WHERE LOWER(username)=LOWER($2)",
    [gbloxOnlineToday, "Gblox"]
  );

  // APP is online 24 hours a day, 5 days a week (Sunday-Thursday)
  // and offline Friday-Saturday, using Maldives time (UTC+5).
  const { dayOfWeek } = maldivesDateParts();
  const appOnline = dayOfWeek >= 0 && dayOfWeek <= 4;
  await db.query(
    "UPDATE profiles SET always_online=$1, last_seen_at=CASE WHEN $1 THEN NOW() ELSE last_seen_at END WHERE LOWER(username)=LOWER($2)",
    [appOnline, APP_BOT]
  );

  for (const username of BOTS) {
    const online = !sleeping && username === active;
    await db.query(
      "UPDATE profiles SET always_online=$1, last_seen_at=CASE WHEN $1 THEN NOW() ELSE last_seen_at END WHERE LOWER(username)=LOWER($2)",
      [online, username]
    );
  }

  return res.json({
    ok: true,
    timezone: "Indian/Maldives (UTC+5)",
    dutySchedule: "24/7 Maldives time",
    nightShift: "00:00-05:00 MVT (five hours)",
    dayShift: "05:00-00:00 MVT",
    sleeping,
    activeBot: active,
    alwaysOnlineBot: ALWAYS_ON,
    updatedBots: BOTS.length + 1
  });
}