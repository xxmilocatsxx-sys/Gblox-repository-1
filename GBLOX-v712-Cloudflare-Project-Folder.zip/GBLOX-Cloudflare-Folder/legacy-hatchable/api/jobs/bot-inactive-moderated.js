import { db } from "hatchable";
export const access="scheduler";
export const methods=["POST"];
const BOT_USERNAME="GblocksBot";
const te=new TextEncoder();
const b64=b=>btoa(String.fromCharCode(...new Uint8Array(b)));
function rb(n){const a=new Uint8Array(n);crypto.getRandomValues(a);return a;}
async function hp(password,salt){const k=await crypto.subtle.importKey("raw",te.encode(password),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:210000,hash:"SHA-256"},k,256);return b64(bits);}
function botPassword(){return "GBbot-"+b64(rb(24)).replace(/[^A-Za-z0-9]/g,"").slice(0,32)+"!";}
export default async function(req,res){
 const bot=await db.query("SELECT user_id,username FROM profiles WHERE LOWER(username)=LOWER($1) LIMIT 1",[BOT_USERNAME]);
 if(!bot.rows[0])return res.json({ok:true,bot:BOT_USERNAME,inactivityPeriod:"5 months",checked:0,processed:0,results:[],skipped:"GblocksBot account is not provisioned; no accounts were modified."});
 const targets=await db.query("SELECT user_id,username,banned,terminated,last_seen_at FROM profiles WHERE (banned=true OR terminated=true) AND user_id<>$1 AND COALESCE(last_seen_at,created_at)<NOW()-INTERVAL '5 months' AND NOT EXISTS (SELECT 1 FROM audit_logs a WHERE a.action='BOT_PASSWORD_ROTATED_AFTER_5_MONTHS' AND a.target_user_id=profiles.user_id) ORDER BY user_id LIMIT 100",[bot.rows[0].user_id]);
 let processed=0;const results=[];
 for(const row of targets.rows){try{
  const password=botPassword(),salt=rb(16),hash=await hp(password,salt),saltText=b64(salt);
  await db.transaction([
   {sql:"UPDATE gblocks_credentials SET password_salt=$1,password_hash=$2,updated_at=NOW() WHERE user_id=$3",params:[saltText,hash,String(row.user_id)]},
   {sql:"DELETE FROM gblocks_sessions WHERE user_id=$1",params:[String(row.user_id)]},
   {sql:"DELETE FROM account_sessions WHERE user_id=$1",params:[String(row.user_id)]},
   {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",params:["BOT_PASSWORD_ROTATED_AFTER_5_MONTHS",String(row.user_id),row.username,String(bot.rows[0].user_id),BOT_USERNAME,"GblocksBot rotated credentials after five months of inactivity on a banned or terminated account.",JSON.stringify({moderationStatus:row.terminated?"terminated":"banned",lastSeenAt:row.last_seen_at,sessionsRevoked:true,passwordRotated:true})]}
  ]);
  processed++;results.push({userId:String(row.user_id),username:row.username,status:row.terminated?"terminated":"banned",passwordChanged:true,sessionsRevoked:true});
 }catch(e){results.push({userId:String(row.user_id),username:row.username,error:"Credential rotation could not be safely completed."});}}
 return res.json({ok:true,bot:BOT_USERNAME,inactivityPeriod:"5 months",checked:targets.rows.length,processed,results});
}