import { db } from "hatchable";

export const access = "scheduler";
export const methods = ["POST"];
export const schedule = "0 * * * *";

const BOT = "Checker";
const CHECKS = [
  ["/api/players", "GET"],
  ["/api/games", "GET"],
  ["/api/catalog/list", "GET"],
  ["/api/profile", "GET"],
  ["/api/social/status", "GET"],
  ["/api/presence", "GET"]
];

async function ensureBotData() {
  const bot = await db.query("SELECT user_id,username FROM profiles WHERE LOWER(username)=LOWER($1) LIMIT 1",[BOT]);
  if (!bot.rows[0]) return {repaired:false,error:"Checker profile is missing."};
  const id=String(bot.rows[0].user_id);
  const player=await db.query("SELECT user_id FROM gblocks_players WHERE user_id=$1 LIMIT 1",[id]);
  if(!player.rows[0]) {
    await db.query("INSERT INTO gblocks_players(user_id,username,display_name,bio) VALUES($1,$2,$2,$3)",[id,BOT,"Automatic Gblocks health checker bot."]);
    return {repaired:true};
  }
  return {repaired:false};
}

async function checkRoutes() {
  const results=[];
  for(const [path,method] of CHECKS){
    try{
      const r=await fetch("https://gblocks.hatchable.site"+path,{method,cache:"no-store"});
      results.push({path,status:r.status,ok:r.status<500});
    }catch(e){
      results.push({path,status:0,ok:false,error:"request failed"});
    }
  }
  return results;
}

export default async function(req,res){
  // Checker is online 24/7 except Friday, when it stays offline for the day.
  // Scheduler uses UTC for deterministic weekly behavior.
  const now=new Date();
  if(now.getUTCDay()===5) return res.json({ok:true,bot:BOT,status:"offline",reason:"Friday offline day",checkedAt:now.toISOString()});
  const repair=await ensureBotData();
  const routes=await checkRoutes();
  const failed=routes.filter(x=>!x.ok);
  const checkedAt=new Date().toISOString();

  await db.query(
    "INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,NULL,$2,NULL,$2,$3,$4::jsonb)",
    ["CHECKER_HEALTH_SCAN",BOT,"Checker automatic health scan",JSON.stringify({checkedAt,failed:failed.length,routes,repaired:repair.repaired})]
  );

  res.json({ok:true,bot:BOT,checkedAt,routeCount:routes.length,failedCount:failed.length,repaired:repair.repaired,routes});
}