import { db } from 'hatchable';
export const access = 'scheduler';
export const methods = ['POST','GET'];
export default async function(req,res){
  const result = await db.query("UPDATE gblox_catalog_event_items SET is_on_sale=FALSE WHERE event_key='halloween-2026' AND (sale_end_at <= NOW() OR (stock_limit IS NOT NULL AND stock_sold >= stock_limit)) RETURNING id");
  return res.json({ok:true,offSaleCount:result.rows.length,items:result.rows.map(x=>x.id)});
}