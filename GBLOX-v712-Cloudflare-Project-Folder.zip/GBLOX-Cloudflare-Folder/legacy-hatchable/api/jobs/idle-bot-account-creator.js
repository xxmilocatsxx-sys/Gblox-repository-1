import { db } from "hatchable";
export const access="scheduler";
export const methods=["POST"];
export const schedule="0 * * * *";
const enc=new TextEncoder();
const b64=x=>btoa(String.fromCharCode(...new Uint8Array(x))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function passwordHash(password,salt){const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);return b64(await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:120000,hash:"SHA-256"},key,256))}
function token(n=24){const b=new Uint8Array(n);crypto.getRandomValues(b);return b64(b)}
export default async function(req,res){
 const activity=await db.query("SELECT COUNT(*)::int AS n FROM profiles WHERE COALESCE(is_bot,false)=false AND COALESCE(role,'user')<>'bot' AND COALESCE(banned,false)=false AND COALESCE(terminated,false)=false AND last_seen_at>NOW()-INTERVAL '15 minutes'");
 if(Number(activity.rows[0]?.n||0)>0)return res.json({ok:true,skipped:true,reason:"Players are active."});
 const recent=await db.query("SELECT 1 FROM audit_logs WHERE action='idle_bot_account_created' AND created_at>NOW()-INTERVAL '15 minutes' LIMIT 1");
 if(recent.rows.length)return res.json({ok:true,skipped:true,reason:"A bot was created recently."});
 const seq=await db.query("UPDATE gblocks_user_number_sequence SET next_number=next_number+1 WHERE id=1 RETURNING next_number-1 AS user_number");
 if(!seq.rows[0])return res.status(503).json({error:"Account numbering is unavailable."});
 const n=Number(seq.rows[0].user_number);
 const username="GBIdleBot"+String(n);
 const taken=await db.query("SELECT 1 FROM profiles WHERE lower(username)=lower($1) UNION ALL SELECT 1 FROM gblocks_players WHERE lower(username)=lower($1) LIMIT 1",[username]);
 if(taken.rows.length)return res.json({ok:true,skipped:true,reason:"Generated username was already taken."});
 const userId=crypto.randomUUID(),salt=new Uint8Array(16);crypto.getRandomValues(salt);
 const saltText=b64(salt),hash=await passwordHash(token(),salt),avatar=JSON.stringify({body:"classic",face:"☺",outfit:"default-2021",gender:null});
 const writes=[
  {sql:"INSERT INTO profiles (user_id,username,display_name,bio,avatar,user_number,gender,role,is_bot) VALUES ($1,$2,$2,'Automated GBLOX system bot account.',$3::jsonb,$4,NULL,'bot',true)",params:[userId,username,avatar,n]},
  {sql:"INSERT INTO account_credentials (user_id,password_salt,password_hash) VALUES ($1,$2,$3)",params:[userId,saltText,hash]},
  {sql:"INSERT INTO user_settings (user_id,gender,updated_at) VALUES ($1,NULL,NOW()) ON CONFLICT (user_id) DO NOTHING",params:[userId]},
  {sql:"INSERT INTO gblocks_players (user_id,username,display_name,bio,avatar,gender,is_bot) VALUES ($1,$2,$2,'Automated GBLOX system bot account.',$3::jsonb,NULL,true)",params:[userId,username,avatar]},
  {sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,50,NULL,false) ON CONFLICT (user_id) DO NOTHING",params:[userId]},
  {sql:"INSERT INTO audit_logs(action,target_user_id,target_username,reason,details) VALUES ('idle_bot_account_created',$1,$2,'Idle scheduled bot creation',$3::jsonb)",params:[userId,username,JSON.stringify({is_bot:true,user_number:n,login_enabled:false})]}
 ];
 await db.transaction(writes);
 return res.json({ok:true,created:true,username,user_number:n});
}