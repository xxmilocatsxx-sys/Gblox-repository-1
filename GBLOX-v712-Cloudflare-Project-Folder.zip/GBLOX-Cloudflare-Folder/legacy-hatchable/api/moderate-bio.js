import { checkBio } from "../lib/moderation-policy.js";
export const access="public";
export const methods=["POST"];
export default async function(req,res){
 const bio=String(req.body?.bio||"").trim().slice(0,160);
 if(!bio)return res.json({allowed:true,deleted:false});
 const result=checkBio(bio);
 return result.flagged
  ? res.json({allowed:false,deleted:true,reason:result.reason})
  : res.json({allowed:true,deleted:false});
}