import { db } from "hatchable";

export const access="scheduler";
export const methods=["POST"];

async function nextUsername(userId){
  const q=await db.query("SELECT 'GBLOCKS_User_'||user_number::text AS username FROM profiles WHERE user_id=$1 AND user_number IS NOT NULL",[userId]);
  return q.rows[0]?.username||"";
}

function decide(appeal,banNote){
  const text=String(appeal||"");
  const meaningful=text.length>=40;
  const badSignals=/(just let me back|i did it on purpose|i will keep doing it|no appeal|whatever)/i.test(text);
  const correction=/(fixed|changed|corrected|understand|won't repeat|will not repeat|mistake|didn't know|did not know)/i.test(text);
  return meaningful&&!badSignals&&(correction||!banNote)?"approved":"denied";
}

export default async function(req,res){
  if(req.headers?.["x-hatchable-trigger"]!=="cron")return res.status(403).json({error:"Scheduler only."});
  const id=req.body?.appeal_id;
  if(!id)return res.status(400).json({error:"Missing appeal_id."});

  const a=(await db.query("SELECT id,user_id,appeal_text,status FROM moderation_appeals WHERE id=$1 LIMIT 1",[id])).rows[0];
  if(!a||a.status!=="pending")return res.json({ok:true,skipped:true});

  const u=(await db.query("SELECT user_id,username,banned,terminated,ban_note FROM profiles WHERE user_id=$1 LIMIT 1",[a.user_id])).rows[0];
  if(!u)return res.status(404).json({error:"Account not found."});

  const timeBan=Boolean(u.banned&&!u.terminated);
  const bypass=/(^|\\b)bypass(\\b|$)|bypassing|circumvent|evad(e|ing|ed)|work around|workaround/i.test(String(a.appeal_text||""));
  const decision=(timeBan||bypass)?"denied":decide(a.appeal_text,u.ban_note);

  if(decision==="approved"&&(u.terminated||u.banned)){
    const until=new Date(Date.now()+5*60*1000);
    if(u.terminated&&String(u.ban_note||"").toLowerCase().includes("automatic username moderation")){
      const newUsername=await nextUsername(u.user_id);
      if(!newUsername)return res.status(409).json({error:"Safe replacement username unavailable."});
      await db.transaction([
        {sql:"UPDATE moderation_appeals SET status='decided',decision='approved',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:["App",id]},
        {sql:"INSERT INTO username_reservations(username,reserved_for_user_id,reason) VALUES($1,$2,$3) ON CONFLICT(username) DO UPDATE SET reserved_for_user_id=EXCLUDED.reserved_for_user_id,reason=EXCLUDED.reason",params:[u.username,u.user_id,"inappropriate_username_permanent_reservation"]},
        {sql:"DELETE FROM username_history WHERE user_id=$1 AND lower(username)=lower($2)",params:[u.user_id,u.username]},
        {sql:"UPDATE profiles SET username=$1,display_name=$1,banned=true,terminated=false,temp_ban_until=$2,ban_note=$3,verified=false WHERE user_id=$4",params:[newUsername,until,"Appeal approved by App. Reactivate your account after 5 minutes.",u.user_id]},
        // account_credentials stores password hashes only; username lives in profiles.
        {sql:"UPDATE gblocks_credentials SET username=$1 WHERE user_id=$2",params:[newUsername,u.user_id]}
      ]);
      return res.json({ok:true,decision:"approved",newUsername,reviewedBy:"App",reactivationAvailableAt:until});
    }
    await db.transaction([
      {sql:"UPDATE moderation_appeals SET status='decided',decision='approved',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",params:["App",id]},
      {sql:"UPDATE profiles SET banned=true,terminated=false,temp_ban_until=$1,ban_note=$2 WHERE user_id=$3",params:[until,"Appeal approved by App. Reactivate your account after 5 minutes.",u.user_id]}
    ]);
    return res.json({ok:true,decision:"approved",reviewedBy:"App",reactivationAvailableAt:until});
  }

  await db.query("UPDATE moderation_appeals SET status='decided',decision=$1,reviewed_by=$2,reviewed_at=NOW() WHERE id=$3",[decision,"App",id]);

  return res.json({ok:true,decision,reviewedBy:"App"});
}