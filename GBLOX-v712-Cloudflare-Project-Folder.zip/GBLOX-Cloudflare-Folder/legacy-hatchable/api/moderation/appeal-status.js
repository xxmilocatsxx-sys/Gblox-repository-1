import { db } from "hatchable";
export const access="public"; export const methods=["GET"];
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
async function hash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}
function token(req){if(req.cookies?.groblox_session)return req.cookies.groblox_session;const m=String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/);return m?.[1]||""}
export default async function(req,res){
 const t=String(token(req)); if(!t)return res.status(401).json({error:"Sign in to view appeals."});
 const q=await db.query("SELECT p.user_id,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await hash(t)]);
 const u=q.rows[0]; if(!u)return res.status(401).json({error:"Your session has expired."});
 if(!u.banned && !u.terminated)return res.json({eligible:false,appeal:null});
 const a=await db.query("SELECT id,status,decision,appeal_text,ban_reason,reviewed_by,reviewed_at,created_at FROM moderation_appeals WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1",[u.user_id]);
 const latest=a.rows[0]||null;
 return res.json({eligible:true,moderation_status:u.terminated?"terminated":"banned",appeal:latest,canSubmit:!latest||!["pending","escalation_required"].includes(latest.status)});
}