import { db, scheduler } from "hatchable";
export const access="public";
export const methods=["POST"];

function token(req){
  if(req.cookies?.groblox_session)return req.cookies.groblox_session;
  const m=String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/);
  return m?.[1]||"";
}
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
async function h(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}

function safeDecision(raw){
  const s=String(raw||"").toLowerCase();
  if(/\bdeny\b/.test(s)&&!/\bapprove\b/.test(s))return "denied";
  return "approved";
}

async function nextUsername(userId){
  const q=await db.query("SELECT 'GBLOCKS_User_'||user_number::text AS username FROM profiles WHERE user_id=$1 AND user_number IS NOT NULL",[userId]);
  return q.rows[0]?.username||"";
}

export default async function(req,res){
  const t=token(req);
  if(!t)return res.status(401).json({error:"Sign in to submit an appeal."});

  const q=await db.query("SELECT p.user_id,p.username,p.display_name,p.banned,p.terminated,p.ban_note,p.role FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await h(t)]);
  const u=q.rows[0];
  if(!u)return res.status(401).json({error:"Your session has expired."});
  if(!u.banned&&!u.terminated)return res.status(400).json({error:"Appeals are only available for banned or terminated accounts."});

  const appeal=String(req.body?.appeal||"").trim().slice(0,2000);
  if(appeal.length<20)return res.status(400).json({error:"Your appeal must be at least 20 characters."});

  const pending=await db.query("SELECT id FROM moderation_appeals WHERE user_id=$1 AND status IN ('pending','escalation_required') LIMIT 1",[u.user_id]);
  if(pending.rows.length)return res.status(409).json({error:"You already have an appeal being reviewed."});

  const text=appeal.toLowerCase();
  const isTimeBan=Boolean(u.banned && !u.terminated && u.role!=="administrator");
  const usesBypassLanguage=/(^|\\b)bypass(\\b|$)|bypassing|circumvent|evad(e|ing|ed)|work around|workaround/i.test(text);
  const badSignals=/(just let me back|i did it on purpose|i will keep doing it|no appeal|whatever)/i.test(appeal);

  // Time-ban appeals and any appeal that asks for/admits a bypass are never
  // approved by App. They are marked for escalation so a higher-rank
  // administrator or the owner can review them manually.
  const usernameProof=String(appeal).toLowerCase().split(/[^a-z0-9_.]+/).includes(String(u.username||"").toLowerCase());
  const permanentTerminationAutoAccept=Boolean(u.terminated&&usernameProof&&!usesBypassLanguage&&!badSignals);
  const escalationRequired=!permanentTerminationAutoAccept&&(isTimeBan||usesBypassLanguage);
  const decision=permanentTerminationAutoAccept?"approved":(escalationRequired||badSignals?"denied":(appeal.length>=20?"approved":"denied"));
  const status=escalationRequired?"escalation_required":"decided";

  const inserted=await db.query(
    "INSERT INTO moderation_appeals(user_id,username,ban_reason,appeal_text,status,decision,reviewed_by,reviewed_at) VALUES($1,$2,$3,$4,$5,$6,'App',NOW()) RETURNING id,created_at",
    [u.user_id,u.username,u.ban_note||"",appeal,status,decision]
  );
  const id=inserted.rows[0].id;

  if(decision==="approved"){
    if(u.terminated){
      await db.query("UPDATE profiles SET banned=false,terminated=false,temp_ban_until=NULL,ban_note='' WHERE user_id=$1",[u.user_id]);
      const alt=(await db.query("SELECT user_id,username FROM profiles WHERE user_id=$1 LIMIT 1",["c66afd7c-03ea-42bc-b771-69b836f7049f"])).rows[0];
      if(alt){
        await db.query("INSERT INTO direct_messages(sender_id,receiver_id,message) VALUES($1,$2,$3)",[u.user_id,alt.user_id,"Termination appeal accepted for @"+u.username+". The user included their username in the appeal. Appeal #"+id+"."]);
        await db.query("INSERT INTO gblocks_notifications(user_id,actor_user_id,actor_username,type,title,body) VALUES($1,$2,$3,'appeal',$4,$5)",[alt.user_id,u.user_id,u.username,"Termination appeal accepted","@"+u.username+" included their username in a termination appeal. Appeal #"+id+"."]);
      }
      return res.status(201).json({ok:true,appeal_id:id,status:"decided",decision:"approved",reviewedBy:"App",action:"account_reactivated",message:"Termination appeal accepted because the appeal included the account username. @Alt was notified."});
    }

    if(u.banned){
      const until=new Date(Date.now()+5*60*1000);
      await db.query(
        "UPDATE profiles SET banned=true,terminated=false,temp_ban_until=$1,ban_note=$2,last_ban_duration_days=0 WHERE user_id=$3",
        [until,"Appeal approved by App. Reactivation available after 5 minutes.",u.user_id]
      );
      return res.status(201).json({ok:true,appeal_id:id,status:"decided",decision:"approved",reviewedBy:"App",action:"five_minute_reactivation_wait",reactivationAvailableAt:until});
    }
  }

  return res.status(201).json({
    ok:true,
    appeal_id:id,
    status,
    decision,
    reviewedBy:"App",
    escalationRequired,
    message:escalationRequired
      ?"Appeal denied automatically. Contact a higher-rank Gblocks administrator or the owner for manual review."
      :undefined
  });
}