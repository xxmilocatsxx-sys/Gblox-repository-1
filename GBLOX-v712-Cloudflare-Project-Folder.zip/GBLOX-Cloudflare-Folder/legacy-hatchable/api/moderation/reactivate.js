import { db } from "hatchable";
export const access="public";
export const methods=["POST"];

const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
async function hash(t){return b64(await crypto.subtle.digest("SHA-256",enc.encode(t)))}

function token(req){
  return req.cookies?.groblox_session || String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1] || "";
}

export default async function(req,res){
  const raw=token(req);
  if(!raw)return res.status(401).json({error:"Sign in to reactivate your account."});
  const q=await db.query("SELECT p.user_id,p.banned,p.terminated,p.temp_ban_until FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await hash(raw)]);
  const u=q.rows[0];
  if(!u)return res.status(401).json({error:"Your session has expired."});
  if(u.terminated)return res.status(403).json({error:"This account is still terminated."});
  if(!u.banned||!u.temp_ban_until)return res.status(400).json({error:"Your account is not ready for reactivation."});
  const banReason=String((await db.query("SELECT ban_note FROM profiles WHERE user_id=$1 LIMIT 1",[u.user_id])).rows[0]?.ban_note||"");
  if(!/^Appeal approved by (App|administrator)/i.test(banReason)){
    return res.status(403).json({error:"This account cannot use self-service reactivation. A higher-rank administrator or the owner must approve the appeal first."});
  }
  if(new Date(u.temp_ban_until)>new Date())return res.status(409).json({error:"The reactivation wait has not finished yet."});
  await db.query("UPDATE profiles SET banned=false,terminated=false,temp_ban_until=NULL,ban_note='' WHERE user_id=$1",[u.user_id]);
  res.json({ok:true,reactivated:true});
}