import { db } from "hatchable";
export const access="public";
export const methods=["GET"];
const enc=new TextEncoder();
const b64url=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).split("+").join("-").split("/").join("_").replace(/=+$/,"");
async function hashToken(token){return b64url(await crypto.subtle.digest("SHA-256",enc.encode(token)))}
function cookie(req,name){const m=String(req.headers?.cookie||"").match(new RegExp("(?:^|;\\s*)"+name+"=([^;]+)"));return m?decodeURIComponent(m[1]):""}
export default async function(req,res){
 const token=cookie(req,"groblox_session");
 if(!token)return res.status(401).json({error:"Sign in to see your friends."});
 const me=await db.query("SELECT user_id FROM account_sessions WHERE token_hash=$1 AND expires_at>NOW() LIMIT 1",[await hashToken(token)]);
 if(!me.rows[0])return res.status(401).json({error:"Sign in to see your friends."});
 const q=await db.query(`SELECT DISTINCT ON (p.user_id) p.user_id,
  CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE p.username END AS username,
  CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE p.display_name END AS display_name,
  CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN '{}'::jsonb ELSE p.avatar END AS avatar,
  CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN false ELSE (p.always_online OR (p.last_seen_at IS NOT NULL AND p.last_seen_at>NOW()-INTERVAL '5 minutes')) END AS online,
  (COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL) AS deactivated
  FROM friend_requests fr
  JOIN profiles p ON p.user_id=CASE WHEN fr.sender_id=$1 THEN fr.receiver_id ELSE fr.sender_id END
  LEFT JOIN gblocks_players gp ON gp.user_id=p.user_id
  WHERE fr.status='accepted' AND (fr.sender_id=$1 OR fr.receiver_id=$1) AND p.user_id<>$1
  ORDER BY p.user_id,online DESC,p.last_seen_at DESC`,[me.rows[0].user_id]);
 return res.json({friends:q.rows});
}