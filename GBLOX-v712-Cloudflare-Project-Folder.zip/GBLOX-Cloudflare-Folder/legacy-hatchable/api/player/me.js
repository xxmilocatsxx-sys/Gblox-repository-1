import { db } from "hatchable";
import { checkModerationUsername, checkBio } from "../../lib/moderation-policy.js";
export const access="public"; export const methods=["GET","PUT"];
const te=new TextEncoder();
function bytesToB64(bytes){return btoa(String.fromCharCode(...bytes));}
function tokenFrom(req){let t=req.headers?.["x-gblocks-session"]||req.headers?.["X-Gblocks-Session"]||null;if(t)return String(t).trim();t=req.cookies?.gblocks_session||null;try{return decodeURIComponent(t||"")}catch{return t||""}}
async function hashToken(token){const data=await crypto.subtle.digest("SHA-256",te.encode(token));return bytesToB64(new Uint8Array(data));}
async function current(req){const token=tokenFrom(req);if(!token)return null;const q=await db.query("SELECT s.user_id FROM gblocks_sessions s WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",[await hashToken(token)]);return q.rows[0]?.user_id||null;}

export default async function(req,res){
 const userId=await current(req);if(!userId)return res.status(401).json({error:"Not signed in."});
 const q0=await db.query("SELECT p.user_id,p.username,p.display_name,p.bio,p.username_history,p.avatar,COALESCE(g.balance,0) AS gobux,p.moderation_status,p.moderation_note,p.temp_ban_until,pr.user_number,p.last_ban_duration_days,p.moderation_violation_count,p.moderation_free_username_change FROM gblocks_players p LEFT JOIN profiles pr ON pr.user_id=p.user_id LEFT JOIN gobux_accounts g ON g.user_id=p.user_id WHERE p.user_id=$1",[userId]);
 if(!q0.rows.length)return res.status(404).json({error:"Player profile not found."});
 const old=q0.rows[0];
 if(req.method==="GET")return res.json({player:old});
 if(old.moderation_status!=="active")return res.status(403).json({error:"Your account is under moderation.",moderation_status:old.moderation_status,temp_ban_until:old.temp_ban_until});

 const body=req.body||{};
 if(body.username!==undefined&&!/^[A-Za-z0-9_]{3,20}$/.test(String(body.username)))return res.status(400).json({error:"Username must be 3-20 letters, numbers, or underscores."});
 const requestedName=body.username!==undefined?String(body.username).trim():old.username;
 const requestedBio=body.bio!==undefined?String(body.bio).slice(0,160):old.bio;
 const requestedDisplayName=body.display_name!==undefined?String(body.display_name).trim().slice(0,40):old.display_name;
 if(body.display_name!==undefined && requestedDisplayName.toLowerCase()==='builder' && String(userId)!=='c66afd7c-03ea-42bc-b771-69b836f7049f')return res.status(409).json({error:'The display name Builder is reserved for the official GBlocks Builder account.'});
 const nameCheck=checkModerationUsername(requestedName);
 const bioCheck=checkBio(requestedBio);
 let moderatedBio=requestedBio;
 let bioDeleted=false;
 if(bioCheck.flagged){ moderatedBio="[Content Deleted]"; bioDeleted=true; }
 // A bio violation is a 5-minute temporary moderation action. Keep the GBlocks session
 // intact so the user is not logged out; the moderation screen can use that same session.
 if(bioCheck.flagged){
   const until=new Date(Date.now()+5*60*1000);
   const note=bioCheck.reason||"Bio violates GBlocks Community Standards.";
   await db.transaction([
     {sql:"UPDATE gblocks_players SET bio=$1,bio_deleted_by_moderation=true,moderation_status='banned',moderation_note=$2,temp_ban_until=$3,moderation_violation_count=moderation_violation_count+1,moderation_last_action=NOW(),last_ban_duration_days=0 WHERE user_id=$4",params:["[Content Deleted]",note,until,userId]},
     {sql:"UPDATE profiles SET bio=$1,bio_deleted_by_moderation=true,bio_moderation_status='content_deleted',bio_moderation_last_reviewed_at=NOW(),banned=true,terminated=false,temp_ban_until=$2,ban_note=$3 WHERE user_id=$4",params:["[Content Deleted]",until,note,userId]}
   ]);
   return res.status(403).json({error:"Your bio was automatically moderated. Your account is temporarily banned for 5 minutes.",moderation_status:"banned",temp_ban_until:until.toISOString(),duration_minutes:5,bio_deleted:true,session_preserved:true});
 }
 if(nameCheck.flagged){
   const durationDays=0;
   const until=new Date(Date.now()+3*60*1000);
   const resetName=nameCheck.flagged?("GBLOCKS_User_"+String(old.user_number)):old.username;
   await db.query("UPDATE gblocks_players SET moderation_status='banned',moderation_note=$1,temp_ban_until=$2,moderation_violation_count=moderation_violation_count+1,moderation_last_action=NOW(),last_ban_duration_days=$3,moderation_free_username_change=CASE WHEN $5 THEN TRUE ELSE moderation_free_username_change END,bio=CASE WHEN $4 THEN '[Content Deleted]' ELSE bio END,bio_deleted_by_moderation=bio_deleted_by_moderation OR $4,username=$6 WHERE user_id=$7",[nameCheck.reason,until,durationDays,bioDeleted,nameCheck.flagged,resetName,userId]);
   if(nameCheck.flagged){ await db.query("UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2",[resetName,userId]); await db.query("UPDATE profiles SET username=$1,display_name=$1 WHERE user_id=$2",[resetName,userId]); }
   return res.status(403).json({error:"Your account was temporarily banned for a GBlocks rules violation.",moderation_status:"banned",temp_ban_until:until.toISOString(),duration_days:durationDays,bio_deleted:bioCheck.flagged,username_reset:nameCheck.flagged});
 }

 let history=Array.isArray(old.username_history)?old.username_history:[];
 if(requestedName.toLowerCase()!==old.username.toLowerCase()){
   const taken=await db.query("SELECT user_id FROM gblocks_players WHERE lower(username)=lower($1) AND user_id<>$2 UNION SELECT user_id FROM gblocks_players WHERE EXISTS (SELECT 1 FROM jsonb_array_elements_text(username_history) h WHERE lower(h)=lower($1)) AND user_id<>$2 UNION SELECT reserved_for_user_id AS user_id FROM username_reservations WHERE lower(username)=lower($1) AND reserved_for_user_id<>$2",[requestedName,userId]);
   if(taken.rows.length)return res.status(409).json({error:"That username has already been used or reserved and cannot be claimed."});
   history=[...history,requestedName];
   await db.query("INSERT INTO username_reservations(username,reserved_for_user_id,reason) VALUES($1,$2,'previous_username') ON CONFLICT(username) DO NOTHING",[old.username,userId]);
   await db.query("UPDATE gblocks_credentials SET username=$1,updated_at=NOW() WHERE user_id=$2",[requestedName,userId]);
 }
 const fixedUser=['tubers93','toobers93'].includes(String(requestedName).toLowerCase());
 const fixedAvatar=fixedUser?{image_url:String(requestedName).toLowerCase()==='toobers93'?"/toobers93back_alt.png":"/tubers93-avatar.png",source:"GBlocks fixed avatar"}:null;
 await db.query("UPDATE gblocks_players SET username=$1,display_name=COALESCE($2,display_name),bio=$3,username_history=$4::jsonb,avatar=COALESCE($5::jsonb,avatar),bio_deleted_by_moderation=$6,moderation_free_username_change=CASE WHEN $7 THEN FALSE ELSE moderation_free_username_change END WHERE user_id=$8",[requestedName,body.display_name!==undefined?requestedDisplayName:null,moderatedBio,JSON.stringify(history),fixedAvatar?JSON.stringify(fixedAvatar):(body.avatar?JSON.stringify(body.avatar):null),bioDeleted,(requestedName.toLowerCase()!==old.username.toLowerCase() && old.moderation_free_username_change),userId]);
 const syncedAvatar=fixedAvatar?fixedAvatar:(body.avatar&&typeof body.avatar==='object'?body.avatar:(old.avatar||{}));
 await db.query("UPDATE profiles SET username=$1,bio=$2,avatar=$3::jsonb,gender=COALESCE($4,gender),bio_deleted_by_moderation=$5,bio_moderation_status=$6,bio_moderation_last_reviewed_at=NOW() WHERE user_id=$7",[requestedName,moderatedBio,JSON.stringify(syncedAvatar),syncedAvatar?.custom?.gender||syncedAvatar?.gender||null,bioDeleted,bioDeleted?'content_deleted':'reviewed',userId]);
 return res.json({ok:true,username:requestedName,bio:moderatedBio,bio_deleted:bioDeleted,moderation_message:bioDeleted?"Your bio was removed for violating GBlocks content rules.":null});
}