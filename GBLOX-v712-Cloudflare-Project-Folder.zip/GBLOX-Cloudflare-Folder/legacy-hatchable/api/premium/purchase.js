import { db } from "hatchable";
import { refreshGroupVerification } from "../../lib/verification.js";

export const access = "public";
export const methods = ["POST"];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");

async function tokenHash(token) {
  return b64(await crypto.subtle.digest("SHA-256", enc.encode(token)));
}

function getSessionToken(req) {
  const direct = req.cookies?.gblocks_session || req.cookies?.groblox_session;
  if (direct) return String(direct);
  const raw = String(req.headers?.cookie || "");
  const match = raw.match(/(?:^|;\s*)(gblocks_session|groblox_session)=([^;]*)/);
  return match ? match[2] : null;
}

export default async function (req, res) {
  const token = getSessionToken(req);
  if (!token) return res.status(401).json({ error: "Log in to buy Premium." });

  const session = await db.query(
    "SELECT p.user_id,p.username,p.role,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1",
    [await tokenHash(token)]
  );
  const user = session.rows[0];
  if (!user) return res.status(401).json({ error: "Your Gblocks session has expired. Please log in again." });
  if (user.banned || user.terminated) return res.status(403).json({ error: "This account cannot purchase Premium." });

  const requestedPlan = String(req.body?.plan || "1_month").trim();
  const plans = {
    "1_month": { months: 1, weekly: 1000, firstDay: 2000, price: 50, label: "1-month Premium" },
    "2_months": { months: 2, weekly: 2000, firstDay: 3000, price: 5000, label: "2-month Premium" },
    "5_months": { months: 5, weekly: 10000, firstDay: 10000, price: 8000, label: "5-month Premium" },
    "10_months": { months: 10, weekly: 5000000, firstDay: 5100000, price: 50000, label: "10-month Premium" },
    "500_years": { months: 6000, weekly: 9897000, firstDay: 9897000, price: 5000000000, adminPrice: 1, label: "★ Premium Plus" }
  };
  const selected = plans[requestedPlan];
  if (!selected) return res.status(400).json({ error: "Invalid Premium plan." });
  const isAdmin = user.role === "admin" || user.role === "administrator";
  const purchasePrice = requestedPlan === "500_years" && isAdmin ? selected.adminPrice : selected.price;

  const result = await db.query("BEGIN");
  try {
    const uid = String(user.user_id);
    await db.query("SELECT pg_advisory_xact_lock(hashtext($1))", [uid]);

    const active = await db.query(
      "SELECT 1 FROM premium_subscriptions WHERE user_id=$1 AND active=true AND (is_permanent=true OR expires_at>NOW()) LIMIT 1",
      [uid]
    );
    if (active.rows.length) {
      await db.query("COMMIT");
      return res.status(409).json({ error: "You already have active Premium." });
    }

    await db.query(
      "INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",
      [uid]
    );

    const debit = await db.query(
      `UPDATE gobux_accounts SET balance=balance-${purchasePrice},updated_at=NOW() WHERE user_id=$1 AND (gobux_infinite OR balance>=${purchasePrice}) RETURNING balance,gobux_infinite`,
      [uid]
    );
    if (!debit.rows.length) {
      const bal = await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1", [uid]);
      await db.query("ROLLBACK");
      const row = bal.rows[0];
      return res.status(402).json({
        error: "You need " + purchasePrice.toLocaleString() + " Gobux to buy " + selected.label + ".",
        balance: Number(row?.balance || 0),
        cost: purchasePrice
      });
    }

    // Premium proceeds are split equally across the configured GBlocks recipients.
    // Validate every account before any payout; a missing recipient rolls back the debit.
    // Only include configured recipients that actually exist in GBLOX. The former
    // hard-coded "idk" entry has no matching profile and caused every Premium purchase
    // to pause even though the other four configured recipients are valid.
    const recipientNames = ["Milo", "CashSoAce", "Lol", "Add_Me_Get_Ban"];
    const normalizedNames = recipientNames.map(name => name.trim().toLowerCase());
    const recipients = await db.query(
      "SELECT user_id,username FROM profiles WHERE lower(trim(username)) = ANY($1::text[]) ORDER BY lower(trim(username))",
      [normalizedNames]
    );
    const found = new Set(recipients.rows.map(row => String(row.username).trim().toLowerCase()));
    const missing = recipientNames.filter(name => !found.has(name.trim().toLowerCase()));
    if (missing.length) {
      await db.query("ROLLBACK");
      return res.status(503).json({
        error: "Premium payout is paused because these recipient accounts could not be found: " + missing.join(", ") + ". Your Gobux was not charged.",
        missingRecipients: missing
      });
    }

    const shareBase = Math.floor(purchasePrice / recipients.rows.length);
    let remainder = purchasePrice - shareBase * recipients.rows.length;
    for (const recipient of recipients.rows) {
      const share = shareBase + (remainder > 0 ? 1 : 0);
      if (remainder > 0) remainder--;
      await db.query(
        "INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite) VALUES ($1,0,NULL,false) ON CONFLICT (user_id) DO NOTHING",
        [String(recipient.user_id)]
      );
      await db.query(
        "UPDATE gobux_accounts SET balance=balance+$2,updated_at=NOW() WHERE user_id=$1",
        [String(recipient.user_id), share]
      );
    }

    const subscription = await db.query(
      `INSERT INTO premium_subscriptions
        (user_id,plan,weekly_amount,started_at,expires_at,next_payout_at,active,gifted_by,updated_at)
       VALUES ($1,$2,$3,NOW(),NOW()+($4 || ' months')::interval,NOW()+INTERVAL '7 days',true,'Gblocks Premium Shop',NOW())
       ON CONFLICT (user_id) DO UPDATE
       SET plan=EXCLUDED.plan,weekly_amount=EXCLUDED.weekly_amount,started_at=EXCLUDED.started_at,
           expires_at=EXCLUDED.expires_at,next_payout_at=EXCLUDED.next_payout_at,active=true,
           gifted_by=EXCLUDED.gifted_by,updated_at=EXCLUDED.updated_at
       RETURNING id`,
      [uid, requestedPlan, selected.weekly, String(selected.months)]
    );
    const subscriptionId = String(subscription.rows[0]?.id || "");
    if (!subscriptionId) throw new Error("Premium subscription could not be recorded.");

    const betaCommunity = await db.query(
      "SELECT id FROM groups WHERE lower(name)=lower('Beta Testers') AND owner_id='1' ORDER BY created_at ASC LIMIT 1"
    );
    if (betaCommunity.rows[0]) {
      await db.query(
        "INSERT INTO group_members (group_id,user_id,role) VALUES ($1,$2,'beta_testers') ON CONFLICT (group_id,user_id) DO UPDATE SET role=CASE WHEN group_members.role='owner' THEN 'owner' ELSE 'beta_testers' END",
        [String(betaCommunity.rows[0].id), uid]
      );
      await refreshGroupVerification(String(betaCommunity.rows[0].id));
    }

    // The immediate 10,000 Gobux reward belongs to the buyer, not the creator.
    // The unique reward ledger makes the grant idempotent and gives every reward a stable transaction ID.
    const rewardTxId = `premium:${subscriptionId}`;
    const reward = await db.query(
      `INSERT INTO premium_purchase_rewards
        (subscription_id,user_id,reward_amount,transaction_id)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (subscription_id) DO NOTHING
       RETURNING id`,
      [subscriptionId, uid, selected.firstDay, rewardTxId]
    );
    if (!reward.rows.length) {
      throw new Error("Premium Gobux reward already exists for this subscription.");
    }

    const rewarded = await db.query(
      `UPDATE gobux_accounts
       SET balance=balance+${selected.firstDay},updated_at=NOW()
       WHERE user_id=$1
       RETURNING balance,gobux_infinite`,
      [uid]
    );
    if (!rewarded.rows.length) throw new Error("Premium Gobux wallet could not be updated.");

    const finalBalance = rewarded.rows[0];
    await db.query(
      `INSERT INTO audit_logs
        (action,target_user_id,target_username,reason,details)
       VALUES ($1,$2,$3,$4,$5::jsonb)`,
      [
        "PREMIUM_PURCHASE",
        uid,
        user.username,
        selected.label + " purchase",
        JSON.stringify({
          transaction_id: rewardTxId,
          subscription_id: subscriptionId,
          previous_balance: Number(debit.rows[0].balance),
          purchase_cost: purchasePrice,
          reward_amount: selected.firstDay,
          new_balance: finalBalance.gobux_infinite ? "∞" : Number(finalBalance.balance),
          recipients: recipients.rows.map(row => row.username)
        })
      ]
    );

    await db.query("COMMIT");
    const row = finalBalance;
    return res.json({
      ok: true,
      plan: requestedPlan,
      duration: selected.months + " month" + (selected.months === 1 ? "" : "s"),
      weeklyAmount: selected.weekly,
      firstDayAmount: selected.firstDay,
      price: purchasePrice,
      recipients: recipients.rows.map(row => row.username),
      balance: row.gobux_infinite ? "∞" : Number(row.balance),
      message: selected.label + " activated. " + selected.firstDay.toLocaleString() + " Gobux added now and " + selected.weekly.toLocaleString() + " every week."
    });
  } catch (err) {
    try { await db.query("ROLLBACK"); } catch {}
    throw err;
  }

  const outcome = result.rows[0] || {};
  if (outcome.already_premium) {
    return res.status(409).json({ error: "You already have active Premium." });
  }
  if (!outcome.charged || !outcome.creator_paid || !outcome.purchased) {
    const balance = await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1", [String(user.user_id)]);
    const row = balance.rows[0];
    if (!row) return res.status(400).json({ error: "Your Gobux account could not be found." });
    if (!row.gobux_infinite && Number(row.balance) < purchasePrice) {
      return res.status(402).json({ error: "You need " + purchasePrice.toLocaleString() + " Gobux to buy " + selected.label + ".", balance: Number(row.balance), cost: purchasePrice });
    }
    return res.status(500).json({ error: "Premium purchase could not be completed. Your Gobux was not charged." });
  }

  const balance = await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1 LIMIT 1", [String(user.user_id)]);
  const row = balance.rows[0];

  return res.json({
    ok: true,
    plan: requestedPlan,
    duration: selected.months + " month" + (selected.months === 1 ? "" : "s"),
    weeklyAmount: selected.weekly,
    firstDayAmount: selected.firstDay,
    price: selected.price,
    creator: "Tubers93",
    balance: row?.gobux_infinite ? "∞" : Number(row?.balance || 0),
    message: selected.label + " activated. " + selected.firstDay.toLocaleString() + " Gobux added now and " + selected.weekly.toLocaleString() + " every week."
  });
}