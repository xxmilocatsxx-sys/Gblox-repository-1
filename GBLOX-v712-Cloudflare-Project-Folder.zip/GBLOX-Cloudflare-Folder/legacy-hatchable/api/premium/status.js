import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

export default async function (req, res) {
  const userId = String(req.query?.userid || req.query?.userId || "").trim();
  const username = String(req.query?.username || "").trim();
  if (!userId && !username) return res.status(400).json({ error: "userid or username is required" });

  const q = userId
    ? await db.query("SELECT user_id FROM profiles WHERE user_id=$1 LIMIT 1", [userId])
    : await db.query("SELECT user_id FROM profiles WHERE lower(username)=lower($1) LIMIT 1", [username]);
  if (!q.rows[0]) return res.status(404).json({ error: "Player not found" });

  const p = await db.query("SELECT plan,weekly_amount,started_at,expires_at,active,is_permanent FROM premium_subscriptions WHERE user_id=$1 LIMIT 1", [q.rows[0].user_id]);
  const row = p.rows[0];
  const active = !!row && row.active && (row.is_permanent || (!!row.expires_at && new Date(row.expires_at).getTime() > Date.now()));
  res.json({
    premium: active,
    plan: active ? row.plan : null,
    name: active ? (row.plan === '500_years' ? 'Premium Plus' : 'Premium') : null,
    weeklyAmount: active ? Number(row.weekly_amount) : 0,
    expiresAt: active ? row.expires_at : null,
    permanent: active ? !!row.is_permanent : false
  });
}