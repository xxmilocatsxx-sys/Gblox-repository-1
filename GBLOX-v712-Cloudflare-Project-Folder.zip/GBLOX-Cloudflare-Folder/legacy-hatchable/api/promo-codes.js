import { db } from "hatchable";
export const access = "public";
export const methods = ["GET", "POST"];
const enc = new TextEncoder();
const b64url = b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b)));
async function hash(token, url = true) { const h = await crypto.subtle.digest("SHA-256", enc.encode(token)); return url ? b64url(h) : b64(h); }
function cookie(req, name) {
  const raw = String(req.headers?.cookie || req.headers?.Cookie || "");
  for (const part of raw.split(";")) { const i = part.indexOf("="); if (i < 0 || part.slice(0,i).trim() !== name) continue; const v = part.slice(i+1).trim(); try { return decodeURIComponent(v); } catch { return v; } }
  return null;
}
async function caller(req) {
  const token = cookie(req,"groblox_session") || cookie(req,"gblocks_session");
  if (!token) return null;
  const [modern, legacy] = await Promise.all([
    db.query("SELECT p.user_id,p.username,p.role,p.verified,p.is_bot,p.banned,p.terminated,p.deactivated_at FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1", [await hash(token,true)]),
    db.query("SELECT p.user_id,p.username,p.role,p.verified,p.is_bot,p.banned,p.terminated,p.deactivated_at FROM gblocks_sessions s JOIN gblocks_players gp ON gp.user_id=s.user_id JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() LIMIT 1", [await hash(token,false)])
  ]);
  return modern.rows[0] || legacy.rows[0] || null;
}
const definitions = {
  gblox: { label:"Gblox", reward:5000, eligible:u => u.role === "user" && !u.verified && !u.is_bot },
  verified: { label:"Verified", reward:306789, eligible:u => Boolean(u.verified) },
  bot: { label:"BOT", reward:60000000, eligible:u => Boolean(u.is_bot) || u.role === "bot" },
  admin: { label:"admin", reward:1000000000, eligible:u => u.role === "administrator" }
};
function safeUser(u) { return { user_id:u.user_id, username:u.username, role:u.role, verified:Boolean(u.verified), is_bot:Boolean(u.is_bot), banned:Boolean(u.banned), terminated:Boolean(u.terminated), deactivated_at:u.deactivated_at }; }
export default async function(req,res) {
  res.setHeader("Cache-Control","no-store, no-cache, must-revalidate, private");
  const found = await caller(req);
  if (!found) return res.status(401).json({ ok:false, error:"Sign in to use promo codes." });
  const u = safeUser(found);
  if (u.banned || u.terminated || u.deactivated_at) return res.status(403).json({ ok:false, error:"This account cannot redeem promo codes while restricted or deactivated." });
  if (req.method === "GET") {
    const q = await db.query("SELECT code_key, redeemed_at FROM promo_code_redemptions WHERE user_id=$1",[u.user_id]);
    const redeemed = new Map(q.rows.map(x=>[x.code_key,x.redeemed_at]));
    const available = Object.entries(definitions).filter(([,d])=>d.eligible(u)).map(([key,d])=>({code:d.label,reward:d.reward,expires:"Never",redeemed:redeemed.has(key),redeemedAt:redeemed.get(key)||null}));
    return res.json({ok:true,username:u.username,codes:available});
  }
  const input = String(req.body?.code || "").trim();
  if (!input || input.length > 40) return res.status(400).json({ok:false,error:"Enter a valid promo code."});
  const key = input.toLowerCase();
  const d = definitions[key];
  if (!d) return res.status(404).json({ok:false,error:"That promo code does not exist."});
  if (!d.eligible(u)) return res.status(403).json({ok:false,error:"Your account is not eligible for that promo code."});
  try {
    const result = await db.transaction([
      {sql:"INSERT INTO promo_code_redemptions (user_id,code_key,code_label,reward_amount) VALUES ($1,$2,$3,$4::numeric)",params:[u.user_id,key,d.label,String(d.reward)]},
      {sql:"INSERT INTO gobux_accounts (user_id,balance,last_daily_at,gobux_infinite,updated_at) VALUES ($1,$2::numeric,NULL,false,NOW()) ON CONFLICT (user_id) DO UPDATE SET balance=CASE WHEN gobux_accounts.gobux_infinite THEN gobux_accounts.balance ELSE gobux_accounts.balance + EXCLUDED.balance END,updated_at=NOW()",params:[u.user_id,String(d.reward)]},
      {sql:"UPDATE gblocks_players SET gobux=COALESCE(gobux,0)+$1::numeric,updated_at=NOW() WHERE user_id=$2",params:[String(d.reward),u.user_id]}
    ]);
    const bal = await db.query("SELECT balance,gobux_infinite FROM gobux_accounts WHERE user_id=$1",[u.user_id]);
    return res.json({ok:true,code:d.label,reward:d.reward,balance:bal.rows[0]?.gobux_infinite?"∞":String(bal.rows[0]?.balance||"0"),message:"Promo code redeemed successfully!"});
  } catch (e) {
    const msg = String(e?.message || "");
    if (/unique|duplicate|promo_code_redemptions_user_id_code_key/i.test(msg)) return res.status(409).json({ok:false,error:"You have already redeemed this promo code."});
    console.error("Promo code redemption failed", {code:key});
    return res.status(500).json({ok:false,error:"Could not redeem this code right now. Please try again."});
  }
}