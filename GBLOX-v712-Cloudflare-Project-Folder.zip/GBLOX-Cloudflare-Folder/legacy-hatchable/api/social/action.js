import { db } from "hatchable";
// Bot moderation is recorded directly in audit_logs; no reward side effects.
import { refreshPlayerVerification } from "../../lib/verification.js";

export const access = "public";
export const methods = ["POST"];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){ return b64(await crypto.subtle.digest("SHA-256", enc.encode(t))); }
function cookie(req){ return String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1] || null; }
async function caller(req){
  const t=cookie(req); if(!t) return null;
  const q=await db.query("SELECT p.user_id,p.username,p.banned,p.terminated,p.role,p.deactivated_at,p.temp_ban_until FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",[await tokenHash(t)]);
  const user=q.rows[0];
  if(!user) return null;
  if(user.banned && user.temp_ban_until && new Date(user.temp_ban_until)<=new Date() && !user.terminated){
    await db.query("UPDATE profiles SET banned=false,temp_ban_until=NULL,ban_note='' WHERE user_id=$1 AND banned=true AND temp_ban_until<=NOW()",[user.user_id]);
    await db.query("UPDATE gblocks_players SET moderation_status='active',temp_ban_until=NULL,moderation_note='' WHERE user_id=$1 AND moderation_status='banned' AND temp_ban_until<=NOW()",[user.user_id]).catch(()=>{});
    user.banned=false;
    user.temp_ban_until=null;
  }
  return user;
}
export default async function(req,res){
  const me=await caller(req);
  if(!me) return res.status(401).json({error:"Log in first."});
  if(me.banned||me.terminated||me.deactivated_at) return res.status(403).json({error:"Your account cannot use social actions."});
  const action=String(req.body?.action||"");
  const targetId=String(req.body?.target_user_id||"").trim();
  if(!targetId||targetId===me.user_id) return res.status(400).json({error:"Invalid player."});
  const target=await db.query("SELECT p.user_id,p.username,p.banned,p.terminated,p.role,COALESCE(p.deactivated_at,gp.deactivated_at) AS deactivated_at FROM profiles p LEFT JOIN gblocks_players gp ON gp.user_id=p.user_id WHERE p.user_id=$1",[targetId]);
  if(!target.rows[0]) return res.status(404).json({error:"Player not found."});
  if(target.rows[0].banned||target.rows[0].terminated||target.rows[0].deactivated_at) return res.status(403).json({error:"That player is unavailable."});
  if(action==="follow"){
    await db.query("INSERT INTO follows(follower_id,following_id) VALUES($1,$2) ON CONFLICT DO NOTHING",[me.user_id,targetId]);
    await refreshPlayerVerification(targetId);
    const counts=await db.query(
      "SELECT ((SELECT COUNT(*) FROM follows WHERE following_id=$1) + COALESCE((SELECT follower_bonus FROM profiles WHERE user_id=$1),0)) AS followers, (SELECT COUNT(*) FROM follows WHERE follower_id=$1) AS following_count, (SELECT COUNT(*) FROM friend_requests WHERE status='accepted' AND (sender_id=$1 OR receiver_id=$1)) AS friends",
      [targetId]
    );
    let c=counts.rows[0];
    const followerTotal=Number(c.followers||0);
    if(followerTotal===1){
      const bot=await db.query("SELECT user_id FROM profiles WHERE role='bot' AND banned=false AND terminated=false AND deactivated_at IS NULL AND user_id<>$1 ORDER BY created_at ASC LIMIT 1",[targetId]);
      if(bot.rows[0])await db.query("INSERT INTO follows(follower_id,following_id) VALUES($1,$2) ON CONFLICT DO NOTHING",[String(bot.rows[0].user_id),targetId]);
    }
    if(followerTotal>0 && followerTotal%25===0){
      const milestone=followerTotal/25;
      const marker=await db.query("INSERT INTO gblocks_follow_milestones(user_id,milestone) VALUES($1,$2) ON CONFLICT(user_id,milestone) DO NOTHING RETURNING milestone",[targetId,milestone]);
      if(marker.rows.length){
        const bot=await db.query("SELECT user_id,username FROM profiles WHERE role='bot' AND banned=false AND terminated=false AND deactivated_at IS NULL AND user_id<>$1 ORDER BY created_at ASC OFFSET $2 LIMIT 1",[targetId,milestone-1]);
        if(bot.rows[0]){
          await db.query("INSERT INTO group_members(group_id,user_id,role) SELECT id,$1,'member' FROM groups WHERE owner_id=$2 AND COALESCE(moderation_deleted,false)=false ON CONFLICT(group_id,user_id) DO NOTHING",[String(bot.rows[0].user_id),targetId]).catch(()=>{});
          await db.query("INSERT INTO game_servers(server_id,game_id,last_active_at) SELECT 'bot-milestone-'||id::text||'-'||$2::text,id,NOW() FROM games WHERE creator_id=$1 AND COALESCE(moderation_deleted,false)=false ON CONFLICT(server_id) DO UPDATE SET last_active_at=NOW(),game_id=EXCLUDED.game_id",[targetId,milestone]).catch(()=>{});
          await db.query("INSERT INTO game_server_players(server_id,user_id,username,last_seen_at) SELECT 'bot-milestone-'||g.id::text||'-'||$3::text,$1,$2,NOW() FROM games g WHERE g.creator_id=$4 AND COALESCE(g.moderation_deleted,false)=false ON CONFLICT(server_id,user_id) DO UPDATE SET username=EXCLUDED.username,last_seen_at=NOW()",[String(bot.rows[0].user_id),String(bot.rows[0].username),milestone,targetId]).catch(()=>{});
        }
      }
    }
    const updatedCounts=await db.query("SELECT (SELECT COUNT(*) FROM follows WHERE following_id=$1)+COALESCE((SELECT follower_bonus FROM profiles WHERE user_id=$1),0) AS followers",[targetId]);
    c.followers=updatedCounts.rows[0]?.followers??followerTotal;
    return res.json({ok:true,status:"following",followers:Number(c.followers||0),followingCount:Number(c.following_count||0),friends:Number(c.friends||0)});
  }
  else if(action==="unfollow"){
    await db.query("DELETE FROM follows WHERE follower_id=$1 AND following_id=$2",[me.user_id,targetId]);
    await refreshPlayerVerification(targetId);
    const counts=await db.query(
      "SELECT (SELECT COUNT(*) FROM follows WHERE following_id=$1) AS followers, (SELECT COUNT(*) FROM follows WHERE follower_id=$1) AS following_count, (SELECT COUNT(*) FROM friend_requests WHERE status='accepted' AND (sender_id=$1 OR receiver_id=$1)) AS friends",
      [targetId]
    );
    const c=counts.rows[0];
    return res.json({ok:true,status:"unfollowed",followers:Number(c.followers||0),followingCount:Number(c.following_count||0),friends:Number(c.friends||0)});
  }
  else if(action==="friend"){
    // Official GBLOX service accounts ignore friend requests regardless of their administrative role flag.
    const targetUsername=String(target.rows[0].username||"").toLowerCase();
    if(targetUsername==="gblox" || targetUsername==="gbloxbuilder"){
      return res.json({ok:true,status:"ignored",message:targetUsername==="gbloxbuilder"?"GbloxBuilder does not accept friend requests.":"Gblox does not accept friend requests."});
    }
    const existing=await db.query("SELECT status FROM friend_requests WHERE (sender_id=$1 AND receiver_id=$2) OR (sender_id=$2 AND receiver_id=$1) ORDER BY updated_at DESC LIMIT 1",[me.user_id,targetId]);
    if(existing.rows[0]?.status==="accepted") return res.json({ok:true,status:"accepted"});
    if(existing.rows[0]?.status==="pending") return res.json({ok:true,status:"pending"});

    // Add_Me_Get_Ban never bans people for sending a request.
    // Its only moderation action happens when the specific Lol account accepts
    // the bot's own pending request; that acceptance handler is below.

    // All other bot accounts use the normal friend-request flow.
    const autoAccept=String(target.rows[0].role||"") === "bot";
    const senderRole=await db.query("SELECT role FROM profiles WHERE user_id=$1 LIMIT 1",[me.user_id]);
    const nextStatus=autoAccept && String(senderRole.rows[0]?.role||"") === "administrator" ? "accepted" : "pending";
    const inserted=await db.query("INSERT INTO friend_requests(sender_id,receiver_id,status,created_at,updated_at) VALUES($1,$2,$3,now(),now()) ON CONFLICT(sender_id,receiver_id) DO UPDATE SET status=EXCLUDED.status,updated_at=NOW() RETURNING status",[me.user_id,targetId,nextStatus]);
    if(inserted.rows[0]?.status==="accepted") return res.json({ok:true,status:"accepted",autoAccepted:true});
    return res.json({ok:true,status:"pending"});
  } else if(action==="unfriend"){
    await db.query("DELETE FROM friend_requests WHERE status='accepted' AND ((sender_id=$1 AND receiver_id=$2) OR (sender_id=$2 AND receiver_id=$1))",[me.user_id,targetId]);
    const counts=await db.query("SELECT (SELECT COUNT(*) FROM friend_requests WHERE status='accepted' AND (sender_id=$1 OR receiver_id=$1)) AS friends",[targetId]);
    return res.json({ok:true,status:"none",friends:Number(counts.rows[0]?.friends||0)});
  } else if(action==="accept_friend" || action==="decline_friend"){
    if(action==="accept_friend" && ["gblox","gbloxbuilder"].includes(String(me.username||"").toLowerCase())){
      return res.json({ok:true,status:"ignored",message:"This GBLOX service account does not accept friend requests."});
    }
    const senderId=String(req.body?.sender_id||"").trim();
    if(!senderId || senderId===me.user_id) return res.status(400).json({error:"Invalid friend request."});
    const q=await db.query("SELECT sender_id FROM friend_requests WHERE sender_id=$1 AND receiver_id=$2 AND status='pending'",[senderId,me.user_id]);
    if(!q.rows[0]) return res.status(404).json({error:"Friend request not found."});
    const next=action==="accept_friend"?"accepted":"declined";
    await db.query("UPDATE friend_requests SET status=$1,updated_at=now() WHERE sender_id=$2 AND receiver_id=$3 AND status='pending'",[next,senderId,me.user_id]);

    // The bot's friend request is a one-time 2-minute test ban only when
    // the exact Lol account accepts it. The accepted friendship is retained.
    if(next==="accepted" && String(me.username||"").toLowerCase()==="lol"){
      const bot=await db.query("SELECT user_id,username FROM profiles WHERE LOWER(username)='add_me_get_ban' AND role='bot' LIMIT 1");
      if(bot.rows[0] && String(bot.rows[0].user_id)===senderId){
        const reason="add_me_get_ban automated time ban";
        const moderatorName="001System";
        const startedAt=new Date();
        const until=new Date(startedAt.getTime()+2*60*1000);
        const locked=await db.query(
          "UPDATE profiles SET banned=true,terminated=false,verified=false,ban_note=$1,temp_ban_until=$2,last_ban_duration_days=0,moderation_violation_count=moderation_violation_count+1 WHERE user_id=$3 AND terminated=false AND (banned=false OR temp_ban_until IS NULL OR temp_ban_until<=NOW()) RETURNING user_id,username",
          [reason,until,me.user_id]
        );
        if(locked.rows[0]){
          await db.query(
            "UPDATE gblocks_players SET moderation_status='banned',moderation_note=$1,temp_ban_until=$2,last_ban_duration_days=0,moderation_violation_count=moderation_violation_count+1 WHERE user_id=$3",
            [reason,until,me.user_id]
          ).catch(()=>{});
          await db.query(
            "INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",
            ["TEMP_BAN",me.user_id,me.username,senderId,moderatorName,reason,JSON.stringify({temporary:true,durationMinutes:2,startedAt:startedAt.toISOString(),expiresAt:until.toISOString(),trigger:"friend_request_accepted",bot:true})]
          );
          const discordWebhook=process.env.GROBLOX_DISCORD_BANS_WEBHOOK||process.env.GROBLOX_DISCORD_WEBHOOK;
          const discordToken=process.env.GROBLOX_DISCORD_BOT_TOKEN;
          const discordChannel=process.env.GROBLOX_DISCORD_BANS_CHANNEL_ID||process.env.GROBLOX_DISCORD_LOG_CHANNEL_ID;
          let discordSent=false, discordStatus=null, discordError=null;
          const discordEmbed={title:"GBLOCKS • TEMPORARY BAN",fields:[
            {name:"Target",value:String(me.username||me.user_id),inline:true},
            {name:"User ID",value:String(me.user_id),inline:true},
            {name:"Reason",value:reason,inline:false},
            {name:"Duration",value:"2 minutes",inline:true},
            {name:"Moderator",value:moderatorName,inline:true},
            {name:"Started",value:startedAt.toISOString(),inline:false},
            {name:"Expires",value:until.toISOString(),inline:false}
          ],timestamp:startedAt.toISOString()};
          try{
            let response=null;
            if(discordWebhook) response=await fetch(discordWebhook,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({username:"GBLOCKS Logs",embeds:[discordEmbed]})});
            else if(discordToken&&discordChannel) response=await fetch("https://discord.com/api/v10/channels/"+encodeURIComponent(discordChannel)+"/messages",{method:"POST",headers:{"content-type":"application/json",authorization:"Bot "+discordToken},body:JSON.stringify({embeds:[discordEmbed]})});
            else discordError="No Discord webhook or bot/channel configuration is available at runtime.";
            if(response){discordStatus=response.status;discordSent=response.ok;if(!discordSent)discordError=(await response.text()).slice(0,500);}
          }catch(err){discordError=String(err?.message||err).slice(0,500);}
          await db.query("INSERT INTO audit_logs(action,target_user_id,target_username,actor_user_id,actor_username,reason,details) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",["DISCORD_LOG",me.user_id,me.username,senderId,moderatorName,discordSent?"Discord temporary-ban log sent":"Discord temporary-ban log failed",JSON.stringify({sourceAction:"TEMP_BAN",discordSent,discordStatus,discordError})]).catch(()=>{});
          return res.json({ok:true,status:"accepted_and_temporarily_banned",duration_minutes:2,moderator:moderatorName,expires_at:until.toISOString(),friendship_preserved:true,discord_logged:discordSent,discord_status:discordStatus,discord_error:discordSent?null:discordError,message:"Friend request accepted. A 2-minute temporary ban was applied by 001 system; the friendship remains."});
        }
      }
    }
    return res.json({ok:true,status:next});
  } else return res.status(400).json({error:"Unknown social action."});
  res.json({ok:true});
}