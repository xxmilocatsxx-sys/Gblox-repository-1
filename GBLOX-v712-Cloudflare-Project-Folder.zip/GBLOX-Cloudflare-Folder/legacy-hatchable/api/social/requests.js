import { db } from "hatchable";

export const access = "public";
export const methods = ["GET"];

const enc = new TextEncoder();
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
async function tokenHash(t){ return b64(await crypto.subtle.digest("SHA-256",enc.encode(t))); }
function cookie(req){ return String(req.headers?.cookie||"").match(/(?:^|;\s*)groblox_session=([^;]*)/)?.[1]||null; }

export default async function(req,res){
  const t=cookie(req);
  if(!t) return res.status(401).json({error:"Log in first.",requests:[],count:0});
  const me=await db.query("SELECT s.user_id,p.banned,p.terminated FROM account_sessions s JOIN profiles p ON p.user_id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW()",[await tokenHash(t)]);
  const user=me.rows[0];
  if(!user) return res.status(401).json({error:"Log in first.",requests:[],count:0});
  if(user.banned||user.terminated) return res.status(403).json({error:"Your account cannot use friend requests.",requests:[],count:0});
  const q=await db.query("SELECT fr.sender_id,CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE p.username END AS username,CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN 'Account Deactivated' ELSE p.display_name END AS display_name,CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN '{}'::jsonb ELSE p.avatar END AS avatar,CASE WHEN COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL THEN false ELSE p.verified END AS verified,(COALESCE(p.deactivated_at,gp.deactivated_at) IS NOT NULL) AS deactivated FROM friend_requests fr JOIN profiles p ON p.user_id=fr.sender_id LEFT JOIN gblocks_players gp ON gp.user_id=p.user_id WHERE fr.receiver_id=$1 AND fr.status='pending' ORDER BY fr.created_at DESC",[user.user_id]);
  res.json({requests:q.rows,count:q.rows.length});
}