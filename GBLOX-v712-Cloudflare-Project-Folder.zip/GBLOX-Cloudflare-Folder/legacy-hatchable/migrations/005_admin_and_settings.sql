-- Bootstrap the legacy profiles table on fresh forks/staging copies.
-- The production GBlocks database already has this table, so this is a no-op there.
CREATE TABLE IF NOT EXISTS profiles (
  user_id text PRIMARY KEY,
  username text NOT NULL UNIQUE,
  display_name text NOT NULL,
  bio text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT NOW(),
  avatar jsonb NOT NULL DEFAULT '{}'::jsonb,
  verified boolean NOT NULL DEFAULT false,
  role text NOT NULL DEFAULT 'user',
  banned boolean NOT NULL DEFAULT false,
  terminated boolean NOT NULL DEFAULT false,
  creator_role text,
  temp_ban_until timestamptz,
  ban_note text NOT NULL DEFAULT '',
  follower_count_bonus bigint NOT NULL DEFAULT 0,
  user_number bigint UNIQUE
);

CREATE TABLE IF NOT EXISTS administrator_credentials (
  user_id text PRIMARY KEY REFERENCES profiles(user_id) ON DELETE CASCADE,
  email text NOT NULL UNIQUE,
  password_salt text NOT NULL,
  password_hash text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_settings (
  user_id text PRIMARY KEY,
  birthday date,
  app_theme text NOT NULL DEFAULT 'system',
  social_accounts jsonb NOT NULL DEFAULT '{}'::jsonb,
  profile_visibility text NOT NULL DEFAULT 'public',
  birthday_visibility text NOT NULL DEFAULT 'private',
  social_visibility text NOT NULL DEFAULT 'public',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);