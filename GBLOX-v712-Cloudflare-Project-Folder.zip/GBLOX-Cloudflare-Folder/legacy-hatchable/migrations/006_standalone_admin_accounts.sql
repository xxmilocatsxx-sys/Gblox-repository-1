CREATE TABLE IF NOT EXISTS admin_accounts (
  admin_id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  username text NOT NULL UNIQUE,
  password_salt text NOT NULL,
  password_hash text NOT NULL,
  banned boolean NOT NULL DEFAULT false,
  terminated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT NOW(),
  updated_at timestamptz NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS admin_sessions (
  token_hash text PRIMARY KEY,
  admin_id text NOT NULL REFERENCES admin_accounts(admin_id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);
INSERT INTO admin_accounts (admin_id,username,password_salt,password_hash,banned,terminated,created_at,updated_at)
SELECT c.user_id,p.username,c.password_salt,c.password_hash,p.banned,p.terminated,NOW(),NOW()
FROM administrator_credentials c JOIN profiles p ON p.user_id=c.user_id
WHERE NOT EXISTS (SELECT 1 FROM admin_accounts a WHERE LOWER(a.username)=LOWER(p.username));