INSERT INTO profiles (user_id,username,display_name,bio,avatar,verified,role,banned,terminated,user_number,always_online)
SELECT gen_random_uuid()::text,'Reddit','Reddit','Gblocks automated bot account.','{}'::jsonb,false,'bot',false,false,COALESCE((SELECT MAX(user_number) FROM profiles),0)+1,true
WHERE NOT EXISTS (SELECT 1 FROM profiles WHERE lower(username)=lower('Reddit'))