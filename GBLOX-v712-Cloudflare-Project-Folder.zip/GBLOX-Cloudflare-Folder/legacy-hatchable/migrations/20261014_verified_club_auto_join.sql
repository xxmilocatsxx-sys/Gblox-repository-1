-- Create Verified Club under Milo's real GBLOX player account.
-- Use a stable group id and avoid creating a second group if the name already exists.
INSERT INTO groups (id, name, description, owner_id, verified, is_private, manual_verified)
SELECT 'verified-club', 'Verified Club',
       'Official group for players with the GBLOX Verified badge. Verified players are added automatically.',
       '0e1e36ba-b824-4bf3-803a-22e2f9af86db', true, false, true
WHERE NOT EXISTS (SELECT 1 FROM groups WHERE lower(name) = lower('Verified Club'));

-- Ensure the existing group is public and owned by Milo, without resetting its other data.
UPDATE groups
   SET owner_id = '0e1e36ba-b824-4bf3-803a-22e2f9af86db',
       is_private = false,
       verified = true,
       manual_verified = true,
       description = 'Official group for players with the GBLOX Verified badge. Verified players are added automatically.'
 WHERE lower(name) = lower('Verified Club');

-- Keep Milo's owner membership and enroll every currently verified, active player.
INSERT INTO group_members (group_id, user_id, role)
SELECT g.id, g.owner_id, 'owner'
  FROM groups g
 WHERE lower(g.name) = lower('Verified Club')
ON CONFLICT (group_id, user_id) DO UPDATE SET role = 'owner';

INSERT INTO group_members (group_id, user_id, role)
SELECT g.id, p.user_id, 'member'
  FROM groups g
  JOIN profiles p ON p.verified = true
 WHERE lower(g.name) = lower('Verified Club')
   AND p.banned = false
   AND p.terminated = false
   AND p.user_id <> g.owner_id
ON CONFLICT (group_id, user_id) DO NOTHING;

-- A verified badge is authoritative only when the stored profile flag is true.
-- Run after insert and after any update that changes verification or account availability.
CREATE OR REPLACE FUNCTION gblox_verified_club_auto_join()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.verified = true AND NEW.banned = false AND NEW.terminated = false THEN
    INSERT INTO group_members (group_id, user_id, role)
    SELECT g.id, NEW.user_id,
           CASE WHEN g.owner_id = NEW.user_id THEN 'owner' ELSE 'member' END
      FROM groups g
     WHERE lower(g.name) = lower('Verified Club')
       AND COALESCE(g.moderation_banned, false) = false
       AND COALESCE(g.moderation_deleted, false) = false
    ON CONFLICT (group_id, user_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS gblox_verified_club_after_profile_save ON profiles;
CREATE TRIGGER gblox_verified_club_after_profile_save
AFTER INSERT OR UPDATE OF verified, banned, terminated ON profiles
FOR EACH ROW EXECUTE FUNCTION gblox_verified_club_auto_join();