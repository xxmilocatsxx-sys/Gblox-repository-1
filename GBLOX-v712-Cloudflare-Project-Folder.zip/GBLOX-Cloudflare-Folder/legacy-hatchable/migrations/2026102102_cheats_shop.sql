CREATE TABLE IF NOT EXISTS cheats_shop_inventory (
  user_id TEXT NOT NULL,
  item_id TEXT NOT NULL,
  purchased_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, item_id)
);
CREATE INDEX IF NOT EXISTS cheats_shop_inventory_user_idx ON cheats_shop_inventory(user_id);