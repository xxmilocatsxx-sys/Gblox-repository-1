CREATE TABLE IF NOT EXISTS direct_messages (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  sender_id text NOT NULL,
  receiver_id text NOT NULL,
  message text NOT NULL,
  read_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS direct_messages_receiver_idx ON direct_messages(receiver_id, created_at DESC);
CREATE INDEX IF NOT EXISTS direct_messages_pair_idx ON direct_messages(sender_id, receiver_id, created_at DESC);

CREATE TABLE IF NOT EXISTS gblocks_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  actor_user_id text NULL,
  actor_username text NULL,
  type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  read_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS gblocks_notifications_user_idx ON gblocks_notifications(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS admin_messages (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  recipient_username text NOT NULL,
  sender_username text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  read_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS admin_messages_recipient_idx ON admin_messages(recipient_username, created_at DESC);