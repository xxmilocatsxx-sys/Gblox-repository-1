-- Count one legitimate visit per signed-in player, game, and browser-tab session.
ALTER TABLE game_visit_receipts ADD COLUMN IF NOT EXISTS visit_session_id text;
UPDATE game_visit_receipts
SET visit_session_id = 'legacy-' || md5(user_id || ':' || game_id)
WHERE visit_session_id IS NULL;
ALTER TABLE game_visit_receipts ALTER COLUMN visit_session_id SET NOT NULL;
ALTER TABLE game_visit_receipts DROP CONSTRAINT IF EXISTS game_visit_receipts_pkey;
ALTER TABLE game_visit_receipts ADD CONSTRAINT game_visit_receipts_pkey PRIMARY KEY (user_id, game_id, visit_session_id);

CREATE OR REPLACE FUNCTION gblocks_refresh_creator_verified(p_user_id text)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  followers_count bigint;
  group_members_count bigint;
  legitimate_visits bigint;
BEGIN
  IF p_user_id IS NULL OR p_user_id = '' THEN RETURN; END IF;
  SELECT count(*) INTO followers_count FROM follows WHERE following_id = p_user_id;
  SELECT count(*) INTO group_members_count
    FROM group_members gm JOIN groups g ON g.id = gm.group_id
    WHERE g.owner_id = p_user_id;
  SELECT COALESCE(sum(visits), 0) INTO legitimate_visits
    FROM games WHERE creator_id = p_user_id;
  IF followers_count >= 100 AND group_members_count >= 300 AND legitimate_visits >= 5000 THEN
    UPDATE profiles SET verified = true WHERE user_id = p_user_id AND banned = false AND terminated = false;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION gblocks_follows_verified_trigger()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP <> 'INSERT' THEN PERFORM gblocks_refresh_creator_verified(OLD.following_id); END IF;
  IF TG_OP <> 'DELETE' THEN PERFORM gblocks_refresh_creator_verified(NEW.following_id); END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;
DROP TRIGGER IF EXISTS gblocks_follows_verified ON follows;
CREATE TRIGGER gblocks_follows_verified
AFTER INSERT OR UPDATE OR DELETE ON follows
FOR EACH ROW EXECUTE FUNCTION gblocks_follows_verified_trigger();

CREATE OR REPLACE FUNCTION gblocks_group_members_verified_trigger()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  old_owner text;
  new_owner text;
BEGIN
  IF TG_OP <> 'INSERT' THEN
    SELECT owner_id INTO old_owner FROM groups WHERE id = OLD.group_id;
    PERFORM gblocks_refresh_creator_verified(old_owner);
  END IF;
  IF TG_OP <> 'DELETE' THEN
    SELECT owner_id INTO new_owner FROM groups WHERE id = NEW.group_id;
    PERFORM gblocks_refresh_creator_verified(new_owner);
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;
DROP TRIGGER IF EXISTS gblocks_group_members_verified ON group_members;
CREATE TRIGGER gblocks_group_members_verified
AFTER INSERT OR UPDATE OR DELETE ON group_members
FOR EACH ROW EXECUTE FUNCTION gblocks_group_members_verified_trigger();

CREATE OR REPLACE FUNCTION gblocks_games_verified_trigger()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM gblocks_refresh_creator_verified(NEW.creator_id);
  ELSIF TG_OP = 'UPDATE' AND (NEW.visits IS DISTINCT FROM OLD.visits OR NEW.creator_id IS DISTINCT FROM OLD.creator_id) THEN
    PERFORM gblocks_refresh_creator_verified(NEW.creator_id);
    IF NEW.creator_id IS DISTINCT FROM OLD.creator_id THEN
      PERFORM gblocks_refresh_creator_verified(OLD.creator_id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS gblocks_games_verified ON games;
DROP TRIGGER IF EXISTS gblocks_games_verified_insert ON games;
CREATE TRIGGER gblocks_games_verified_insert
AFTER INSERT ON games
FOR EACH ROW EXECUTE FUNCTION gblocks_games_verified_trigger();
CREATE TRIGGER gblocks_games_verified
AFTER UPDATE OF visits, creator_id ON games
FOR EACH ROW EXECUTE FUNCTION gblocks_games_verified_trigger();

-- Backfill verification for creators who already meet all thresholds.
UPDATE profiles p
SET verified = true
WHERE p.banned = false
  AND p.terminated = false
  AND (SELECT count(*) FROM follows f WHERE f.following_id = p.user_id) >= 100
  AND (SELECT count(*) FROM group_members gm JOIN groups g ON g.id = gm.group_id WHERE g.owner_id = p.user_id) >= 300
  AND (SELECT COALESCE(sum(gm.visits), 0) FROM games gm WHERE gm.creator_id = p.user_id) >= 5000;