ALTER TABLE gblocks_players ADD COLUMN IF NOT EXISTS deactivated_at TIMESTAMPTZ;
ALTER TABLE gblocks_players ADD COLUMN IF NOT EXISTS legacy_status TEXT NOT NULL DEFAULT 'active';
ALTER TABLE gblocks_players ADD COLUMN IF NOT EXISTS legacy_bot_enabled BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE gblocks_players ADD COLUMN IF NOT EXISTS legacy_reviewed_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS gblocks_players_deactivated_idx ON gblocks_players (deactivated_at, legacy_status);
CREATE TABLE IF NOT EXISTS gblocks_account_deletion_audit (
 id BIGSERIAL PRIMARY KEY,
 target_user_id TEXT NOT NULL,
 target_username TEXT NOT NULL,
 admin_user_id TEXT NOT NULL,
 admin_username TEXT NOT NULL,
 reason TEXT NOT NULL,
 deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
)