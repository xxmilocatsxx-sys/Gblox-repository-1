CREATE TABLE IF NOT EXISTS gblocks_beta_release_cycle (
  id INTEGER PRIMARY KEY CHECK (id=1),
  beta_updates_completed INTEGER NOT NULL DEFAULT 0,
  current_update_number INTEGER NOT NULL DEFAULT 1,
  phase TEXT NOT NULL DEFAULT 'beta',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO gblocks_beta_release_cycle (id,beta_updates_completed,current_update_number,phase)
VALUES (1,0,1,'beta')
ON CONFLICT (id) DO NOTHING;