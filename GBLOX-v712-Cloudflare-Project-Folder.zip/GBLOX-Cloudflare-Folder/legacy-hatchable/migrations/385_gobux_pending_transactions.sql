CREATE TABLE IF NOT EXISTS gobux_pending_credits (
  transaction_id text PRIMARY KEY,
  recipient_user_id text NOT NULL,
  source_type text NOT NULL,
  source_id text NOT NULL,
  amount numeric(80,0) NOT NULL CHECK (amount > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','released','cancelled')),
  available_at timestamptz NOT NULL DEFAULT (now() + interval '5 days'),
  created_at timestamptz NOT NULL DEFAULT now(),
  released_at timestamptz
)