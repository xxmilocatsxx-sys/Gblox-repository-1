CREATE TABLE IF NOT EXISTS group_gobux_purchases (
  transaction_id text PRIMARY KEY,
  group_id text NOT NULL,
  buyer_user_id text NOT NULL,
  recipient_user_id text NOT NULL,
  amount numeric(80,0) NOT NULL CHECK (amount > 0),
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
)