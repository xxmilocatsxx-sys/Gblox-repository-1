CREATE TABLE IF NOT EXISTS gamepasses (
  id text PRIMARY KEY,
  owner_user_id text NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  price bigint NOT NULL CHECK (price BETWEEN 1 AND 1000000),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS gamepasses_owner_active_idx ON gamepasses(owner_user_id, active, created_at DESC);
CREATE TABLE IF NOT EXISTS gamepass_purchases (
  id text PRIMARY KEY,
  gamepass_id text NOT NULL REFERENCES gamepasses(id),
  buyer_user_id text NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
  seller_user_id text NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
  price bigint NOT NULL CHECK (price > 0),
  buyer_ip_hash text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(gamepass_id, buyer_user_id)
);
CREATE INDEX IF NOT EXISTS gamepass_purchases_seller_ip_idx ON gamepass_purchases(seller_user_id, buyer_ip_hash, created_at DESC);
CREATE INDEX IF NOT EXISTS gamepass_purchases_buyer_idx ON gamepass_purchases(buyer_user_id, created_at DESC);