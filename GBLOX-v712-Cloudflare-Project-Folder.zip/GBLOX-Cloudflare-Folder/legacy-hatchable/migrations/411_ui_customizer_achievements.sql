ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS accent_color TEXT NOT NULL DEFAULT 'blue';
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS profile_theme TEXT NOT NULL DEFAULT 'neon';
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS reduced_motion BOOLEAN NOT NULL DEFAULT FALSE;
CREATE TABLE IF NOT EXISTS gblocks_user_achievements (
 user_id TEXT NOT NULL,
 achievement_key TEXT NOT NULL,
 unlocked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY (user_id, achievement_key)
);
CREATE INDEX IF NOT EXISTS gblocks_user_achievements_user_idx ON gblocks_user_achievements (user_id, unlocked_at DESC);