-- GBLOX Community is a verified community; every active account is enrolled automatically.
UPDATE groups
SET verified = true, manual_verified = true, is_private = false,
    description = 'Official community for new and longtime GBLOX players. All active accounts are automatically included.'
WHERE id = 'gblox-community';

INSERT INTO group_members (group_id, user_id, role)
SELECT 'gblox-community', p.user_id,
       CASE WHEN p.user_id = 'f89a8f80-3c8d-4b42-a3e6-b3fca4e3a5e9' THEN 'owner' ELSE 'member' END
FROM profiles p
WHERE p.banned = false AND p.terminated = false
ON CONFLICT (group_id, user_id) DO NOTHING;

CREATE OR REPLACE FUNCTION gblox_auto_join_community()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.banned = false AND NEW.terminated = false
     AND EXISTS (SELECT 1 FROM groups WHERE id = 'gblox-community') THEN
    INSERT INTO group_members (group_id, user_id, role)
    VALUES ('gblox-community', NEW.user_id,
      CASE WHEN NEW.user_id = 'f89a8f80-3c8d-4b42-a3e6-b3fca4e3a5e9' THEN 'owner' ELSE 'member' END)
    ON CONFLICT (group_id, user_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS gblox_auto_join_community_after_profile_insert ON profiles;
CREATE TRIGGER gblox_auto_join_community_after_profile_insert
AFTER INSERT ON profiles
FOR EACH ROW EXECUTE FUNCTION gblox_auto_join_community();