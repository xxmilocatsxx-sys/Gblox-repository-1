CREATE TABLE IF NOT EXISTS gblox_account_link_policy (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  deadline_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO gblox_account_link_policy (id, deadline_at)
VALUES (1, NOW() + INTERVAL '4 days')
ON CONFLICT (id) DO NOTHING;