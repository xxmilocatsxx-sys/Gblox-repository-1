CREATE TABLE IF NOT EXISTS gobux_bot_reward_state (
  user_id text PRIMARY KEY,
  last_accrued_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO gobux_bot_reward_state (user_id, last_accrued_at)
SELECT p.user_id, now()
FROM profiles p
WHERE p.banned=false AND p.terminated=false AND p.deactivated_at IS NULL
  AND (lower(p.username)='gblox' OR (p.role='bot' AND p.is_bot=true))
ON CONFLICT (user_id) DO NOTHING;

CREATE INDEX IF NOT EXISTS gobux_bot_reward_state_updated_idx
  ON gobux_bot_reward_state (updated_at);