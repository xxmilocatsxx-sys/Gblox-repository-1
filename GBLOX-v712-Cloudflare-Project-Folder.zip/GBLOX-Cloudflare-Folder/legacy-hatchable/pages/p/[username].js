import { db, storage } from "hatchable";
export const access = "public";
const esc = (s) => String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");
export default async function(req,res){
  const key=String(req.params?.username||"").trim();
  if(!key || key.length>100) return res.status(404).send(notFound());
  const numeric=/^\d+$/.test(key);
  const where=numeric ? "p.user_number=$1::int" : "LOWER(p.username)=LOWER($1)";
  const {rows}=await db.query("SELECT p.user_id,p.user_number,p.username,p.display_name,p.bio,p.avatar,p.banned,p.terminated,p.bio_deleted_by_moderation,p.deactivated_at,COALESCE(p.legacy_status,gp.legacy_status,'active') AS legacy_status,COALESCE(s.profile_visibility,'public') AS profile_visibility FROM profiles p LEFT JOIN gblocks_players gp ON gp.user_id=p.user_id LEFT JOIN user_settings s ON s.user_id=p.user_id WHERE "+where+" LIMIT 1",[key]);
  const p=rows[0];
  if(!p || p.terminated || p.deactivated_at || p.legacy_status==='deleted' || p.profile_visibility==='private') return res.status(404).send(notFound());
  const url="https://gblocks.hatchable.site/p/"+encodeURIComponent(p.username);
  const title=String(p.display_name||p.username||"GBLOX Player")+" | GBLOX";
  const description=(p.banned ? "GBLOX player profile." : (p.bio_deleted_by_moderation ? "A player on GBLOX." : String(p.bio||"GBLOX player profile.").trim().slice(0,180))) || "GBLOX player profile.";
  let avatar=p.avatar && typeof p.avatar==="object" ? String(p.avatar.image_url||"") : "";
  if(!avatar || avatar.startsWith("/")) avatar="https://gblocks.hatchable.site/avatar-default.svg";
  else if(!/^https:\/\//i.test(avatar)) avatar="https://gblocks.hatchable.site/avatar-default.svg";
  const body='<main><div class="brand">GBLOX</div><img class="avatar" src="'+esc(avatar)+'" alt="Player avatar"><h1>'+esc(title.replace(/ \| GBLOX$/,""))+'</h1><p class="handle">@'+esc(p.username)+'</p><p>'+esc(description)+'</p><a href="/profile.html?username='+encodeURIComponent(p.username)+'">View full profile</a><p class="foot">A player profile on GBLOX</p></main>';
  res.setHeader("Cache-Control","public, max-age=60, s-maxage=60");
  return res.send('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><meta name="description" content="'+esc(description)+'"><link rel="canonical" href="'+esc(url)+'"><meta property="og:type" content="profile"><meta property="og:site_name" content="GBLOX"><meta property="og:title" content="'+esc(title)+'"><meta property="og:description" content="'+esc(description)+'"><meta property="og:url" content="'+esc(url)+'"><meta property="og:image" content="'+esc(avatar)+'"><meta property="og:image:alt" content="GBLOX player avatar"><meta name="theme-color" content="#b51224"><meta name="twitter:card" content="summary"><style>body{margin:0;background:#080b12;color:#f4f6fb;font:16px system-ui,Arial}main{box-sizing:border-box;max-width:680px;margin:7vh auto;padding:28px;text-align:center;background:#111723;border:1px solid #293348;border-radius:18px}.brand{font-weight:950;letter-spacing:3px;color:#ef3340}.avatar{width:128px;height:128px;object-fit:cover;border-radius:18px;margin-top:22px;background:#202a3c}h1{margin:14px 0 4px}.handle,.foot{color:#aab4c7}p{overflow-wrap:anywhere}a{display:inline-block;background:#b51224;color:white;text-decoration:none;font-weight:800;padding:12px 18px;border-radius:10px;margin-top:10px}</style></head><body>'+body+'</body></html>');
}
function notFound(){return '<!doctype html><html><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>Profile not found | GBLOX</title><meta name="theme-color" content="#b51224"></head><body style="background:#080b12;color:#fff;font:16px system-ui;padding:32px"><h1>Profile not found</h1><a href="https://gblocks.hatchable.site/players.html">Browse GBLOX players</a></body></html>';}