(async function(){
  const box=document.getElementById('accounts');
  if(!box)return;
  function esc(v){return String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;')}
  function render(accounts){
    if(!Array.isArray(accounts)||!accounts.length){box.innerHTML='<div class="muted">No GBLOCKS accounts found.</div>';return;}
    box.innerHTML='<table><thead><tr><th>User #</th><th>Username</th><th>Display Name</th><th>Role</th><th>Creator</th><th>Verified</th><th>Status</th></tr></thead><tbody>'+accounts.map(a=>'<tr><td>#'+esc(a.user_number??'—')+'</td><td>'+esc(a.username)+'</td><td>'+esc(a.display_name)+' '+(a.restricted_admin_badge?'<img class="badge-icon" src="/badges/restricted-admin.svg?v=464" alt="Restricted Admin">':(String(a.role||'').toLowerCase()==='administrator'?'<img class="badge-icon" src="/badges/admin.svg?v=464" alt="Admin">':''))+(a.creator_role==='creator'?'<span class="creator-badge">Creator</span>':a.creator_role==='creator_alt'?'<span class="creator-alt-badge">Creator Alt</span>':'')+(a.verified?'<img class="badge-icon" src="/badges/verified.svg?v=464" alt="Verified">':'')+(a.premium_active?'<img class="badge-icon" src="/badges/premium.svg?v=464" alt="Premium">':'')+'</td><td><span class="pill">'+esc(a.role||'user')+'</span></td><td>'+esc(a.creator_role||'—')+'</td><td>'+(a.verified?'<img class="badge-icon" src="/badges/verified.svg?v=464" alt="Verified">':'—')+'</td><td>'+esc(a.terminated?'Terminated':(a.banned?'Banned':'Active'))+'</td></tr>').join('')+'</tbody></table>';
  }
  async function loadAccounts(){
    try{
      box.innerHTML='<div class="muted">Loading accounts…</div>';
      const r=await fetch('/api/admin/status',{cache:'no-store',credentials:'same-origin'});
      let d={};try{d=await r.json()}catch{}
      if(!r.ok)throw new Error(d.error||('Admin status returned HTTP '+r.status));
      render(d.accounts);
      const top=document.getElementById('topStatus');
      if(top){top.textContent='Signed in as '+(d.administrator||'administrator');top.className='status ok'}
    }catch(e){
      box.innerHTML='<div class="danger">Unable to load accounts: '+esc(e.message||'Unknown error')+'</div>';
    }
  }
  window.grobloxReloadAccounts=loadAccounts;
  await loadAccounts();
})();