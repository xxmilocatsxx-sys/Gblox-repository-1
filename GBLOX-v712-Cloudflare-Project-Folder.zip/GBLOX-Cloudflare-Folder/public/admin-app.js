(() => {
  const api='/api';
  const q=id=>document.getElementById(id);
  const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
  const msg=(id,t,good=false)=>{const el=q(id);if(el){el.textContent=t;el.className='status '+(good?'ok':'danger')}};
  async function loadAnnouncer(){
    const title=q('announcerTitle'), body=q('announcerBody'), status=q('announcerStatus');
    if(!title||!body)return;
    try{
      const r=await fetch(api+'/admin/announcer',{cache:'no-store',credentials:'same-origin'});
      const d=await r.json();
      if(!r.ok)throw new Error(d.error||'Could not load announcer.');
      const a=d.announcement;
      title.value=a?.title||'';
      body.value=a?.body||'';
      if(status)status.textContent=a?'Published '+new Date(a.updated_at).toLocaleString():'No announcement is currently published.';
    }catch(e){if(status)status.textContent=e.message||'Could not load announcer.'}
  }
  async function publishAnnouncement(){
    const title=q('announcerTitle')?.value.trim()||'';
    const body=q('announcerBody')?.value.trim()||'';
    if(!title||!body)return msg('announcerStatus','Enter both an announcement title and message.');
    const btn=q('announcerPublish');if(btn)btn.disabled=true;
    try{
      const d=await call('/admin/announcer',{title,body});
      msg('announcerStatus',d.message||'Announcement published.',true);
      if(q('announcerTitle'))q('announcerTitle').value=d.announcement?.title||title;
      if(q('announcerBody'))q('announcerBody').value=d.announcement?.body||body;
    }catch(e){msg('announcerStatus',e.message||'Could not publish announcement.')}
    finally{if(btn)btn.disabled=false}
  }
  async function removeAnnouncement(){
    if(!confirm('Remove the current GBlocks announcement from players?'))return;
    const btn=q('announcerRemove');if(btn)btn.disabled=true;
    try{
      const r=await fetch(api+'/admin/announcer',{method:'DELETE',credentials:'same-origin',cache:'no-store'});
      const d=await r.json();
      if(!r.ok)throw new Error(d.error||'Could not remove announcement.');
      if(q('announcerTitle'))q('announcerTitle').value='';
      if(q('announcerBody'))q('announcerBody').value='';
      msg('announcerStatus',d.message||'GBlocks announcement removed.',true);
    }catch(e){msg('announcerStatus',e.message||'Could not remove announcement.')}
    finally{if(btn)btn.disabled=false}
  }
  function showAdmin(signedIn){
    const login=q('adminLogin'), setup=q('adminEmailSetup'), controls=q('adminControls');
    if(login)login.style.display=signedIn?'none':'block';
    if(setup)setup.style.display='none';
    if(controls)controls.style.display=signedIn?'block':'none';
  }
  async function grant257Achievement(){
    const userId=q('achievementUser')?.value||'';const years=Number(q('achievementYears')?.value||0);
    if(!userId)return msg('achievementStatus','Select an administrator player account first.');
    try{const d=await call('/admin/achievements',{user_id:userId,years});msg('achievementStatus','Granted '+d.achievement+' ('+d.years+' years) to @'+d.username+'.',true)}catch(e){msg('achievementStatus',e.message||'Could not grant achievement.')}
  }
  async function call(path,body){
    const r=await fetch(api+path,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(body||{})});
    let d={};try{d=await r.json()}catch{}
    if(!r.ok)throw new Error(d.error||`Request failed (HTTP ${r.status}).`);
    return d;
  }
  let accountsPage=1;
  const accountsPerPage=20;
  let allAccountsForPaging=[];
  function renderAccounts(accounts){
    const box=q('accounts'); if(!box)return;
    allAccountsForPaging=Array.isArray(accounts)?accounts.slice().sort((a,b)=>Number(a.user_number||0)-Number(b.user_number||0)):[];
    const totalPages=Math.max(1,Math.ceil(allAccountsForPaging.length/accountsPerPage));
    accountsPage=Math.min(Math.max(1,accountsPage),totalPages);
    if(!allAccountsForPaging.length){box.innerHTML='<div class="muted">No GBLOCKS accounts found.</div>';return;}
    const start=(accountsPage-1)*accountsPerPage;
    const pageAccounts=allAccountsForPaging.slice(start,start+accountsPerPage);
    box.innerHTML='<table><thead><tr><th>User #</th><th>Username</th><th>Display Name</th><th>Role</th><th>Creator</th><th>Verified</th><th>Status</th></tr></thead><tbody>'+pageAccounts.map(a=>'<tr><td>#'+esc(a.user_number??'—')+'</td><td>'+esc(a.username)+'</td><td>'+esc(a.display_name)+' '+(a.restricted_admin_badge?'<img class="badge-icon" src="/badges/restricted-admin.svg?v=464" alt="Restricted Admin">':(String(a.role||'').toLowerCase()==='administrator'?'<img class="badge-icon" src="/badges/admin.svg?v=464" alt="Admin">':''))+(a.creator_role==='creator'?'<span class="inline-badge creator-badge">Creator</span>':a.creator_role==='creator_alt'?'<span class="inline-badge creator-alt-badge">Creator Alt</span>':'')+(a.verified?'<img class="badge-icon" src="/badges/verified.svg?v=464" alt="Verified">':'')+(a.premium_active?'<img class="badge-icon" src="/badges/premium.svg?v=464" alt="Premium">':'')+'</td><td><span class="pill">'+esc(a.role||'user')+'</span>'+(a.premium_active?'<span class="pill premium-pill">Premium</span>':'')+(a.premium_permanent?'<span class="pill" style="border-color:#d9b441;color:#ffe08a">PERMANENT</span>':'')+'</td><td>'+esc(a.creator_role||'—')+'</td><td>'+(a.verified?'<img class="badge-icon" src="/badges/verified.svg?v=464" alt="Verified">':'—')+'</td><td>'+esc(a.terminated?'Terminated':(a.banned?'Banned':'Active'))+'</td></tr>').join('')+'</tbody></table><div class="accounts-pagination"><button class="gray" aria-label="First page, User ID 1" title="Back to User ID 1" onclick="accountsGoFirst()" '+(accountsPage<=1?'disabled':'')+'>«</button><button class="gray" aria-label="Previous page" title="Previous page" onclick="accountsGoPrev()" '+(accountsPage<=1?'disabled':'')+'>‹</button><span class="pill accounts-page-label">'+accountsPage+'/'+totalPages+'</span><button class="gray" aria-label="Next page" title="Next page" onclick="accountsGoNext()" '+(accountsPage>=totalPages?'disabled':'')+'>›</button><button class="gray" aria-label="Last page" title="Last page" onclick="accountsGoLast()" '+(accountsPage>=totalPages?'disabled':'')+'>»</button></div><div class="muted accounts-range">Users '+(start+1)+'–'+Math.min(start+accountsPerPage,allAccountsForPaging.length)+' of '+allAccountsForPaging.length+' · « = User ID 1</div>';
  }
  function accountsGoFirst(){accountsPage=1;renderAccounts(allAccountsForPaging);}
  function accountsGoPrev(){if(accountsPage>1){accountsPage--;renderAccounts(allAccountsForPaging);}}
  function accountsGoNext(){const total=Math.max(1,Math.ceil(allAccountsForPaging.length/accountsPerPage));if(accountsPage<total){accountsPage++;renderAccounts(allAccountsForPaging);}}
  function accountsGoLast(){accountsPage=Math.max(1,Math.ceil(allAccountsForPaging.length/accountsPerPage));renderAccounts(allAccountsForPaging);}
  async function load(){
    try{
      const r=await fetch(api+'/admin/status',{cache:'no-store',credentials:'same-origin'});
      let d={};try{d=await r.json()}catch{}
      if(!r.ok)throw new Error(d.error||`Admin status returned HTTP ${r.status}.`);
      if(d.panel_account!==true){showAdmin(false);const top=q('topStatus');if(top){top.textContent='A separate administrator-panel login is required. Sign in below with your administrator-panel username and password.';top.className='status danger'}return null;}
      showAdmin(true);
      const top=q('topStatus');if(top){top.textContent='Signed in as '+(d.administrator||'administrator');top.className='status ok'}
      renderAccounts(d.accounts);
      if(typeof window.loadAdminPanelAccounts==="function")void window.loadAdminPanelAccounts();
      // Populate every player selector immediately from the already-loaded admin/status response.
      // Do not wait for announcer, bio moderation, or any other secondary panel request.
      const verifySelect=q('verifyUser');
      const accounts=Array.isArray(d.accounts)?d.accounts:[];
      // Admin player selectors are ordered by the account's actual stored join date,
      // so older players (including manually restored historical dates) appear first.
      const pickerAccounts=Array.from(new Map(accounts.filter(a=>a&&a.user_id!=null).map(a=>[String(a.user_id),a])).values()).sort((a,b)=>{const ad=Date.parse(a.created_at||'');const bd=Date.parse(b.created_at||'');if(Number.isFinite(ad)&&Number.isFinite(bd)&&ad!==bd)return ad-bd;if(Number.isFinite(ad)!==Number.isFinite(bd))return Number.isFinite(ad)?-1:1;return Number(a.user_number||0)-Number(b.user_number||0)});
      const achievementUser=q('achievementUser');if(achievementUser){const current=achievementUser.value;achievementUser.innerHTML='<option value="">Select an administrator player account…</option>'+pickerAccounts.filter(a=>['admin','administrator'].includes(String(a.role||'').toLowerCase())).map(a=>'<option value="'+esc(a.user_id)+'">@'+esc(a.username)+' — '+esc(a.display_name||a.username)+'</option>').join('');if(current)achievementUser.value=current;}
      const achievementYears=q('achievementYears');if(achievementYears&&!achievementYears.options.length){achievementYears.innerHTML=Array.from({length:257},(_,i)=>'<option value="'+(i+1)+'">'+(i+1)+' year'+(i?'s':'')+'</option>').join('');achievementYears.value='257';}
      if(verifySelect){const current=verifySelect.value;verifySelect.innerHTML='<option value="">Select a Gblocks player account…</option>'+pickerAccounts.filter(a=>!a.terminated).map(a=>'<option value="'+esc(a.username)+'">'+esc(a.username)+(a.display_name&&a.display_name!==a.username?' — '+esc(a.display_name):'')+(a.verified?' ✓ Verified':'')+'</option>').join('');if(pickerAccounts.some(a=>a.username===current))verifySelect.value=current;}
      const accountSelects=['banUser','roleUser','followersUser','gobuxUser','premiumUser','restrictedAdminBadgeUser','joinDateUser','passUser','usernameResetCurrent','deleteUser'];
      accountSelects.forEach(id=>{const el=q(id);if(!el)return;const current=el.value;el.innerHTML='<option value="">Select a Gblocks player account…</option>'+pickerAccounts.map(x=>'<option value="'+esc(x.username)+'">@'+esc(x.username)+' — '+esc(x.display_name||x.username)+(x.verified?' ✓ Verified':'')+(x.terminated?' (Terminated)':(x.banned?' (Banned)':''))+'</option>').join('');if(current&&pickerAccounts.some(x=>x.username===current))el.value=current;});
      const usernameSelect=q('adminUsernameCurrent');
      if(usernameSelect){const current=usernameSelect.value;usernameSelect.innerHTML='<option value="">Select a Gblocks player account…</option>'+pickerAccounts.map(x=>'<option value="'+esc(x.user_id)+'">@'+esc(x.username)+' — '+esc(x.display_name||x.username)+(x.verified?' ✓ Verified':'')+(x.terminated?' (Terminated)':(x.banned?' (Banned)':''))+'</option>').join('');if(current&&pickerAccounts.some(x=>String(x.user_id)===String(current)))usernameSelect.value=current;}
      const actualUsernameSelect=q('adminPlayerUsernameTarget');
      if(actualUsernameSelect){const current=actualUsernameSelect.value;actualUsernameSelect.innerHTML='<option value="">Select a GBlocks player account…</option>'+pickerAccounts.map(x=>'<option value="'+esc(x.user_id)+'">@'+esc(x.username)+' — '+esc(x.display_name||x.username)+(x.verified?' ✓ Verified':'')+(x.terminated?' (Terminated)':(x.banned?' (Banned)':''))+'</option>').join('');if(current&&pickerAccounts.some(x=>String(x.user_id)===String(current)))actualUsernameSelect.value=current;}
      const banSelect=q('banUser');
      if(banSelect){const current=banSelect.value;banSelect.innerHTML='<option value="">Select a Gblocks player account…</option>'+accounts.map(x=>'<option value="'+esc(x.user_id)+'">@'+esc(x.username)+' — '+esc(x.display_name||x.username)+(x.terminated?' (Terminated)':(x.banned?' (Banned)':''))+'</option>').join('');if(current&&accounts.some(x=>String(x.user_id)===String(current)))banSelect.value=current;}
      // Bio moderation is independent of the player selectors; do not block account pickers on it.
      void loadAnnouncer().catch(()=>{});
      void loadBioModeration().catch(()=>{});
      return d;
    }catch(e){
      showAdmin(false);
      const box=q('accounts');if(box)box.innerHTML='<div class="danger">Unable to load accounts: '+esc(e.message||'Unknown error')+'</div>';
      const top=q('topStatus');if(top){top.textContent=e.message||'Administrator sign-in required.';top.className='status danger'}
      return null;
    }
  }
  async function adminLogin(){try{const username=q('adminLoginUsername')?.value.trim();const password=q('adminLoginPassword')?.value||'';if(!username||!password)throw new Error('Enter your administrator username and password.');const d=await call('/admin/email-login',{action:'login',username,password});if(!d.user?.username||d.user.role!=='administrator')throw new Error('Administrator login failed.');const status=await load();if(!status)throw new Error('Administrator session could not be loaded.');msg('adminLoginStatus','Signed in as '+d.user.username+'.',true);if(q('adminLoginPassword'))q('adminLoginPassword').value=''}catch(e){msg('adminLoginStatus',e.message)}}
  async function createAdminFromLogin(){const btn=document.querySelector('[data-create-admin-login]');try{const username=q('newAdminUserLogin')?.value.trim()||'';const password=q('newAdminPassLogin')?.value||'';if(!username)return msg('createLoginStatus','Enter an administrator username.');if(password.length<8)return msg('createLoginStatus','Administrator password must be at least 8 characters.');if(btn)btn.disabled=true;msg('createLoginStatus','Authorizing administrator creation…');const d=await call('/admin/create-administrator',{username,password});msg('createLoginStatus',d.message||'Administrator created successfully.',true);q('newAdminUserLogin').value='';q('newAdminPassLogin').value=''}catch(e){msg('createLoginStatus',e.message||'Administrator creation failed.')}finally{if(btn)btn.disabled=false}}
  async function setupAdminEmail(){try{const d=await call('/admin/email-login',{action:'setup',email:q('adminEmailSetupEmail')?.value.trim(),password:q('adminEmailSetupPassword')?.value||''});msg('adminEmailSetupStatus',d.message+' You can now use this email login after signing out.',true);if(q('adminEmailSetupPassword'))q('adminEmailSetupPassword').value=''}catch(e){msg('adminEmailSetupStatus',e.message)}}
  async function manage(action){try{const username=q('roleUser')?.value.trim();if(!username)return msg('roleStatus','Enter the GBlocks player username.');const d=await call('/admin/manage',{username,action});msg('roleStatus','Updated GBlocks player '+d.username+'. Role: '+d.role+(d.creator_role?' • Creator: '+d.creator_role:''),true);await load()}catch(e){msg('roleStatus',e.message)}}
  async function moderateUser(){const action=q('banAction')?.value;const targetUserId=q('banUser')?.value;const label=q('banUser')?.selectedOptions?.[0]?.textContent||'';if(!targetUserId)return msg('banStatus','Select a GBlocks player account.');const starts=q('banStartsAt')?.value||'';const ends=q('banEndsAt')?.value||'';const days=Number(q('banDurationDays')?.value||3);if(action==='terminated'&&!confirm('TERMINATE '+label+(starts?' at the scheduled time':'')+'? The GBlocks account will be locked and its username reset.'))return;if(action==='banned'&&!confirm((starts?'Schedule ban for ':'Ban ')+label+'?'))return;try{const payload={target_user_id:targetUserId,action,ban_note:q('banReason')?.value.trim()||'',reason:q('banReason')?.value.trim()||'',moderator_note:q('banModeratorNote')?.value.trim()||'',duration_days:days};if(starts)payload.starts_at=new Date(starts).toISOString();if(ends)payload.ends_at=new Date(ends).toISOString();const d=await call('/admin/ban',payload);msg('banStatus',d.message||'Action applied.',true);if(q('banStartsAt'))q('banStartsAt').value='';if(q('banEndsAt'))q('banEndsAt').value='';await load()}catch(e){msg('banStatus',e.message)}}
  async function changeJoinDate(){try{const username=q('joinDateUser').value.trim();const joinDate=q('joinDateValue').value;if(!username||!joinDate)return msg('joinDateStatus','Enter a username and join date.');if(!confirm('Change the join date for '+username+'?'))return;const d=await call('/admin/change-join-date',{username,joinDate});msg('joinDateStatus','Join date changed for @'+d.username+'.',true);load()}catch(e){msg('joinDateStatus',e.message)}}
async function adminChangeUsername(){try{const currentUserId=q('adminUsernameCurrent')?.value.trim()||'';const selected=q('adminUsernameCurrent')?.selectedOptions?.[0]?.textContent||'';const newDisplayName=q('adminUsernameNew')?.value.trim()||'';if(!currentUserId)return msg('adminUsernameStatus','Select a GBlocks player account.');if(!newDisplayName)return msg('adminUsernameStatus','Enter the new display name.');if(newDisplayName.length>60)return msg('adminUsernameStatus','Display names must be 60 characters or fewer.');if(!confirm('Change the display name for '+selected.replace(/^@/,'').split(' — ')[0]+' to '+newDisplayName+'? The @username will stay the same.'))return;const d=await call('/admin/change-username',{currentUserId,newDisplayName});msg('adminUsernameStatus',d.message||('Changed display name to '+d.newDisplayName+'.'),true);q('adminUsernameCurrent').value='';q('adminUsernameNew').value='';await load()}catch(e){msg('adminUsernameStatus',e.message)}}
  async function adminChangePlayerUsername(){try{const currentUserId=q('adminPlayerUsernameTarget')?.value.trim()||'';const selected=q('adminPlayerUsernameTarget')?.selectedOptions?.[0]?.textContent||'';const newUsername=q('adminPlayerUsernameNew')?.value.trim()||'';if(!currentUserId)return msg('adminPlayerUsernameStatus','Select a GBlocks player account.');if(!newUsername)return msg('adminPlayerUsernameStatus','Enter the new username.');if(!/^[A-Za-z0-9_]{3,24}$/.test(newUsername))return msg('adminPlayerUsernameStatus','Username must be 3–24 characters using letters, numbers, or underscores.');if(!confirm('Change the actual @username for '+selected+' to @'+newUsername+'? The display name, account ID, balances, inventory, ownership, badges, followers, sessions, and moderation records will remain unchanged. If the username is already used or reserved for another account, the request will be rejected without changing either account.'))return;const d=await call('/admin/change-player-username',{currentUserId,newUsername});msg('adminPlayerUsernameStatus',d.message||('Changed username to @'+d.newUsername+'.'),true);q('adminPlayerUsernameTarget').value='';q('adminPlayerUsernameNew').value='';await load()}catch(e){msg('adminPlayerUsernameStatus',e.message)}}
  async function resetUsername(){const u=q('usernameResetCurrent')?.value.trim();if(!u)return msg('usernameResetStatus','Enter the current username.');if(!confirm('Reset '+u+'? A new username will be generated automatically.'))return;q('usernameResetButton').disabled=true;try{const d=await call('/admin/username-reset',{username:u,allAccounts:false});msg('usernameResetStatus','Changed '+d.oldUsername+' to '+d.newUsername+'. Previous usernames remain reserved.',true);q('usernameResetCurrent').value='';await load()}catch(e){msg('usernameResetStatus',e.message)}finally{q('usernameResetButton').disabled=false}}
  async function resetAllUsernames(){if(!confirm('Reset the usernames of ALL OTHER GBLOCKS accounts? Your administrator account will be excluded.'))return;q('usernameResetAllButton').disabled=true;try{const d=await call('/admin/username-reset',{allAccounts:true});msg('usernameResetStatus','Reset '+d.resetCount+' other account(s). Your username stayed '+d.excludedUsername+'.',true);await load()}catch(e){msg('usernameResetStatus',e.message)}finally{q('usernameResetAllButton').disabled=false}}
  async function createAdmin(){try{const username=q('newAdminUser')?.value.trim()||'';const password=q('newAdminPass')?.value||'';if(!username)return msg('createStatus','Enter an administrator username.');if(password.length<8)return msg('createStatus','Administrator password must be at least 8 characters.');msg('createStatus','Creating administrator account…');const d=await call('/admin/create-administrator',{username,password});msg('createStatus',d.message||'Administrator created successfully.',true);if(q('newAdminUser'))q('newAdminUser').value='';if(q('newAdminPass'))q('newAdminPass').value='';await load()}catch(e){msg('createStatus',e.message||'Administrator creation failed.')}}
  async function addFollowers(){try{const username=q('followersUser')?.value.trim()||'';const amount=Number(q('followersAmount')?.value);if(!username)return msg('followersStatus','Enter a username.');if(!Number.isSafeInteger(amount)||amount<1)return msg('followersStatus','Enter a whole follower amount of at least 1.');const d=await call('/admin/followers-grant',{username,amount});msg('followersStatus','Added '+d.added+' followers to '+d.username+'. New follower count bonus: '+d.followerBonus+'.',true);if(q('followersAmount'))q('followersAmount').value='';}catch(e){msg('followersStatus',e.message)}}
  async function gobux(){try{const infinite=!!q('gobuxInfinite')?.checked;const d=await call('/admin/gobux-grant',{username:q('gobuxUser')?.value.trim(),amount:Number(q('gobuxAmount')?.value),infinite});msg('gobuxStatus',d.infinite?'Set '+d.username+' to ∞ Infinite Gobux.':'Granted '+d.granted+' Gobux to '+d.username+'.',true);await load()}catch(e){msg('gobuxStatus',e.message)}}
  async function premiumGift(){try{const username=q('premiumUser')?.value.trim()||'';const plan=q('premiumPlan')?.value||'';if(!username)return msg('premiumStatus','Enter a Gblocks username.');const d=await call('/admin/premium-gift',{username,plan});msg('premiumStatus',d.message||('Premium gifted: '+Number(d.weeklyAmount||0).toLocaleString()+' Gobux/week.'),true);await load()}catch(e){msg('premiumStatus',e.message)}}
  async function verifiedGroup(v){
    const input=q('verifyGroup');
    const status='verifyGroupStatus';
    const value=input?.value.trim()||'';
    if(!value)return msg(status,'Enter the community ID or exact community name.');
    const buttons=input?.parentElement?.parentElement?.querySelectorAll('button')||[];
    buttons.forEach(b=>b.disabled=true);
    msg(status,v?'Saving verification…':'Removing verification…');
    try{
      const isId=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
      const d=await call('/admin/group-verify',isId?{id:value,verified:v}:{name:value,verified:v});
      if(d.verified!==v)throw new Error('The server did not return the requested verification state.');
      msg(status,d.message||('Community '+(v?'verified.':'verification removed.')),true);
    }catch(e){msg(status,e.message||'Community verification failed.');}
    finally{buttons.forEach(b=>b.disabled=false);}
  }
  async function loadRestrictedAdminPlayers(){try{const sel=q('restrictedAdminBadgeUser'),list=q('restrictedAdminBadgeList');if(!sel)return;const sr=await fetch(api+'/admin/status',{cache:'no-store',credentials:'same-origin'});let sd={};try{sd=await sr.json()}catch{}if(!sr.ok)throw new Error(sd.error||('Admin status returned HTTP '+sr.status+'.'));const accounts=Array.isArray(sd.accounts)?sd.accounts:[];const current=sel.value;sel.innerHTML='<option value="">Select a Gblocks player account…</option>'+accounts.map(a=>'<option value="'+esc(a.username)+'">@'+esc(a.username)+' — '+esc(a.display_name||a.username)+(a.terminated?' (Terminated)':(a.banned?' (Banned)':''))+'</option>').join('');if(current&&accounts.some(a=>a.username===current))sel.value=current;const br=await fetch(api+'/admin/restricted-admin-badge',{cache:'no-store',credentials:'same-origin'});let bd={};try{bd=await br.json()}catch{}if(!br.ok)throw new Error(bd.error||('Restricted Admin badge list returned HTTP '+br.status+'.'));const badges=Array.isArray(bd.badges)?bd.badges:[];if(list)list.innerHTML=badges.length?'<table><thead><tr><th>Badge</th><th>Username</th><th>Applied By</th><th>Applied</th></tr></thead><tbody>'+badges.map(b=>'<tr><td><img class="badge-icon" src="/badges/restricted-admin.svg?v=464" alt="Restricted Admin"> Restricted Admin</td><td>@'+esc(b.username)+'</td><td>'+esc(b.applied_by||'Administrator')+'</td><td>'+esc(b.applied_at?new Date(b.applied_at).toLocaleString():'—')+'</td></tr>').join('')+'</tbody></table>':'<div class="muted">No Restricted Admin badges have been applied yet.</div>';}catch(e){const sel=q('restrictedAdminBadgeUser'),list=q('restrictedAdminBadgeList');if(sel&&sel.options.length<=1)sel.innerHTML='<option value="">Unable to load players — refresh</option>';if(list)list.innerHTML='<div class="danger">Unable to load Restricted Admin badge holders — refresh.</div>';console.error('Restricted Admin player load failed',e)}}
  async function applyRestrictedAdminBadge(){try{const username=q('restrictedAdminBadgeUser')?.value.trim()||'';if(!username)return msg('restrictedAdminBadgeStatus','Select a Gblocks player account.');const d=await call('/admin/restricted-admin-badge',{username});msg('restrictedAdminBadgeStatus',d.message||('Restricted Admin ⚠️ applied permanently to '+(d.username||username)+'.'),true);await load();await loadRestrictedAdminPlayers()}catch(e){msg('restrictedAdminBadgeStatus',e.message)}}
  async function verified(v){try{const d=await call('/admin/set-verified',{username:q('verifyUser')?.value.trim(),verified:v});msg('verifyStatus',(v?'Verified ':'Removed verification for ')+(d.username||q('verifyUser')?.value.trim()),true);await load()}catch(e){msg('verifyStatus',e.message)}}
  async function setPassword(){try{const d=await call('/admin/set-password',{username:q('passUser')?.value.trim(),password:q('passValue')?.value||''});msg('passStatus',d.message||'Password updated.',true);if(q('passValue'))q('passValue').value=''}catch(e){msg('passStatus',e.message)}}
  async function deleteAccount(){const u=q('deleteUser')?.value.trim();const reason=q('deleteReason')?.value.trim();if(!u)return;if(!reason)return msg('deleteStatus','A documented moderation reason is required for permanent deletion.');if(!confirm('PERMANENTLY DELETE '+u+'? This cannot be undone.'))return;try{const d=await call('/admin/reset-user',{username:u,confirmation:u,reason});msg('deleteStatus',d.message||'Account deleted.',true);q('deleteUser').value='';await load()}catch(e){msg('deleteStatus',e.message)}}
  async function maintenanceStatus(){try{const r=await fetch(api+'/maintenance/status',{credentials:'same-origin'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Maintenance status failed.');msg('maintStatus',JSON.stringify(d),true)}catch(e){msg('maintStatus',e.message)}}
  async function repair(){try{const r=await fetch(api+'/maintenance/repair',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:'{}'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Repair failed.');msg('maintStatus',d.message||'Maintenance repair completed.',true);await load()}catch(e){msg('maintStatus',e.message)}}
  async function resetAccounts(){const c=q('resetAccountsConfirmation')?.value||'';if(c!=='RESET ALL GBLOCKS ACCOUNTS')return msg('resetAllStatus','Type exactly: RESET ALL GBLOCKS ACCOUNTS');if(!confirm('RESET ALL GBLOCKS ACCOUNTS? This is destructive and cannot be undone.'))return;try{const d=await call('/admin/reset-accounts',{confirmation:c});msg('resetAllStatus','Deleted '+d.deleted.accounts+' other account(s). Your administrator account stayed.',true);q('resetAccountsConfirmation').value='';await load()}catch(e){msg('resetAllStatus',e.message)}}
  async function previewViolationChecker(){
    try{
      const d=await call('/admin/violation-checker',{dry_run:true});
      const items=Array.isArray(d.flagged)?d.flagged:[];
      msg('violationCheckerStatus','Scanned '+d.scanned+' player account(s): '+items.length+' explicit match(es). '+(items.length?items.map(x=>'@'+x.oldUsername+' ('+x.reasons.join(', ')+')').join(' • '):'No matching accounts.'),true);
    }catch(e){msg('violationCheckerStatus',e.message)}
  }
  async function runViolationChecker(){
    const btn=q('violationScanButton');
    if(!confirm('Scan all GBlocks player accounts and reset confirmed matches?'))return;
    if(btn)btn.disabled=true;
    msg('violationCheckerStatus','Scanning GBlocks player accounts…');
    try{
      const d=await call('/admin/violation-checker',{dry_run:false});
      const items=Array.isArray(d.results)?d.results:[];
      msg('violationCheckerStatus','Scanned '+d.scanned+' player account(s). Reset '+d.resetCount+' confirmed match(es).'+(items.length?' '+items.map(x=>'@'+x.oldUsername+' → @'+x.newUsername).join(' • '):''),true);
      await load();
    }catch(e){msg('violationCheckerStatus',e.message)}
    finally{if(btn)btn.disabled=false}
  }
  async function loadAppeals(){const box=q('appealsList');if(!box)return;try{const r=await fetch(api+'/admin/appeals',{method:'GET',credentials:'same-origin',cache:'no-store'});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||'Could not load appeals.');const a=Array.isArray(d.appeals)?d.appeals:[];msg('appealsStatus',a.length+' appeal(s) loaded.',true);if(!a.length){box.innerHTML='<div class="muted">No appeals submitted.</div>';return;}box.innerHTML='<table><thead><tr><th>User</th><th>Moderation reason</th><th>Appeal</th><th>Status</th><th>Decision</th><th>Submitted</th><th>Actions</th></tr></thead><tbody>'+a.map(x=>'<tr><td>@'+esc(x.username)+'</td><td style="white-space:normal;min-width:180px">'+esc(x.ban_reason||'')+'</td><td style="white-space:normal;min-width:260px">'+esc(x.appeal_text||'')+'</td><td><span class="pill">'+esc(x.status)+'</span></td><td>'+esc(x.decision||'—')+'</td><td>'+esc(x.created_at||'')+'</td><td>'+(x.status==='pending'||x.status==='escalation_required'?'<button class="green" onclick="decideAppeal('+Number(x.id)+',\'approved\')">Accept</button> <button class="red" onclick="decideAppeal('+Number(x.id)+',\'denied\')">Deny</button> <button class="gray" onclick="decideAppeal('+Number(x.id)+',\'closed\')">Close</button> <button class="red" onclick="decideAppeal('+Number(x.id)+',\'permanent_remove\')">Permanently Remove Account</button>':'<span class="muted">'+esc(x.reviewed_by||'Reviewed')+'</span>')+'</td></tr>').join('')+'</tbody></table>';}catch(e){msg('appealsStatus',e.message||'Could not load appeals.')}}
  async function decideAppeal(id,decision){const label=decision==='approved'?'Accept':decision==='denied'?'Deny':decision==='closed'?'Close':'Permanently Remove Account';if(!confirm(label+' this appeal'+(decision==='permanent_remove'?' and permanently delete the account':'')+'?'))return;try{const d=await call('/admin/appeals',{method:'POST',body:{id,decision}});msg('appealsStatus','Appeal '+id+' '+(d.decision||decision)+'.',true);await loadAppeals();await load()}catch(e){msg('appealsStatus',e.message||'Could not update appeal.')}}
  async function runModerationChecker(){
    const input=q('moderationCheckerTarget');
    const box=q('moderationCheckerResults');
    const target=input?.value.trim()||'';
    if(!target)return msg('moderationCheckerStatus','Enter a permanent user ID or username.');
    if(box)box.innerHTML='<div class="muted">Loading moderation records…</div>';
    try{
      const r=await fetch(api+'/admin/moderation-checker?'+(target.length>24||target.includes('-')?'user_id=':'username=')+encodeURIComponent(target),{cache:'no-store',credentials:'same-origin'});
      const d=await r.json();
      if(!r.ok)throw new Error(d.error||'Could not load moderation records.');
      const p=d.profile||{},activity=Array.isArray(d.activity)?d.activity:[],bios=Array.isArray(d.moderation_history)?d.moderation_history:[],names=Array.isArray(d.username_history)?d.username_history:[];
      msg('moderationCheckerStatus','Loaded records for @'+(p.username||target)+'.',true);
      if(!box)return;
      box.innerHTML='<div class="notice"><h3>'+esc(p.display_name||p.username)+' '+(p.restricted_admin_badge?'<img class="badge-icon" src="/badges/restricted-admin.svg?v=464" alt="Restricted Admin">':(String(p.role||'').toLowerCase()==='administrator'?'<img class="badge-icon" src="/badges/admin.svg?v=464" alt="Admin">':''))+(p.creator_role==='creator'?'<span class="creator-badge">Creator</span>':p.creator_role==='creator_alt'?'<span class="creator-alt-badge">Creator Alt</span>':'')+(p.verified?'<img class="badge-icon" src="/badges/verified.svg?v=464" alt="Verified">':'')+(p.premium?'<img class="badge-icon" src="/badges/premium.svg?v=464" alt="Premium">':'')+' (@'+esc(p.username)+')</h3><p><b>Permanent User ID:</b> <code>'+esc(p.user_id)+'</code> · <b>User #:</b> '+esc(p.user_number??'—')+'</p><p><b>Current bio:</b> '+esc(p.bio||'(empty)')+'</p><p><b>Account status:</b> '+esc(p.terminated?'Terminated':p.banned?'Banned':'Active')+' · <b>Bio status:</b> '+esc(p.bio_moderation_status||'not_reviewed')+'</p><p><b>Created:</b> '+esc(p.created_at||'unknown')+' · <b>Last seen:</b> '+esc(p.last_seen_at||'unknown')+'</p><h3>Recorded Activity / Audit Events ('+activity.length+')</h3>'+(activity.length?'<table><thead><tr><th>Action</th><th>Actor</th><th>Reason</th><th>Time</th></tr></thead><tbody>'+activity.map(x=>'<tr><td>'+esc(x.action==='TEMP_BAN'&&Number(x.details?.durationMinutes)>0?('TEMP_BAN ('+Number(x.details.durationMinutes)+' minutes)'):x.action)+'</td><td>'+esc(String(x.actor_username||'System').toLowerCase()==='001 system'?'001System':(x.actor_username||'System'))+'</td><td style="white-space:normal">'+esc(x.reason||'')+'</td><td>'+esc(x.created_at||'')+'</td></tr>').join('')+'</tbody></table>':'<p>No recorded audit events.</p>')+'<h3>Bio Moderation History ('+bios.length+')</h3>'+(bios.length?'<table><thead><tr><th>Action</th><th>Original Bio</th><th>Result</th><th>Moderator</th><th>Reason / Time</th></tr></thead><tbody>'+bios.map(x=>'<tr><td>'+esc(x.action)+'</td><td style="white-space:normal">'+esc(x.original_bio||'')+'</td><td style="white-space:normal">'+esc(x.resulting_bio||'')+'</td><td>'+esc(x.actor_admin_username||'System')+'</td><td style="white-space:normal">'+esc(x.reason||'')+'<br>'+esc(x.created_at||'')+'</td></tr>').join('')+'</tbody></table>':'<p>No bio moderation history.</p>')+'<h3>Previous Usernames ('+names.length+')</h3>'+(names.length?'<p>'+names.map(x=>esc(x.username)+' ('+esc(x.changed_at||'unknown date')+')').join('<br>')+'</p>':'<p>No previous usernames recorded.</p>')+'<p class="muted">'+esc(d.activity_note||'Only recorded events are shown; this is not a full page-view history.')+'</p></div>';
    }catch(e){msg('moderationCheckerStatus',e.message||'Could not load moderation records.');if(box)box.innerHTML='<div class="danger">Could not load records.</div>'}
  }
  async function checkAllPlayerBios(){
    const btn=q('bioModerationCheckAllButton');
    if(!confirm('Check all GBlocks player bios using the server-side bio moderation rules?'))return;
    if(btn)btn.disabled=true;
    msg('bioModerationStatus','Checking all GBlocks player bios…');
    try{
      const d=await call('/admin/bio-moderation',{action:'check_all_players'});
      msg('bioModerationStatus','Checked '+d.scanned+' player bio(s). Reviewed '+d.reviewed+' and replaced '+d.deleted+' violating bio(s) with [Content Deleted].',true);
      await loadBioModeration();
    }catch(e){msg('bioModerationStatus',e.message)}
    finally{if(btn)btn.disabled=false}
  }
  async function loadBioModeration(){
    const box=q('bioModerationList');
    if(!box)return;
    try{
      const search=encodeURIComponent(q('bioModerationSearch')?.value.trim()||'');
      const status=encodeURIComponent(q('bioModerationFilter')?.value||'all');
      const r=await fetch(api+'/admin/bio-moderation?status='+status+'&search='+search,{cache:'no-store',credentials:'same-origin'});
      const d=await r.json();
      if(!r.ok)throw new Error(d.error||'Bio moderation list failed.');
      const bios=Array.isArray(d.bios)?d.bios:[];
      if(!bios.length){box.innerHTML='<div class="muted">No bios match this filter.</div>';return;}
      box.innerHTML='<table><thead><tr><th>User ID</th><th>Username</th><th>Bio</th><th>Status</th><th>Last Moderation</th><th>Actions</th></tr></thead><tbody>'+bios.map(b=>'<tr><td>'+esc(b.user_id)+'</td><td>@'+esc(b.username)+'</td><td style="white-space:normal;min-width:240px">'+esc(b.bio||'')+'</td><td><span class="pill">'+esc(b.moderation_status)+'</span></td><td>'+esc(b.last_moderation_time||'Never')+'</td><td><button class="gray" onclick="openBioModeration(\''+esc(b.user_id)+'\')">Open</button> <button onclick="bioModerationAction(\''+esc(b.user_id)+'\',\'mark_reviewed\')">Mark Reviewed</button> <button class="red" onclick="bioModerationAction(\''+esc(b.user_id)+'\',\'delete\')">Delete Bio</button> <button class="green" onclick="bioModerationAction(\''+esc(b.user_id)+'\',\'restore\')">Restore</button></td></tr>').join('')+'</tbody></table><div id="bioModerationDetails" style="margin-top:14px"></div>';
    }catch(e){msg('bioModerationStatus',e.message)}
  }
  async function openBioModeration(userId){
    try{
      const r=await fetch(api+'/admin/bio-moderation-history?user_id='+encodeURIComponent(userId),{cache:'no-store',credentials:'same-origin'});
      const d=await r.json();
      if(!r.ok)throw new Error(d.error||'Bio history failed.');
      const history=Array.isArray(d.history)?d.history:[];
      const details=q('bioModerationDetails');
      if(!details)return;
      details.innerHTML='<div class="notice"><b>Moderation history for '+esc(userId)+'</b>'+(history.length?'<div class="table" style="margin-top:10px"><table><thead><tr><th>Action</th><th>Previous Bio</th><th>Resulting Bio</th><th>Admin</th><th>Reason</th><th>Time</th></tr></thead><tbody>'+history.map(h=>'<tr><td>'+esc(h.action)+'</td><td style="white-space:normal;min-width:220px">'+esc(h.original_bio||'')+'</td><td style="white-space:normal;min-width:220px">'+esc(h.resulting_bio||'')+'</td><td>'+esc(h.actor_admin_username||'Automatic')+'</td><td style="white-space:normal">'+esc(h.reason||'')+'</td><td>'+esc(h.created_at||'')+'</td></tr>').join('')+'</tbody></table></div>':'<p class="muted">No moderation history yet.</p>')+'</div>';
    }catch(e){msg('bioModerationStatus',e.message)}
  }
  async function bioModerationAction(userId,action){
    if(action==='delete'&&!confirm('Delete this bio and replace it with [Content Deleted]?'))return;
    if(action==='restore'&&!confirm('Explicitly restore the most recent previously deleted bio?'))return;
    try{
      const reason=action==='delete'?(prompt('Optional moderation reason:')||'Admin deleted bio.'):'';
      const d=await call('/admin/bio-moderation',{user_id:userId,action,reason});
      msg('bioModerationStatus',d.message||('Bio action '+action+' completed.'),true);
      await loadBioModeration();
      await openBioModeration(userId);
    }catch(e){msg('bioModerationStatus',e.message)}
  }
  function initPlayerPickers(){
    // Keep the Restricted Admin selector native on mobile. The custom fixed-position picker can swallow its populated options on Android.
    const ids=['roleUser','banUser','followersUser','gobuxUser','premiumUser','verifyUser','joinDateUser','adminUsernameCurrent','adminPlayerUsernameTarget','passUser','usernameResetCurrent','deleteUser'];
    ids.forEach(id=>{
      const sel=q(id);
      if(!sel||sel.dataset.customPicker==='1')return;
      sel.dataset.customPicker='1';
      const wrap=document.createElement('div');wrap.className='gblocks-picker';
      const button=document.createElement('button');button.type='button';button.className='gblocks-picker-button';
      const pop=document.createElement('div');pop.className='gblocks-picker-popover';
      const search=document.createElement('input');search.type='search';search.className='gblocks-picker-search';search.placeholder='Search players…';search.autocomplete='off';
      const list=document.createElement('div');list.className='gblocks-picker-list';
      sel.parentNode.insertBefore(wrap,sel);wrap.append(sel,button);pop.append(search,list);document.body.appendChild(pop);wrap._pickerPopover=pop;pop._pickerWrap=wrap;pop.style.display='none';
      sel.classList.add('gblocks-picker-native');
      const close=()=>{wrap.classList.remove('open');button.setAttribute('aria-expanded','false');pop.style.display='none'};
      const closeOthers=()=>document.querySelectorAll('.gblocks-picker.open').forEach(x=>{if(x!==wrap){x.classList.remove('open');x._pickerPopover&&(x._pickerPopover.style.display='none')}});
      const sync=()=>{const o=sel.options[sel.selectedIndex];button.textContent=o&&o.value?o.textContent:'Select a Gblocks player account…';};
      const render=()=>{
        const term=search.value.trim().toLowerCase();list.innerHTML='';
        Array.from(sel.options).forEach((o,i)=>{
          if(i&&term&&!o.textContent.toLowerCase().includes(term))return;
          const b=document.createElement('button');b.type='button';b.className='gblocks-picker-option'+(o.value===sel.value?' selected':'');b.textContent=o.textContent;
          b.onclick=()=>{sel.value=o.value;sel.dispatchEvent(new Event('change',{bubbles:true}));sync();close()};
          list.appendChild(b);
        });
        if(!list.children.length){const empty=document.createElement('div');empty.className='gblocks-picker-empty';empty.textContent='No matching players';list.appendChild(empty)}
      };
      button.onclick=()=>{const open=!wrap.classList.contains('open');closeOthers();wrap.classList.toggle('open',open);button.setAttribute('aria-expanded',String(open));pop.style.display=open?'block':'none';if(open){search.value='';render();requestAnimationFrame(()=>{const r=button.getBoundingClientRect();const w=pop.offsetWidth;const h=Math.min(pop.offsetHeight,window.innerHeight*.42);const left=Math.max(12,Math.min(r.left,window.innerWidth-w-12));const top=(r.bottom+h+8<=window.innerHeight)?r.bottom+6:Math.max(12,r.top-h-6);pop.style.left=left+'px';pop.style.top=top+'px';search.focus()})}};
      search.oninput=render;
      // Let Android/WebView handle the list as a normal native vertical touch scroller.
      // The popover and list both use touch-action: pan-y in admin.html.
      sel.addEventListener('change',sync);
      new MutationObserver(()=>{sync();render()}).observe(sel,{childList:true});
      sync();render();
    });
  }
  document.addEventListener('click',e=>{if(!e.target.closest('.gblocks-picker')&&!e.target.closest('.gblocks-picker-popover'))document.querySelectorAll('.gblocks-picker.open').forEach(x=>{x.classList.remove('open');if(x._pickerPopover)x._pickerPopover.style.display='none';})});
  window.addEventListener('resize',()=>document.querySelectorAll('.gblocks-picker.open').forEach(wrap=>{const button=wrap.querySelector('.gblocks-picker-button');const pop=wrap._pickerPopover;if(!button||!pop)return;const r=button.getBoundingClientRect();const w=pop.offsetWidth;const h=pop.offsetHeight;pop.style.left=Math.max(12,Math.min(r.left,window.innerWidth-w-12))+'px';pop.style.top=(r.bottom+h+8<=window.innerHeight?r.bottom+6:Math.max(12,r.top-h-6))+'px'}));
  initPlayerPickers();
  void loadRestrictedAdminPlayers();
  Object.assign(window,{load,loadRestrictedAdminPlayers,loadAnnouncer,publishAnnouncement,removeAnnouncement,grant257Achievement,loadAppeals,decideAppeal,adminLogin,createAdminFromLogin,setupAdminEmail,manage,moderateUser,adminChangeUsername,adminChangePlayerUsername,resetUsername,resetAllUsernames,createAdmin,addFollowers,gobux,premiumGift,applyRestrictedAdminBadge,verified,verifiedGroup,setPassword,deleteAccount,maintenanceStatus,repair,resetAccounts,previewViolationChecker,runViolationChecker,checkAllPlayerBios,loadBioModeration,openBioModeration,bioModerationAction,runModerationChecker,accountsGoFirst,accountsGoPrev,accountsGoNext,accountsGoLast,grobloxReloadAccounts:load});
  const verifyBtn=q('verifyGroupButton');
  const removeVerifyBtn=q('removeVerifyGroupButton');
  if(verifyBtn)verifyBtn.addEventListener('click',()=>verifiedGroup(true));
  if(removeVerifyBtn)removeVerifyBtn.addEventListener('click',()=>verifiedGroup(false));
  const joinDateButton=q('changeJoinDateButton');
  if(joinDateButton)joinDateButton.addEventListener('click',changeJoinDate);
  const refresh=q('refresh');if(refresh)refresh.onclick=load;
  load();
})();