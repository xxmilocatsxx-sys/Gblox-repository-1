(()=>{
if(window.__adminContentReady)init();else window.addEventListener('admin-content-ready',init,{once:true});
function init(){
 const $=id=>document.getElementById(id), list=$('avatarPlayers');
 if(!list)return;
 let players=[],selected=null,uploaded='',requestNo=0,searchTimer=null;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const defaultImg='/avatar-default.svg';
 const img=p=>String(p?.avatar?.image_url||defaultImg);
 function preview(src){const el=$('avatarPreview');if(el)el.innerHTML='<img src="'+esc(src||defaultImg)+'" alt="Avatar preview" style="width:100%;height:100%;object-fit:cover" onerror="this.onerror=null;this.src=\'/avatar-default.svg\'">'}
 function render(){
  list.innerHTML=players.map(p=>'<button type="button" class="avplayer '+(selected&&String(selected.user_id)===String(p.user_id)?'selected':'')+'" data-id="'+esc(p.user_id)+'"><img src="'+esc(img(p))+'" alt="" onerror="this.onerror=null;this.src=\'/avatar-default.svg\'"><span><b>'+esc(p.display_name||p.username)+'</b><br><span class="avmuted">@'+esc(p.username)+' · User #'+esc(p.user_number)+'</span></span></button>').join('')||'<p class="avmuted">No players found. Check the username and try again.</p>';
  list.querySelectorAll('.avplayer').forEach(b=>b.onclick=()=>{
   selected=players.find(p=>String(p.user_id)===b.dataset.id);uploaded='';
   $('avatarUrl').value=String(selected?.avatar?.image_url||'');$('avatarFile').value='';
   $('avatarSelected').textContent=selected?(selected.display_name||selected.username)+' (@'+selected.username+')':'Select a player';
   preview(img(selected));render();
  });
 }
 async function load(q=''){
  const thisRequest=++requestNo;
  list.textContent=q?'Searching usernames…':'Loading player accounts…';
  try{
   // Use the same authenticated player directory as Gobux, verification, and admin-role tools.
   const r=await fetch('/api/admin/status',{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}});
   const d=await r.json().catch(()=>({}));
   if(thisRequest!==requestNo)return;
   if(!r.ok)throw Error(d.error||'Could not load the GBlocks player directory (HTTP '+r.status+').');
   const all=Array.isArray(d.accounts)?d.accounts:[];
   const term=q.trim().toLocaleLowerCase();
   players=all.filter(p=>!term||String(p.username||'').toLocaleLowerCase().includes(term)||String(p.display_name||'').toLocaleLowerCase().includes(term))
    .sort((a,b)=>Number(a.user_number||0)-Number(b.user_number||0));
   render();
  }catch(e){
   if(thisRequest!==requestNo)return;
   list.innerHTML='<p class="avmuted">'+esc(e.message)+' <button type="button" id="avatarRetry">Retry</button></p>';
   const retry=$('avatarRetry');if(retry)retry.onclick=()=>load($('avatarSearch')?.value||'');
  }
 }
 $('avatarSearch').addEventListener('input',()=>{
  clearTimeout(searchTimer);
  const q=$('avatarSearch').value;
  searchTimer=setTimeout(()=>load(q),220);
 });
 $('avatarUrl').addEventListener('input',()=>{uploaded='';preview($('avatarUrl').value.trim()||defaultImg)});
 $('avatarFile').addEventListener('change',()=>{
  const f=$('avatarFile').files?.[0];if(!f){uploaded='';return}
  if(f.size>900*1024){$('avatarStatus').textContent='Image is too large. Maximum size is 900 KB.';$('avatarFile').value='';return}
  const rd=new FileReader();rd.onload=()=>{uploaded=String(rd.result||'');$('avatarUrl').value='';preview(uploaded)};rd.readAsDataURL(f);
 });
 async function save(image_url){
  if(!selected){$('avatarStatus').textContent='Select a player first.';return}
  const b=$('avatarSave');b.disabled=true;
  try{
   const r=await fetch('/api/admin/avatar',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:selected.user_id,image_url})});
   const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Save failed.');
   selected.avatar=d.avatar;players=players.map(p=>String(p.user_id)===String(selected.user_id)?selected:p);
   $('avatarStatus').textContent=d.message||'Avatar updated.';preview(img(selected));render();
  }catch(e){$('avatarStatus').textContent=e.message}finally{b.disabled=false}
 }
 $('avatarSave').onclick=()=>save(uploaded||$('avatarUrl').value.trim());
 $('avatarReset').onclick=()=>{if(!selected){$('avatarStatus').textContent='Select a player first.';return}uploaded='';$('avatarUrl').value='';$('avatarFile').value='';save('')};
 // Shared default-avatar manager: this asset is separate from every player's saved custom image.
 const defaultFile=$('defaultAvatarFile'),defaultPreview=$('defaultAvatarPreview'),defaultInfo=$('defaultAvatarInfo'),defaultStatus=$('defaultAvatarStatus');
 async function loadDefaultAvatar(){if(!defaultPreview)return;try{const r=await fetch('/api/admin/default-avatar',{credentials:'same-origin',cache:'no-store'});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Could not load default avatar settings.');const g=$('defaultAvatarGender')?.value||'female',item=d.avatars?.[g];defaultPreview.src=item?.url||d.fallback||'/avatar-default.svg';if(defaultInfo)defaultInfo.textContent=item?'Custom '+g+' default: '+item.filename+' · '+Math.ceil((item.bytes||0)/1024)+' KB':('Using '+(g==='default'?'the built-in general fallback':('the general fallback for '+g+' players'))+'.');}catch(e){if(defaultInfo)defaultInfo.textContent=e.message;}}
 if(defaultFile){defaultFile.addEventListener('change',()=>{const f=defaultFile.files?.[0];if(!f)return;if(f.size>900*1024){if(defaultStatus)defaultStatus.textContent='Image is too large. Maximum size is 900 KB.';defaultFile.value='';return;}const rd=new FileReader();rd.onload=()=>{if(defaultPreview)defaultPreview.src=String(rd.result||'/avatar-default.svg')};rd.readAsDataURL(f);});}
 const defaultGender=$('defaultAvatarGender');if(defaultGender)defaultGender.addEventListener('change',()=>{if(defaultFile)defaultFile.value='';if(defaultStatus)defaultStatus.textContent='';void loadDefaultAvatar();});
 const defaultSave=$('defaultAvatarSave');
 if(defaultSave)defaultSave.onclick=async()=>{const f=defaultFile?.files?.[0],gender=defaultGender?.value||'female';if(!f){if(defaultStatus)defaultStatus.textContent='Choose an image for the '+gender+' default first.';return;}defaultSave.disabled=true;if(defaultStatus)defaultStatus.textContent='Uploading '+gender+' default avatar…';try{const fd=new FormData();fd.append('file',f);fd.append('gender',gender);const r=await fetch('/api/admin/default-avatar',{method:'POST',credentials:'same-origin',body:fd});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Default avatar upload failed.');if(defaultStatus)defaultStatus.textContent=d.message||'Default avatar updated.';defaultFile.value='';await loadDefaultAvatar();}catch(e){if(defaultStatus)defaultStatus.textContent=e.message;}finally{defaultSave.disabled=false;}};
 const defaultReset=$('defaultAvatarReset');
 if(defaultReset)defaultReset.onclick=async()=>{const gender=defaultGender?.value||'female';if(!confirm('Reset the '+gender+' default avatar? Player custom avatars will not be changed.'))return;defaultReset.disabled=true;try{const r=await fetch('/api/admin/default-avatar?gender='+encodeURIComponent(gender),{method:'DELETE',credentials:'same-origin'});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Could not reset default avatar.');if(defaultStatus)defaultStatus.textContent=d.message||'Default avatar reset.';if(defaultFile)defaultFile.value='';await loadDefaultAvatar();}catch(e){if(defaultStatus)defaultStatus.textContent=e.message;}finally{defaultReset.disabled=false;}};
 void loadDefaultAvatar();
 load();
}
})();