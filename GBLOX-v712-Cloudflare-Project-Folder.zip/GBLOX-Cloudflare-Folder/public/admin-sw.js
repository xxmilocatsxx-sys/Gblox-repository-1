const CACHE = 'groblox-admin-shell-v1';
const SHELL = ['/admin.html', '/admin-manifest.webmanifest', '/admin-app.js', '/icon.svg'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname === '/admin.html' || url.pathname === '/admin-manifest.webmanifest' || url.pathname === '/admin-app.js' || url.pathname === '/icon.svg') {
    event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
  }
});