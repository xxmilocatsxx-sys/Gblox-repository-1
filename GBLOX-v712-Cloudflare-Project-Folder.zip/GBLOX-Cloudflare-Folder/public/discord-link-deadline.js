(()=>{
  if(window.__gbloxDiscordDeadlineStarted)return;
  window.__gbloxDiscordDeadlineStarted=true;
  const esc=s=>String(s??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  async function start(){
    try{
      const r=await fetch('/api/account/discord/status',{credentials:'include',cache:'no-store'});
      if(r.status===401||!r.ok)return;
      const d=await r.json();
      if(d.is_bot===true||d.discord_exempt===true||d.linked||!d.deadline_at||document.getElementById('gblox-discord-deadline-modal'))return;
      const deadline=Date.parse(d.deadline_at);
      if(!Number.isFinite(deadline))return;
      const style=document.createElement('style');
      style.textContent='#gblox-discord-deadline-modal{position:fixed;inset:0;z-index:2147483000;display:grid;place-items:center;padding:18px;background:#020817d9;backdrop-filter:blur(7px);font-family:system-ui,-apple-system,sans-serif}#gblox-discord-deadline-modal .gdd-card{width:min(100%,460px);box-sizing:border-box;padding:24px;border:1px solid #315b9c;border-radius:20px;background:linear-gradient(145deg,#0a1b38,#120f29);color:#fff;box-shadow:0 18px 70px #0009}#gblox-discord-deadline-modal h2{margin:0 0 10px;font-size:23px}#gblox-discord-deadline-modal p{color:#d3e1ff;line-height:1.55;font-size:14px}#gblox-discord-deadline-modal .gdd-count{font-size:21px;font-weight:900;color:#71c4ff;padding:13px 10px;text-align:center;border:1px solid #285ca3;border-radius:12px;background:#06152b;margin:16px 0}#gblox-discord-deadline-modal .gdd-local{font-size:12px;color:#a9bad9;text-align:center}#gblox-discord-deadline-modal .gdd-btn{display:block;width:100%;box-sizing:border-box;text-align:center;border:0;border-radius:11px;padding:13px 16px;background:linear-gradient(90deg,#1677ff,#7b45ff);color:white;font-size:15px;font-weight:900;text-decoration:none;margin-top:16px}#gblox-discord-deadline-modal .gdd-later{display:block;width:100%;border:1px solid #34496a;border-radius:10px;padding:10px;margin-top:8px;background:transparent;color:#c8d7f2;font-weight:700}';
      document.head.appendChild(style);
      const modal=document.createElement('div');modal.id='gblox-discord-deadline-modal';modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-labelledby','gdd-title');
      modal.innerHTML='<section class="gdd-card"><h2 id="gdd-title">🔗 Connect your GBLOX account</h2><p>Connect your Discord account to GBLOX before the four-day deadline. Accounts that remain unlinked may be subject to termination, and usernames may be released later under the account policy.</p><p>Your countdown is shown using your device’s local time. Everyone shares the same deadline, so changing your device clock will not extend it.</p><div class="gdd-count" id="gdd-countdown">Loading countdown…</div><div class="gdd-local" id="gdd-local"></div><a class="gdd-btn" href="/api/account/discord/start?mode=link">Connect Discord account</a><a class="gdd-btn" style="background:#17243b;border:1px solid #38547b;margin-top:8px" href="/settings.html#discordVerification">Open Discord settings</a><button class="gdd-later" id="gdd-later" type="button">Remind me later</button></section>';
      document.body.appendChild(modal);
      const update=()=>{const left=deadline-Date.now();const out=document.getElementById('gdd-countdown');if(left<=0){out.textContent='Deadline reached';}else{const s=Math.floor(left/1000),days=Math.floor(s/86400),hours=Math.floor(s%86400/3600),mins=Math.floor(s%3600/60),secs=s%60;out.textContent=`${days}d ${hours}h ${mins}m ${secs}s remaining`;}document.getElementById('gdd-local').textContent='Deadline: '+new Date(deadline).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});};
      update();const timer=setInterval(update,1000);
      document.getElementById('gdd-later').onclick=()=>{clearInterval(timer);modal.remove();};
    }catch(e){/* Account pages remain usable if status lookup is unavailable. */}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();