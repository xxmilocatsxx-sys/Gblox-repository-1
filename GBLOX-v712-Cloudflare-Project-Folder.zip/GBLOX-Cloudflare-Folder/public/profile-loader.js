(async function(){
  const box=document.getElementById('box');
  if(!box)return;
  const params=new URLSearchParams(location.search);
  const userid=params.get('userid')||params.get('userId');
  const username=params.get('username');
  if(!userid&&!username){box.innerHTML='<h1>Profile not found</h1>';return;}
  try{
    const api=(window.__HATCHABLE__&&window.__HATCHABLE__.api)||'/api';
    const q=userid?'userid='+encodeURIComponent(userid):'username='+encodeURIComponent(username);
    let r,p;
    for(let attempt=0;attempt<3;attempt++){
      r=await fetch(api+'/profile-view?'+q,{cache:'no-store',headers:{Accept:'application/json'}});
      p=await r.json().catch(()=>({}));
      if(r.status!==429)break;
      await new Promise(resolve=>setTimeout(resolve,500*(attempt+1)));
    }
    if(r.status===429){box.innerHTML='<h1>Profile is temporarily busy</h1><p class="muted">Too many requests reached the database. Please try again in a moment.</p>';return;}
    if(!r.ok||!p||p.error){box.innerHTML='<h1>Profile not found</h1><p class="muted">'+escapeHtml((p&&p.error)||'This player profile could not be found.')+'</p>';return;}
    if(p.banned||p.terminated){box.className='card profile profile-unavailable';box.innerHTML='<h1>Profile not found</h1><p class="handle">Gblocks User #'+escapeHtml(p.user_number)+'</p><p class="muted">This User Is Banned Or Terminated avatar isn\'t available</p>';return;}
    const imageUrl=String(p.avatar&&p.avatar.image_url||'');
    const a=(p.avatar&&p.avatar.custom)||p.avatar||{};
    const gender=(p.gender||a.gender)==='female'?'female':'male';
    const hair=a.hair|| (gender==='male'?'brown':'none');
    const skin=a.skin||'#f2c94c',shirt=a.shirt||'#b91c1c',pants=a.pants||'#17212b',face=a.face||'⌣';
    const restrictedAdmin=!!p.restricted_admin_badge;
    const admin=!restrictedAdmin && (p.admin||p.role==='administrator');
    const badges=(restrictedAdmin?'<span class="badge">⚠️</span>':'')+(p.discord_verified?'<span class="badge discord-verified" style="border:1px solid #5865f2;background:#20213d;color:#c8ccff">Discord Verified</span>':'')+(p.verified?'<span class="badge verified"><span class="inline-badge g-badge">☑️</span> Verified</span>':'')+(admin?'<span class="badge admin"><span class="inline-badge a-badge">🚨</span> Admin</span>':'')+(p.premium?'<span class="badge premium"><span class="inline-badge premium-badge">👑</span> '+(p.premium_plan==='500_years'?'Premium Plus':'Premium')+'</span>'+(p.premium_permanent?'<span class="badge permanent-premium" title="This Premium entitlement does not expire" style="display:inline-flex;align-items:center;margin:4px;padding:5px 9px;border:1px solid #d9b441;border-radius:999px;color:#ffe08a;background:#35290a;font-size:12px;font-weight:800">PERMANENT</span>':''):'');
    const previous=(p.previous_usernames||[]).map(x=>'<span class="previous-username">@'+escapeHtml(x.display_username||x.username)+'</span>').join('');
    const updatedUsername='<div class="handle">Updated @'+escapeHtml(p.username)+'</div>';
    const socials=p.social_accounts||{};
    const socialLabels={youtube:'YouTube',discord:'Discord',tiktok:'TikTok',instagram:'Instagram',x:'X',website:'Website'};
    const socialHtml=Object.keys(socialLabels).filter(k=>String(socials[k]||'').trim()).map(k=>'<a href="'+escapeHtml(socialUrl(k,socials[k]))+'" target="_blank" rel="noopener noreferrer">'+socialLabels[k]+'</a>').join('');
    const date=p.created_at?new Date(p.created_at).toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'}):'Unknown';
    box.className='card profile';
    box.innerHTML='<div class="ava"><div class="avatar3d">'+(hair!=='none'?'<div class="hair '+escapeHtml(gender)+' '+escapeHtml(hair)+'"></div>':'')+'<div class="head" style="background:'+escapeHtml(skin)+'"><div class="face">'+escapeHtml(face)+'</div></div><div class="arm l" style="background:'+escapeHtml(skin)+'"></div><div class="arm r" style="background:'+escapeHtml(skin)+'"></div><div class="torso" style="background:'+escapeHtml(shirt)+'"></div><div class="leg l" style="background:'+escapeHtml(pants)+'"></div><div class="leg r" style="background:'+escapeHtml(pants)+'"></div></div></div><h1>'+escapeHtml(p.display_name||p.username)+(restrictedAdmin?'<span class="inline-badge" aria-label="Restricted administrator">⚠️</span>':(admin?'<span class="inline-badge a-badge" aria-label="Admin badge">🚨</span>':''))+(p.verified?'<span class="inline-badge g-badge" aria-label="Verified badge">☑️</span>':'')+(p.discord_verified?'<span class="inline-badge" aria-label="Discord Verified" title="Discord Verified" style="color:#7280ff">◆</span>':'')+(p.premium?'<span class="inline-badge premium-badge" aria-label="Premium badge">👑</span>':'')+(p.premium_permanent?'<span class="inline-badge permanent-premium" aria-label="Permanent Premium">PERMANENT</span>':'')+'</h1><div class="handle">@'+escapeHtml(p.username)+'</div><div class="handle">Gblocks User #'+escapeHtml(p.user_number)+'</div><div class="handle profile-status '+(p.online?'online':'offline')+'">'+(p.online?'Online':'Offline')+'</div><div class="handle">Joined '+date+'</div><div class="badges">'+badges+'</div><p>'+escapeHtml(p.bio||'No bio yet.')+'</p>'+(socialHtml?'<section class="communities-panel"><h3>Social Links</h3><div class="following-list">'+socialHtml+'</div></section>':'')+(previous?'<div class="previous-usernames"><h3>Previous Usernames</h3><div class="previous-usernames-list">'+previous+'</div>'+updatedUsername+'</div>':'')+'<p class="muted">Gblocks player</p>';
    if(imageUrl){const avatarBox=box.querySelector('.ava');if(avatarBox)avatarBox.innerHTML='<img src="'+escapeHtml(imageUrl)+'" alt="Tubers93 Roblox 2020 avatar" style="width:100%;height:100%;object-fit:cover;display:block">';}
  }catch(e){console.error(e);box.innerHTML='<h1>Profile could not load</h1><p class="muted">Please refresh and try again.</p>';}
  function escapeHtml(v){return String(v==null?'':v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
  function socialUrl(k,v){let x=String(v).trim();if(x.startsWith('http://')||x.startsWith('https://'))return x;if(k==='youtube')return 'https://youtube.com/@'+x.replace(/^@/,'');if(k==='tiktok')return 'https://tiktok.com/@'+x.replace(/^@/,'');if(k==='instagram')return 'https://instagram.com/'+x.replace(/^@/,'');if(k==='x')return 'https://x.com/'+x.replace(/^@/,'');if(k==='discord')return x.startsWith('discord.gg/')?'https://'+x:'https://discord.com/users/'+x.replace(/^@/,'');return x;}
})();