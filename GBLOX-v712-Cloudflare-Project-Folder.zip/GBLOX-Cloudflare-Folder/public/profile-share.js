/* Builds a crawler-readable profile URL. The /p/:username route returns server-rendered Open Graph tags. */
(function(){
  function shareUrl(username){return new URL('/p/'+encodeURIComponent(String(username||'')),location.origin).href;}
  window.gbloxProfileShareUrl=shareUrl;
  window.gbloxCopyProfileLink=async function(username){
    const url=shareUrl(username);
    try{await navigator.clipboard.writeText(url);return {ok:true,url};}
    catch(e){return {ok:false,url};}
  };
})();