/* Shared GBLOX link-preview metadata for all public site routes. Existing page titles remain authoritative. */
(function(){
  const root='https://gblocks.hatchable.site';
  const path=location.pathname || '/';
  const titleByPath={
    '/':'GBLOX — Play, Create, and Connect',
    '/index.html':'GBLOX — Play, Create, and Connect',
    '/players.html':'Players • GBLOX',
    '/groups.html':'Communities • GBLOX',
    '/group.html':'Community • GBLOX',
    '/games.html':'Games • GBLOX',
    '/catalog.html':'Catalog • GBLOX',
    '/avatar.html':'Avatar Creator • GBLOX',
    '/premium.html':'GBLOX Premium',
    '/studio.html':'GBLOX Studio',
    '/signup.html':'Create an account • GBLOX',
    '/login.html':'Log in • GBLOX',
    '/terms.html':'Terms of Service • GBLOX'
  };
  const descByPath={
    '/':'Discover games, customize your avatar, meet players, and build communities on GBLOX.',
    '/players.html':'Discover GBLOX players and open their public profiles.',
    '/groups.html':'Discover, join, and create communities on GBLOX.',
    '/group.html':'Explore this GBLOX community, its members, and public details.',
    '/games.html':'Discover games published on GBLOX.',
    '/catalog.html':'Browse avatar items and catalog creations on GBLOX.',
    '/avatar.html':'Customize your GBLOX avatar and save your look.',
    '/premium.html':'Explore GBLOX Premium features.',
    '/studio.html':'Create and explore games with GBLOX Studio.',
    '/signup.html':'Create your GBLOX account.',
    '/login.html':'Log in to your GBLOX account.',
    '/terms.html':'Read the GBLOX Terms of Service.'
  };
  const title=titleByPath[path] || (document.title && document.title.trim()) || 'GBLOX';
  const description=descByPath[path] || 'Explore public content and communities on GBLOX.';
  const canonical=new URL(path,root).href;
  function meta(selector,attr,value,createTag,createAttr){
    let el=document.head.querySelector(selector);
    if(!el){el=document.createElement(createTag||'meta');if(createAttr)el.setAttribute(createAttr[0],createAttr[1]);document.head.appendChild(el);}
    el.setAttribute(attr,value);
  }
  function property(name,value){meta('meta[property="'+name+'"]','content',value,'meta',['property',name]);}
  function named(name,value){meta('meta[name="'+name+'"]','content',value,'meta',['name',name]);}
  property('og:site_name','GBLOX');property('og:type','website');property('og:title',title);
  property('og:description',description);property('og:url',canonical);
  property('og:image',root+'/icon.svg');property('og:image:alt','GBLOX');
  named('description',description);named('theme-color','#b51224');named('twitter:card','summary');
  let link=document.head.querySelector('link[rel="canonical"]');
  if(!link){link=document.createElement('link');link.rel='canonical';document.head.appendChild(link);}
  link.href=canonical;
})();