#!/bin/sh
set -eu
for f in functions/api/account/*.js; do
  node --input-type=module --check < "$f"
done
echo "Cloudflare Function syntax checks passed."
